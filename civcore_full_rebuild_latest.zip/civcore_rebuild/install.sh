#!/usr/bin/env bash
set -euo pipefail

SERVER_DIR="${SERVER_DIR:-$HOME/civcore_server}"
MC_VERSION="${MC_VERSION:-latest}"
MIN_RAM="${MIN_RAM:-3G}"
MAX_RAM="${MAX_RAM:-5G}"
TMUX_SESSION="${TMUX_SESSION:-mc}"

mkdir -p "$SERVER_DIR/plugins"
cd "$SERVER_DIR"

echo "[1/7] Installing system dependencies..."
if command -v apt >/dev/null 2>&1; then
  sudo apt update -y
  sudo apt install -y curl jq tmux unzip ca-certificates openjdk-21-jdk
fi

echo "[2/7] Resolving latest Purpur Minecraft version..."
if [ "$MC_VERSION" = "latest" ]; then
  MC_VERSION=$(curl -fsSL https://api.purpurmc.org/v2/purpur | jq -r '.versions[-1]')
fi
echo "Using Minecraft version: $MC_VERSION"

echo "[3/7] Downloading latest Purpur..."
curl -fL -o purpur.jar "https://api.purpurmc.org/v2/purpur/${MC_VERSION}/latest/download"

echo "[4/7] Accepting EULA and writing server.properties..."
echo "eula=true" > eula.txt
cat > server.properties <<PROPS
motd=CivCore Crossplay Server
server-port=25565
online-mode=true
enforce-secure-profile=false
max-players=20
view-distance=6
simulation-distance=4
spawn-protection=0
enable-command-block=false
allow-flight=true
sync-chunk-writes=false
network-compression-threshold=256
PROPS

echo "[5/7] Downloading crossplay + compatibility plugins..."
cd plugins
rm -f Geyser*.jar Floodgate*.jar floodgate*.jar ViaVersion*.jar ViaBackwards*.jar ViaRewind*.jar LuckPerms*.jar Vault*.jar spark*.jar CoreProtect*.jar EssentialsX*.jar
curl -fL -o Geyser-Spigot.jar "https://download.geysermc.org/v2/projects/geyser/versions/latest/builds/latest/downloads/spigot"
curl -fL -o floodgate-spigot.jar "https://download.geysermc.org/v2/projects/floodgate/versions/latest/builds/latest/downloads/spigot"
curl -fL -o ViaVersion.jar "https://hangarcdn.papermc.io/plugins/ViaVersion/ViaVersion/versions/latest/PAPER/download"
curl -fL -o ViaBackwards.jar "https://hangarcdn.papermc.io/plugins/ViaVersion/ViaBackwards/versions/latest/PAPER/download"
# ViaRewind is optional, but useful for older Java clients. Remove it if it causes issues.
curl -fL -o ViaRewind.jar "https://hangarcdn.papermc.io/plugins/ViaVersion/ViaRewind/versions/latest/PAPER/download" || true
curl -fL -o LuckPerms-Bukkit.jar "https://download.luckperms.net/1573/bukkit/loader/LuckPerms-Bukkit-5.5.11.jar" || true
curl -fL -o spark.jar "https://ci.lucko.me/job/spark/lastSuccessfulBuild/artifact/spark-bukkit/build/libs/spark-1.10.142-bukkit.jar" || true
cd ..

echo "[6/7] Writing start/update scripts..."
cat > start.sh <<START
#!/usr/bin/env bash
cd "\$(dirname "\$0")"
java -Xms${MIN_RAM} -Xmx${MAX_RAM} -XX:+UseG1GC -XX:+ParallelRefProcEnabled -XX:MaxGCPauseMillis=200 -XX:+UnlockExperimentalVMOptions -XX:+DisableExplicitGC -XX:+AlwaysPreTouch -XX:G1NewSizePercent=30 -XX:G1MaxNewSizePercent=40 -XX:G1HeapRegionSize=8M -XX:G1ReservePercent=20 -XX:G1HeapWastePercent=5 -XX:G1MixedGCCountTarget=4 -XX:InitiatingHeapOccupancyPercent=15 -XX:G1MixedGCLiveThresholdPercent=90 -XX:G1RSetUpdatingPauseTimePercent=5 -XX:SurvivorRatio=32 -XX:+PerfDisableSharedMem -XX:MaxTenuringThreshold=1 -jar purpur.jar nogui
START
chmod +x start.sh

cat > update.sh <<'UPDATE'
#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
MC_VERSION="${MC_VERSION:-latest}"
if [ "$MC_VERSION" = "latest" ]; then
  MC_VERSION=$(curl -fsSL https://api.purpurmc.org/v2/purpur | jq -r '.versions[-1]')
fi
echo "Updating to Purpur $MC_VERSION"
curl -fL -o purpur.jar "https://api.purpurmc.org/v2/purpur/${MC_VERSION}/latest/download"
cd plugins
rm -f Geyser*.jar Floodgate*.jar floodgate*.jar ViaVersion*.jar ViaBackwards*.jar ViaRewind*.jar
curl -fL -o Geyser-Spigot.jar "https://download.geysermc.org/v2/projects/geyser/versions/latest/builds/latest/downloads/spigot"
curl -fL -o floodgate-spigot.jar "https://download.geysermc.org/v2/projects/floodgate/versions/latest/builds/latest/downloads/spigot"
curl -fL -o ViaVersion.jar "https://hangarcdn.papermc.io/plugins/ViaVersion/ViaVersion/versions/latest/PAPER/download"
curl -fL -o ViaBackwards.jar "https://hangarcdn.papermc.io/plugins/ViaVersion/ViaBackwards/versions/latest/PAPER/download"
curl -fL -o ViaRewind.jar "https://hangarcdn.papermc.io/plugins/ViaVersion/ViaRewind/versions/latest/PAPER/download" || true
echo "Updated. Restart the server."
UPDATE
chmod +x update.sh

cat > run-tmux.sh <<RUN
#!/usr/bin/env bash
tmux kill-session -t ${TMUX_SESSION} 2>/dev/null || true
tmux new -d -s ${TMUX_SESSION} "cd '$SERVER_DIR' && ./start.sh"
tmux attach -t ${TMUX_SESSION}
RUN
chmod +x run-tmux.sh

echo "[7/7] Starting server in tmux..."
tmux kill-session -t "$TMUX_SESSION" 2>/dev/null || true
tmux new -d -s "$TMUX_SESSION" "cd '$SERVER_DIR' && ./start.sh"
echo "Done. Attach with: tmux attach -t $TMUX_SESSION"
echo "Server folder: $SERVER_DIR"
