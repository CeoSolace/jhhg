CivCore full rebuild pack

Upload this zip to your VPS, unzip it, then run:

chmod +x install.sh
./install.sh

Default install folder:
~/civcore_server

To force a specific Minecraft version:
MC_VERSION=1.21.11 ./install.sh

To update later:
cd ~/civcore_server
./update.sh
./run-tmux.sh

Bedrock/Xbox/PS5:
- Java port: 25565
- Bedrock/Geyser port: 19132 UDP
- Make sure your firewall allows UDP 19132 and TCP 25565.

Firewall quick commands:
sudo ufw allow 25565/tcp
sudo ufw allow 19132/udp

Useful tmux:
tmux attach -t mc
Ctrl+B then D to detach
