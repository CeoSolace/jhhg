#!/bin/bash
set -e
mkdir -p /opt/minecraft/backups
cd /opt/minecraft/server
tar -czf /opt/minecraft/backups/latest.tar.gz world plugins server.properties 2>/dev/null || true
