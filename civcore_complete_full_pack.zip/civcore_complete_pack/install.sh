#!/bin/bash
set -e
BASE="/opt/minecraft"
SERVER="$BASE/server"
PLUGINS="$SERVER/plugins"
SRC="$BASE/civcore-source"
PACK_DIR="$(cd "$(dirname "$0")" && pwd)"

apt update
apt install -y openjdk-21-jre wget curl unzip tmux cron ufw
mkdir -p "$SERVER" "$PLUGINS" "$BASE/backups"
cp -r "$PACK_DIR/civcore-source" "$SRC"
cd "$SERVER"
if [ ! -f purpur.jar ]; then wget -q https://api.purpurmc.org/v2/purpur/1.21.1/latest/download -O purpur.jar; fi
echo eula=true > eula.txt
cat > server.properties <<PROP
motd=CivCore | Two Country Nation Simulation
online-mode=true
pvp=true
difficulty=normal
gamemode=survival
max-players=30
view-distance=6
simulation-distance=4
spawn-protection=0
allow-nether=false
enforce-secure-profile=false
PROP
cd "$PLUGINS"
wget -q -nc https://download.geysermc.org/v2/projects/geyser/versions/latest/builds/latest/downloads/spigot -O Geyser-Spigot.jar || true
wget -q -nc https://download.geysermc.org/v2/projects/floodgate/versions/latest/builds/latest/downloads/spigot -O floodgate.jar || true
wget -q -nc https://download.luckperms.net/1515/bukkit/loader/LuckPerms-Bukkit-5.4.128.jar -O LuckPerms.jar || true
wget -q -nc https://github.com/PlayPro/CoreProtect/releases/latest/download/CoreProtect.jar -O CoreProtect.jar || true
wget -q -nc https://github.com/MilkBowl/Vault/releases/latest/download/Vault.jar -O Vault.jar || true
cd "$SRC"
if ! command -v gradle >/dev/null || gradle -v | grep -q "Gradle 4"; then
  cd /tmp
  wget -q https://services.gradle.org/distributions/gradle-8.10.2-bin.zip -O gradle.zip
  unzip -oq gradle.zip
  rm -rf /opt/gradle
  mv gradle-8.10.2 /opt/gradle
  ln -sf /opt/gradle/bin/gradle /usr/local/bin/gradle
fi
cd "$SRC"
gradle --stop || true
gradle clean build
cp build/libs/*.jar "$PLUGINS/CivCore.jar"
cp "$PACK_DIR/backup.sh" "$BASE/backup.sh" && chmod +x "$BASE/backup.sh"
(crontab -l 2>/dev/null | grep -v '/opt/minecraft/backup.sh' || true; echo '*/15 * * * * /opt/minecraft/backup.sh >/opt/minecraft/backups/backup.log 2>&1') | crontab -
ufw allow 22/tcp || true
ufw allow 25565/tcp || true
ufw allow 19132/udp || true
ufw --force enable || true
tmux kill-session -t mc 2>/dev/null || true
tmux new -d -s mc
tmux send-keys -t mc "cd $SERVER && java -Xms3G -Xmx5G -jar purpur.jar nogui" C-m
echo "Installed. Attach with: tmux attach -t mc"
