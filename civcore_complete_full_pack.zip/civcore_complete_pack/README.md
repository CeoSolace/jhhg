# CivCore Complete Server Pack

Full starter pack for a two-country Minecraft nation simulation server.

## Install
```bash
cd /path/to/civcore_complete_pack
chmod +x install.sh update.sh backup.sh
./install.sh
```

## Server console
```bash
tmux attach -t mc
```
Detach: Ctrl+B then D.

## Commands
- /spawn
- /join capitalist
- /join communist
- /room
- /hq
- /work
- /jobs
- /shop
- /balance
- /pay <player> <amount>
- /tax
- /treasury
- /rules
- /parliament propose <law>
- /parliament laws
- /gov appoint <player> <role>
- /civadmin rebuild
- /civadmin clear

## Features
- Floating spawn island built on join
- Players cannot leave spawn island except portal pads
- Emerald portal = survival zone
- Redstone portal = PvP zone
- Gold portal = spawn
- Communist and capitalist HQ hotels
- Assigned locked hotel rooms
- Fall damage protection after teleports
- Economy, taxes, treasuries
- Task-based work system
- Rule and command book, non-droppable
- Protected HQs and rooms
- Nether disabled
- Scoreboard UI
- Backups every 15 minutes
