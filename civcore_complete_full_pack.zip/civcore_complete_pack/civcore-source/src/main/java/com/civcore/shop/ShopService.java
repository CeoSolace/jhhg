package com.civcore.shop;

import com.civcore.economy.EconomyService;
import org.bukkit.*;import org.bukkit.entity.Player;import org.bukkit.event.*;import org.bukkit.event.inventory.InventoryClickEvent;import org.bukkit.inventory.*;import org.bukkit.inventory.meta.ItemMeta;
import java.util.*;

public class ShopService implements Listener{
    private final EconomyService economy; public ShopService(EconomyService economy){this.economy=economy;}
    public void open(Player p){ Inventory inv=Bukkit.createInventory(null,27,ChatColor.GOLD+"CivCore Shop"); item(inv,10,Material.BREAD,16,"Bread Pack",5); item(inv,11,Material.COOKED_BEEF,8,"Steak Pack",15); item(inv,12,Material.COAL,16,"Coal Pack",10); item(inv,14,Material.IRON_INGOT,4,"Iron Pack",50); item(inv,15,Material.STONE_BRICKS,32,"Building Pack",6); item(inv,16,Material.OAK_LOG,16,"Wood Pack",8); p.openInventory(inv); }
    private void item(Inventory inv,int slot,Material m,int amount,String name,double price){ ItemStack it=new ItemStack(m,amount); ItemMeta meta=it.getItemMeta(); if(meta!=null){meta.setDisplayName(ChatColor.YELLOW+name); meta.setLore(List.of(ChatColor.GRAY+"Price: $"+price)); it.setItemMeta(meta);} inv.setItem(slot,it);}
    @EventHandler public void click(InventoryClickEvent e){ if(!e.getView().getTitle().equals(ChatColor.GOLD+"CivCore Shop"))return; e.setCancelled(true); if(!(e.getWhoClicked() instanceof Player p))return; ItemStack it=e.getCurrentItem(); if(it==null||it.getType()==Material.AIR)return; double price=switch(it.getType()){case BREAD->5;case COOKED_BEEF->15;case COAL->10;case IRON_INGOT->50;case STONE_BRICKS->6;case OAK_LOG->8;default->-1;}; if(price<0)return; if(!economy.withdraw(p,price)){p.sendMessage(ChatColor.RED+"Not enough money.");return;} p.getInventory().addItem(new ItemStack(it.getType(),it.getAmount())); p.sendMessage(ChatColor.GREEN+"Purchased "+it.getAmount()+"x "+it.getType().name()); }
}
