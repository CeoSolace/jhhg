package com.civcore.country;

import org.bukkit.ChatColor;

public enum Side {
    CAPITALIST, COMMUNIST, NONE;
    public static Side parse(String raw) {
        if (raw == null) return NONE;
        if (raw.equalsIgnoreCase("capitalist") || raw.equalsIgnoreCase("cap")) return CAPITALIST;
        if (raw.equalsIgnoreCase("communist") || raw.equalsIgnoreCase("com")) return COMMUNIST;
        return NONE;
    }
    public String display() {
        return switch (this) { case CAPITALIST -> "Capitalist"; case COMMUNIST -> "Communist"; default -> "None"; };
    }
    public ChatColor color() { return this == COMMUNIST ? ChatColor.RED : this == CAPITALIST ? ChatColor.GOLD : ChatColor.GRAY; }
    public String key() { return name().toLowerCase(); }
}
