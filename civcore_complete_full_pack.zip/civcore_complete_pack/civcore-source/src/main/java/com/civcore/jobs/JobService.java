package com.civcore.jobs;

import com.civcore.economy.EconomyService;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.block.BlockBreakEvent;
import java.util.*;

public class JobService implements Listener {
    private final EconomyService economy;
    private final Map<UUID,String> job = new HashMap<>();
    private final Map<UUID,Integer> progress = new HashMap<>();
    private final Random random = new Random();
    public JobService(EconomyService economy){this.economy=economy;}
    public void start(Player p){
        UUID id=p.getUniqueId();
        if(job.containsKey(id)){ p.sendMessage(ChatColor.YELLOW+"Current task: "+job.get(id)+" "+progress.getOrDefault(id,0)+"/5"); return; }
        String j = switch(random.nextInt(4)){ case 0 -> "MINER"; case 1 -> "LUMBERJACK"; case 2 -> "FARMER"; default -> "BUILDER"; };
        job.put(id,j); progress.put(id,0);
        p.sendTitle(ChatColor.GOLD+"Work Task", ChatColor.YELLOW+taskText(j), 10,80,20);
        p.sendMessage(ChatColor.GOLD+"Work started: "+j+ChatColor.GRAY+" | "+taskText(j));
    }
    public String taskText(String j){ return switch(j){ case "MINER" -> "Break 5 stone/deepslate/ore"; case "LUMBERJACK" -> "Break 5 logs"; case "FARMER" -> "Break 5 crops"; case "BUILDER" -> "Break 5 stone bricks/planks"; default -> "Complete 5 actions";}; }
    @EventHandler public void breakBlock(BlockBreakEvent e){
        Player p=e.getPlayer(); UUID id=p.getUniqueId(); String j=job.get(id); if(j==null)return;
        Material m=e.getBlock().getType(); boolean valid = switch(j){
            case "MINER" -> m==Material.STONE||m==Material.DEEPSLATE||m.name().contains("ORE");
            case "LUMBERJACK" -> m.name().contains("LOG");
            case "FARMER" -> m==Material.WHEAT||m==Material.CARROTS||m==Material.POTATOES||m==Material.BEETROOTS;
            case "BUILDER" -> m.name().contains("PLANKS")||m.name().contains("BRICKS");
            default -> false;
        };
        if(!valid)return; int now=progress.getOrDefault(id,0)+1; progress.put(id,now); p.sendMessage(ChatColor.GREEN+"Task progress: "+now+"/5");
        if(now>=5){ job.remove(id); progress.remove(id); economy.taxedIncome(p,75.0); p.sendTitle(ChatColor.GREEN+"Job Complete", ChatColor.GRAY+"Gross pay $75",10,60,20); }
    }
}
