package com.civcore.rules;

import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.BookMeta;

public class RuleBookService {
    public ItemStack book(){
        ItemStack book=new ItemStack(Material.WRITTEN_BOOK); BookMeta m=(BookMeta)book.getItemMeta(); if(m==null)return book;
        m.setTitle("CivCore Command Book"); m.setAuthor("CivCore");
        m.addPage(ChatColor.GOLD+"CivCore\n\n"+ChatColor.BLACK+"Welcome. Use the spawn portals to leave the floating spawn island. Choose a country with /join capitalist or /join communist.");
        m.addPage(ChatColor.GOLD+"Rules\n\n"+ChatColor.BLACK+"No griefing HQs. No exploiting. No hacked clients. Respect staff. Build freely outside protected areas. Nether is disabled.");
        m.addPage(ChatColor.GOLD+"Commands\n\n"+ChatColor.BLACK+"/spawn\n/join <side>\n/room\n/hq\n/work\n/balance\n/pay\n/shop\n/treasury\n/parliament");
        m.addPage(ChatColor.GOLD+"Countries\n\n"+ChatColor.BLACK+"Each side has a hotel HQ, parliament, shops, jobs, rooms, locked doors, taxes, and a treasury.");
        book.setItemMeta(m); return book;
    }
    public void give(Player p, boolean force){
        if(!force){ for(ItemStack i:p.getInventory().getContents()){ if(i!=null&&i.getType()==Material.WRITTEN_BOOK&&i.hasItemMeta()){ BookMeta m=(BookMeta)i.getItemMeta(); if(m!=null&&"CivCore Command Book".equals(m.getTitle())) return; } } }
        p.getInventory().addItem(book()); p.sendMessage(ChatColor.GOLD+"You received the CivCore command book.");
    }
}
