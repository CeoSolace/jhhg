package com.civcore.economy;

import com.civcore.country.Side;
import com.civcore.storage.DataStore;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;

public class EconomyService {
    private final DataStore data;
    public EconomyService(DataStore data){ this.data=data; }
    public double balance(Player p){ return data.balance(p.getUniqueId()); }
    public void deposit(Player p,double amount){ data.balance(p.getUniqueId(), balance(p)+Math.max(0,amount)); }
    public boolean withdraw(Player p,double amount){ if(amount<=0 || balance(p)<amount)return false; data.balance(p.getUniqueId(), balance(p)-amount); return true; }
    public void taxedIncome(Player p,double gross){
        Side side=data.side(p.getUniqueId()); double tax=gross*data.tax(side); double net=gross-tax;
        data.addTreasury(side,tax); deposit(p,net);
        p.sendMessage(ChatColor.GREEN+"Earned $"+String.format("%.2f",net)+ChatColor.YELLOW+" | Tax: $"+String.format("%.2f",tax));
    }
    public void pay(Player from, Player to, double amount){
        if(amount<=0){ from.sendMessage(ChatColor.RED+"Amount must be positive."); return; }
        if(!withdraw(from,amount)){ from.sendMessage(ChatColor.RED+"Not enough money."); return; }
        to.sendMessage(ChatColor.GREEN+from.getName()+" paid you $"+String.format("%.2f",amount)); deposit(to,amount);
        from.sendMessage(ChatColor.GREEN+"Paid $"+String.format("%.2f",amount)+" to "+to.getName());
    }
}
