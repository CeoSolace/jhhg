package com.civcore.storage;

import com.civcore.CivCore;
import com.civcore.country.Side;
import org.bukkit.configuration.file.YamlConfiguration;
import java.io.File;
import java.io.IOException;
import java.util.*;

public class DataStore {
    private final CivCore plugin;
    private File playersFile, countriesFile, lawsFile;
    private YamlConfiguration players, countries, laws;
    public DataStore(CivCore plugin) { this.plugin = plugin; }
    public void load() {
        plugin.getDataFolder().mkdirs();
        playersFile = new File(plugin.getDataFolder(), "players.yml");
        countriesFile = new File(plugin.getDataFolder(), "countries.yml");
        lawsFile = new File(plugin.getDataFolder(), "laws.yml");
        players = YamlConfiguration.loadConfiguration(playersFile);
        countries = YamlConfiguration.loadConfiguration(countriesFile);
        laws = YamlConfiguration.loadConfiguration(lawsFile);
        countries.addDefault("capitalist.tax", 0.08); countries.addDefault("capitalist.treasury", 0.0); countries.addDefault("capitalist.leader", "");
        countries.addDefault("communist.tax", 0.30); countries.addDefault("communist.treasury", 0.0); countries.addDefault("communist.leader", "");
        countries.options().copyDefaults(true); saveAll();
    }
    public void saveAll() { try { players.save(playersFile); countries.save(countriesFile); laws.save(lawsFile); } catch(IOException e){ plugin.getLogger().severe("Failed saving data"); e.printStackTrace(); } }
    public Side side(UUID id){ return Side.parse(players.getString(id+".side", "NONE")); }
    public void side(UUID id, Side side){ players.set(id+".side", side.name()); saveAll(); }
    public double balance(UUID id){ return players.getDouble(id+".balance", 250.0); }
    public void balance(UUID id,double val){ players.set(id+".balance", Math.max(0,val)); saveAll(); }
    public int room(UUID id){ return players.getInt(id+".room", -1); }
    public void room(UUID id,int val){ players.set(id+".room", val); saveAll(); }
    public String role(UUID id){ return players.getString(id+".role", "Citizen"); }
    public void role(UUID id,String role){ players.set(id+".role", role); saveAll(); }
    public double tax(Side s){ if(s==Side.CAPITALIST) return countries.getDouble("capitalist.tax"); if(s==Side.COMMUNIST) return countries.getDouble("communist.tax"); return 0; }
    public void tax(Side s,double tax){ tax=Math.max(0,Math.min(.75,tax)); if(s==Side.CAPITALIST)countries.set("capitalist.tax",tax); if(s==Side.COMMUNIST)countries.set("communist.tax",tax); saveAll(); }
    public double treasury(Side s){ if(s==Side.CAPITALIST)return countries.getDouble("capitalist.treasury"); if(s==Side.COMMUNIST)return countries.getDouble("communist.treasury"); return 0; }
    public void addTreasury(Side s,double amt){ if(s==Side.CAPITALIST)countries.set("capitalist.treasury", treasury(s)+amt); if(s==Side.COMMUNIST)countries.set("communist.treasury", treasury(s)+amt); saveAll(); }
    public void addLaw(Side s, String law){ List<String> list = laws.getStringList(s.key()+".laws"); list.add(law); laws.set(s.key()+".laws", list); saveAll(); }
    public List<String> laws(Side s){ return laws.getStringList(s.key()+".laws"); }
}
