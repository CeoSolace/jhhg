#!/bin/bash
set -e
BASE="/opt/minecraft"
PACK_DIR="$(cd "$(dirname "$0")" && pwd)"
rm -rf "$BASE/civcore-source"
cp -r "$PACK_DIR/civcore-source" "$BASE/civcore-source"
cd "$BASE/civcore-source"
gradle --stop || true
gradle clean build
cp build/libs/*.jar "$BASE/server/plugins/CivCore.jar"
tmux send-keys -t mc "stop" C-m || true
sleep 8
tmux has-session -t mc 2>/dev/null || tmux new -d -s mc
tmux send-keys -t mc "cd $BASE/server && java -Xms3G -Xmx5G -jar purpur.jar nogui" C-m
echo "Updated and restarted."
