#!/bin/bash
set -e

SERVER="/opt/minecraft/server"
BACKUPS="/opt/minecraft/backups"
mkdir -p "$BACKUPS"

tar -czf "$BACKUPS/rolling_15min.tar.gz.tmp" \
  -C "$SERVER" \
  world world_nether world_the_end plugins 2>/dev/null || true

mv "$BACKUPS/rolling_15min.tar.gz.tmp" "$BACKUPS/rolling_15min.tar.gz" 2>/dev/null || true
