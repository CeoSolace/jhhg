#!/bin/bash
set -e

BASE="/opt/minecraft"
CIV="$BASE/civcore-source"
SERVER="$BASE/server"

echo "[1] Building CivCore..."
cd "$CIV"
gradle clean build
cp build/libs/*.jar "$SERVER/plugins/CivCore.jar"

echo "[2] Restarting server..."
tmux has-session -t mc 2>/dev/null || tmux new -d -s mc
tmux send-keys -t mc "stop" C-m || true
sleep 8
tmux send-keys -t mc "cd $SERVER && $BASE/scripts/start.sh" C-m

echo "Updated."
