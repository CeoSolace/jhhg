package com.civcore.government;

import com.civcore.country.Side;
import com.civcore.storage.DataStore;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;

import java.util.*;

public class ParliamentService {
    private final DataStore data;
    private final Map<Side, Proposal> active = new EnumMap<>(Side.class);

    public ParliamentService(DataStore data) {
        this.data = data;
    }

    public void propose(Player player, Side side, String text) {
        if (side == Side.NONE) {
            player.sendMessage(ChatColor.RED + "Join a country first.");
            return;
        }
        if (text == null || text.length() < 5) {
            player.sendMessage(ChatColor.RED + "Proposal too short.");
            return;
        }

        active.put(side, new Proposal(text, player.getUniqueId()));
        Bukkit.broadcastMessage(ChatColor.GOLD + "[" + side.display() + " Parliament] New proposal: " + text);
        Bukkit.broadcastMessage(ChatColor.YELLOW + "Vote with /parliament vote yes or /parliament vote no");
    }

    public void vote(Player player, Side side, boolean yes) {
        Proposal proposal = active.get(side);
        if (proposal == null) {
            player.sendMessage(ChatColor.RED + "No active proposal for your country.");
            return;
        }

        proposal.votes.put(player.getUniqueId(), yes);
        player.sendMessage(ChatColor.GREEN + "Vote recorded.");

        if (proposal.votes.size() >= 3) {
            finish(side);
        }
    }

    public void finish(Side side) {
        Proposal proposal = active.remove(side);
        if (proposal == null) return;

        long yes = proposal.votes.values().stream().filter(v -> v).count();
        long no = proposal.votes.values().stream().filter(v -> !v).count();

        if (yes > no) {
            data.addLaw(side, proposal.text);
            Bukkit.broadcastMessage(ChatColor.GREEN + "[" + side.display() + " Parliament] Law passed: " + proposal.text);
        } else {
            Bukkit.broadcastMessage(ChatColor.RED + "[" + side.display() + " Parliament] Proposal failed: " + proposal.text);
        }
    }

    public String status(Side side) {
        Proposal p = active.get(side);
        if (p == null) return "No active proposal.";
        long yes = p.votes.values().stream().filter(v -> v).count();
        long no = p.votes.values().stream().filter(v -> !v).count();
        return p.text + " | Yes: " + yes + " No: " + no;
    }

    private static class Proposal {
        final String text;
        final UUID proposer;
        final Map<UUID, Boolean> votes = new HashMap<>();

        Proposal(String text, UUID proposer) {
            this.text = text;
            this.proposer = proposer;
        }
    }
}
