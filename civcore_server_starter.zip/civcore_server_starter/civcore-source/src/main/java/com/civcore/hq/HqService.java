package com.civcore.hq;

import com.civcore.CivCore;
import com.civcore.country.Side;
import com.civcore.storage.DataStore;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.Chest;
import org.bukkit.block.data.Bisected;
import org.bukkit.block.data.type.Door;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.*;

public class HqService {
    private final CivCore plugin;
    private final DataStore data;
    private final Set<String> protectedBlocks = new HashSet<>();
    private final Map<String, UUID> lockedDoors = new HashMap<>();
    private final Map<Side, List<Location>> rooms = new EnumMap<>(Side.class);

    public HqService(CivCore plugin, DataStore data) {
        this.plugin = plugin;
        this.data = data;
        rooms.put(Side.CAPITALIST, new ArrayList<>());
        rooms.put(Side.COMMUNIST, new ArrayList<>());
    }

    public void rebuildBatched() {
        protectedBlocks.clear();
        lockedDoors.clear();
        rooms.get(Side.CAPITALIST).clear();
        rooms.get(Side.COMMUNIST).clear();

        buildCountry(base(Side.COMMUNIST), Side.COMMUNIST);
        buildCountry(base(Side.CAPITALIST), Side.CAPITALIST);
    }

    public boolean isProtected(Block b) {
        return protectedBlocks.contains(key(b));
    }

    public boolean isLockedDoor(Block b) {
        return lockedDoors.containsKey(doorKey(b));
    }

    public boolean canUseDoor(Player p, Block b) {
        UUID owner = lockedDoors.get(doorKey(b));
        return owner == null || owner.equals(p.getUniqueId()) || p.hasPermission("civcore.admin");
    }

    public void toggleDoor(Block clicked) {
        Block lower = clicked;
        if (clicked.getBlockData() instanceof Door d && d.getHalf() == Bisected.Half.TOP) {
            lower = clicked.getLocation().clone().add(0, -1, 0).getBlock();
        }
        Block upper = lower.getLocation().clone().add(0, 1, 0).getBlock();
        if (!(lower.getBlockData() instanceof Door ld)) return;
        if (!(upper.getBlockData() instanceof Door ud)) return;
        boolean open = !ld.isOpen();
        ld.setOpen(open);
        ud.setOpen(open);
        lower.setBlockData(ld);
        upper.setBlockData(ud);
    }

    public Location assignRoom(Player p, Side side) {
        if (rooms.get(side).isEmpty()) rebuildBatched();
        List<Location> list = rooms.get(side);
        if (list.isEmpty()) return base(side).clone().add(0, 2, -75);

        int saved = data.getRoom(p.getUniqueId());
        int index = saved >= 0 && saved < list.size() ? saved : Math.abs(p.getUniqueId().hashCode()) % list.size();
        data.setRoom(p.getUniqueId(), index);

        Location door = list.get(index);
        lockedDoors.put(doorKey(door.getBlock()), p.getUniqueId());
        Location tp = door.clone().add(0, 0, 2);
        tp.setYaw(180);
        return tp;
    }

    public Location hqSpawn(Side side) {
        return base(side).clone().add(0, 2, -82);
    }

    public void clearOldZonesBatched() {
        int[] bases = {-450, 450, -350, 350, -260, 260, -200, 200, -150, 150};
        new BukkitRunnable() {
            int baseIndex = 0;
            int dx = -130, dy = -20, dz = -130;
            final int blocksPerTick = 2500;

            @Override
            public void run() {
                int count = 0;
                while (count < blocksPerTick && baseIndex < bases.length) {
                    Location base = new Location(world(), bases[baseIndex], 80, 0);
                    base.clone().add(dx, dy, dz).getBlock().setType(Material.AIR, false);
                    count++;

                    dz++;
                    if (dz > 130) { dz = -130; dy++; }
                    if (dy > 100) { dy = -20; dx++; }
                    if (dx > 130) { dx = -130; baseIndex++; }
                }
                if (baseIndex >= bases.length) {
                    cancel();
                    Bukkit.broadcastMessage(ChatColor.GREEN + "[CivCore] Old HQ areas cleared.");
                }
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    private World world() {
        World w = Bukkit.getWorld("world");
        return w == null ? Bukkit.getWorlds().get(0) : w;
    }

    private Location base(Side side) {
        return side == Side.COMMUNIST ? safeLand(-450, 0) : safeLand(450, 0);
    }

    private Location safeLand(int sx, int sz) {
        World w = world();
        for (int r = 0; r <= 1000; r += 25) {
            for (int x = sx - r; x <= sx + r; x += 25) {
                for (int z = sz - r; z <= sz + r; z += 25) {
                    int y = w.getHighestBlockYAt(x, z);
                    Material ground = w.getBlockAt(x, y - 1, z).getType();
                    if (!ground.name().contains("WATER") && !ground.name().contains("LAVA") && !ground.name().contains("ICE") && ground != Material.AIR) {
                        return new Location(w, x, y + 4, z);
                    }
                }
            }
        }
        return new Location(w, sx, 100, sz);
    }

    private void buildCountry(Location base, Side side) {
        boolean com = side == Side.COMMUNIST;
        Material wall = com ? Material.WHITE_CONCRETE : Material.SMOOTH_QUARTZ;
        Material trim = com ? Material.RED_CONCRETE : Material.DEEPSLATE_TILES;
        Material floor = com ? Material.LIGHT_GRAY_CONCRETE : Material.QUARTZ_BLOCK;
        Material carpet = com ? Material.RED_CARPET : Material.BLUE_CARPET;
        Material roomWall = com ? Material.SPRUCE_PLANKS : Material.BIRCH_PLANKS;
        Material bed = com ? Material.RED_BED : Material.BLUE_BED;

        preparePlot(base);
        cuboid(base, -90,0,-70,90,2,70,floor);
        hollowBox(base, -76,3,-58,76,34,58,wall,floor);
        hollowBox(base, -42,35,-40,42,62,40,wall,floor);
        cuboid(base, -98,3,-42,-78,26,42,wall);
        cuboid(base, 78,3,-42,98,26,42,wall);

        for (int y : new int[]{3,13,23,33,43,53}) cuboid(base,-74,y,-56,74,y,56,Material.SMOOTH_STONE);

        cuboid(base,-30,3,-78,30,22,-59, com ? Material.DEEPSLATE_BRICKS : Material.QUARTZ_PILLAR);
        columns(base,-42,4,-82,42,28, com ? Material.POLISHED_DIORITE : Material.QUARTZ_PILLAR);
        clearDoor(base,-9,3,-80,9,14,-59);
        for (int i=0;i<12;i++) cuboid(base,-46-i,i,-98-i,46+i,i,-78, com ? Material.STONE_BRICK_STAIRS : Material.QUARTZ_STAIRS);
        cuboid(base,-78,35,-60,78,37,60,trim);
        cuboid(base,-44,63,-42,44,65,42,trim);

        createLobby(base, carpet);
        createFacilities(base);
        createRooms(base, side, roomWall, bed);
    }

    private void preparePlot(Location base) {
        World w = base.getWorld();
        int bx=base.getBlockX(), by=base.getBlockY(), bz=base.getBlockZ();
        for (int x=-120;x<=120;x++) {
            for (int z=-120;z<=120;z++) {
                Block floor = w.getBlockAt(bx+x, by-1, bz+z);
                floor.setType(Material.STONE_BRICKS, false);
                protectedBlocks.add(key(floor));
                for (int y=0;y<=85;y++) {
                    Block b = w.getBlockAt(bx+x, by+y, bz+z);
                    if (b.isLiquid()) b.setType(Material.AIR, false);
                }
            }
        }
    }

    private void createLobby(Location base, Material carpet) {
        cuboid(base,-32,4,-36,32,4,22,carpet);
        cuboid(base,-16,5,10,16,5,16,Material.DARK_OAK_PLANKS);
        for (int x=-28;x<=28;x+=14) {
            place(base,x,6,-28,Material.LANTERN);
            place(base,x,6,12,Material.LANTERN);
        }
    }

    private void createFacilities(Location base) {
        cuboid(base,-66,4,22,-38,4,50,Material.DEEPSLATE);
        place(base,-56,5,36,Material.DIAMOND_ORE);
        place(base,-52,5,36,Material.IRON_ORE);
        place(base,-48,5,36,Material.COAL_ORE);
        cuboid(base,38,4,22,66,4,50,Material.OAK_PLANKS);
        for (int x : new int[]{46,54,62}) {
            place(base,x,5,36,Material.CHEST);
            fillShopChest(base.clone().add(x,5,36).getBlock());
        }
        cuboid(base,-18,4,30,18,4,52,Material.DEEPSLATE_TILES);
        place(base,0,5,42,Material.LECTERN);
        place(base,4,5,42,Material.ENDER_CHEST);
        place(base,-4,5,42,Material.CRAFTING_TABLE);
    }

    private void createRooms(Location base, Side side, Material wall, Material bed) {
        List<Location> list = rooms.get(side);
        list.clear();
        for (int floorY : new int[]{5,16,27,38}) {
            for (int x=-64;x<=48;x+=16) {
                Location corner = base.clone().add(x,floorY,-48);
                list.add(buildSuite(corner, wall, bed));
            }
        }
    }

    private Location buildSuite(Location c, Material wall, Material bed) {
        for (int x=0;x<=13;x++) for (int y=0;y<=9;y++) for (int z=0;z<=13;z++)
            if (x==0||x==13||y==0||y==9||z==0||z==13) placeAbs(c.clone().add(x,y,z), wall);

        for (int x=1;x<=12;x++) for (int y=1;y<=8;y++) for (int z=1;z<=12;z++) c.clone().add(x,y,z).getBlock().setType(Material.AIR, false);
        cuboidAbs(c.clone().add(1,4,1), c.clone().add(12,4,12), Material.SMOOTH_STONE);

        Location door = c.clone().add(6,1,0);
        setDoor(door);

        placeAbs(c.clone().add(2,1,10), bed);
        placeAbs(c.clone().add(4,1,10), Material.CHEST);
        fillStarterChest(c.clone().add(4,1,10).getBlock());
        placeAbs(c.clone().add(6,1,10), Material.FURNACE);
        placeAbs(c.clone().add(8,1,10), Material.CRAFTING_TABLE);
        placeAbs(c.clone().add(10,1,10), Material.LANTERN);

        placeAbs(c.clone().add(2,5,10), bed);
        placeAbs(c.clone().add(4,5,10), Material.CHEST);
        fillStarterChest(c.clone().add(4,5,10).getBlock());
        placeAbs(c.clone().add(6,5,10), Material.FURNACE);
        placeAbs(c.clone().add(8,5,10), Material.LANTERN);
        return door;
    }

    private void setDoor(Location loc) {
        Block lower = loc.getBlock();
        Block upper = loc.clone().add(0,1,0).getBlock();
        lower.setType(Material.IRON_DOOR, false);
        upper.setType(Material.IRON_DOOR, false);
        Door ld = (Door) Bukkit.createBlockData(Material.IRON_DOOR);
        ld.setHalf(Bisected.Half.BOTTOM);
        Door ud = (Door) Bukkit.createBlockData(Material.IRON_DOOR);
        ud.setHalf(Bisected.Half.TOP);
        lower.setBlockData(ld, false);
        upper.setBlockData(ud, false);
        protectedBlocks.add(key(lower));
        protectedBlocks.add(key(upper));
    }

    private void fillStarterChest(Block block) {
        if (!(block.getState() instanceof Chest chest)) return;
        chest.getInventory().clear();
        chest.getInventory().addItem(new ItemStack(Material.BREAD, 16));
        chest.getInventory().addItem(new ItemStack(Material.COOKED_BEEF, 8));
        chest.getInventory().addItem(new ItemStack(Material.COAL, 16));
        chest.getInventory().addItem(new ItemStack(Material.TORCH, 16));
    }

    private void fillShopChest(Block block) {
        if (!(block.getState() instanceof Chest chest)) return;
        chest.getInventory().clear();
        chest.getInventory().addItem(new ItemStack(Material.BREAD, 32));
        chest.getInventory().addItem(new ItemStack(Material.COOKED_BEEF, 16));
        chest.getInventory().addItem(new ItemStack(Material.COAL, 32));
        chest.getInventory().addItem(new ItemStack(Material.IRON_INGOT, 8));
        chest.getInventory().addItem(new ItemStack(Material.STONE_BRICKS, 64));
        chest.getInventory().addItem(new ItemStack(Material.OAK_LOG, 32));
    }

    private void cuboid(Location b,int x1,int y1,int z1,int x2,int y2,int z2,Material m) {
        for (int x=Math.min(x1,x2);x<=Math.max(x1,x2);x++) for (int y=Math.min(y1,y2);y<=Math.max(y1,y2);y++) for (int z=Math.min(z1,z2);z<=Math.max(z1,z2);z++) place(b,x,y,z,m);
    }

    private void hollowBox(Location b,int x1,int y1,int z1,int x2,int y2,int z2,Material wall,Material floor) {
        for (int x=x1;x<=x2;x++) for (int y=y1;y<=y2;y++) for (int z=z1;z<=z2;z++)
            if (x==x1||x==x2||y==y1||y==y2||z==z1||z==z2) place(b,x,y,z,(y==y1||y==y2)?floor:wall);
    }

    private void columns(Location b,int x1,int y1,int z,int x2,int y2,Material m) {
        for (int x=x1;x<=x2;x+=7) for (int y=y1;y<=y2;y++) place(b,x,y,z,m);
    }

    private void clearDoor(Location b,int x1,int y1,int z1,int x2,int y2,int z2) {
        for (int x=x1;x<=x2;x++) for (int y=y1;y<=y2;y++) for (int z=z1;z<=z2;z++) b.clone().add(x,y,z).getBlock().setType(Material.AIR, false);
    }

    private void cuboidAbs(Location a, Location b, Material m) {
        World w = a.getWorld();
        for (int x=Math.min(a.getBlockX(),b.getBlockX());x<=Math.max(a.getBlockX(),b.getBlockX());x++) for (int y=Math.min(a.getBlockY(),b.getBlockY());y<=Math.max(a.getBlockY(),b.getBlockY());y++) for (int z=Math.min(a.getBlockZ(),b.getBlockZ());z<=Math.max(a.getBlockZ(),b.getBlockZ());z++) {
            Block block = w.getBlockAt(x,y,z);
            block.setType(m, false);
            protectedBlocks.add(key(block));
        }
    }

    private void place(Location b,int x,int y,int z,Material m) {
        Block block = b.clone().add(x,y,z).getBlock();
        block.setType(m, false);
        protectedBlocks.add(key(block));
    }

    private void placeAbs(Location loc, Material m) {
        Block block = loc.getBlock();
        block.setType(m, false);
        protectedBlocks.add(key(block));
    }

    private String key(Block b) {
        return b.getWorld().getName()+":"+b.getX()+":"+b.getY()+":"+b.getZ();
    }

    private String doorKey(Block b) {
        if (b.getBlockData() instanceof Door d && d.getHalf() == Bisected.Half.TOP) return key(b.getLocation().clone().add(0,-1,0).getBlock());
        return key(b);
    }
}
