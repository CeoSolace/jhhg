package com.civcore;

import com.civcore.country.Side;
import com.civcore.economy.EconomyService;
import com.civcore.government.ParliamentService;
import com.civcore.hq.HqService;
import com.civcore.storage.DataStore;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.data.type.Door;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.block.*;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.*;
import org.bukkit.event.world.PortalCreateEvent;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.BookMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scoreboard.*;

import java.util.List;
import java.util.UUID;

public class CivCore extends JavaPlugin implements Listener, CommandExecutor {
    private DataStore data;
    private EconomyService economy;
    private ParliamentService parliament;
    private HqService hq;

    @Override
    public void onEnable() {
        data = new DataStore(this);
        data.load();

        economy = new EconomyService(data);
        parliament = new ParliamentService(data);
        hq = new HqService(this, data);

        Bukkit.getPluginManager().registerEvents(this, this);

        for (String cmd : new String[]{"join","country","parliament","work","job","balance","pay","tax","treasury","room","hq","rules","shop","civadmin"}) {
            PluginCommand pc = getCommand(cmd);
            if (pc != null) pc.setExecutor(this);
        }

        Bukkit.getScheduler().runTaskTimer(this, this::updateScoreboards, 100L, 100L);

        getLogger().info("CivCore Nation Simulation enabled.");
    }

    @Override
    public void onDisable() {
        data.saveAll();
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        data.setBalance(p.getUniqueId(), data.getBalance(p.getUniqueId()));
        giveRules(p, false);
        updateScoreboard(p);
    }

    @EventHandler
    public void onDrop(PlayerDropItemEvent e) {
        ItemStack item = e.getItemDrop().getItemStack();
        if (item.getType() == Material.WRITTEN_BOOK && item.hasItemMeta()) {
            BookMeta meta = (BookMeta) item.getItemMeta();
            if (meta != null && "CivCore Rulebook".equals(meta.getTitle())) {
                e.setCancelled(true);
                e.getPlayer().sendMessage(ChatColor.RED + "You cannot drop the rulebook.");
            }
        }
    }

    @EventHandler
    public void onBreak(BlockBreakEvent e) {
        if (hq.isProtected(e.getBlock()) && !e.getPlayer().hasPermission("civcore.admin")) {
            e.setCancelled(true);
            e.getPlayer().sendMessage(ChatColor.RED + "This country HQ is protected.");
        }
    }

    @EventHandler
    public void onPlace(BlockPlaceEvent e) {
        if (hq.isProtected(e.getBlock()) && !e.getPlayer().hasPermission("civcore.admin")) {
            e.setCancelled(true);
            e.getPlayer().sendMessage(ChatColor.RED + "You cannot build inside protected HQ zones.");
        }
    }

    @EventHandler
    public void onPortal(PlayerPortalEvent e) {
        e.setCancelled(true);
        e.getPlayer().sendMessage(ChatColor.RED + "Nether and portal travel are disabled.");
    }

    @EventHandler
    public void onPortalCreate(PortalCreateEvent e) {
        e.setCancelled(true);
    }

    @EventHandler
    public void onDoor(PlayerInteractEvent e) {
        if (e.getClickedBlock() == null) return;
        Block b = e.getClickedBlock();
        if (!(b.getBlockData() instanceof Door)) return;

        if (hq.isLockedDoor(b)) {
            e.setCancelled(true);
            if (!hq.canUseDoor(e.getPlayer(), b)) {
                e.getPlayer().sendMessage(ChatColor.RED + "This hotel room belongs to another player.");
                return;
            }
            hq.toggleDoor(b);
        }
    }

    @EventHandler
    public void onPvP(EntityDamageByEntityEvent e) {
        if (!(e.getDamager() instanceof Player a)) return;
        if (!(e.getEntity() instanceof Player v)) return;

        Side as = data.getSide(a.getUniqueId());
        Side vs = data.getSide(v.getUniqueId());

        if (as == Side.COMMUNIST && vs == Side.COMMUNIST) {
            e.setCancelled(true);
            a.sendMessage(ChatColor.RED + "Communists cannot attack each other.");
        }
    }

    @EventHandler
    public void onShop(InventoryClickEvent e) {
        if (!e.getView().getTitle().equals(ChatColor.GOLD + "CivCore Shop")) return;
        e.setCancelled(true);

        if (!(e.getWhoClicked() instanceof Player p)) return;
        ItemStack clicked = e.getCurrentItem();
        if (clicked == null || clicked.getType() == Material.AIR) return;

        Material type = clicked.getType();
        int amount = clicked.getAmount();
        double price = switch (type) {
            case BREAD -> 5;
            case COOKED_BEEF -> 15;
            case COAL -> 10;
            case IRON_INGOT -> 50;
            case STONE_BRICKS -> 6;
            case OAK_LOG -> 8;
            case TORCH -> 4;
            default -> -1;
        };

        if (price < 0) return;

        if (!economy.withdraw(p, price)) {
            p.sendMessage(ChatColor.RED + "Not enough money.");
            return;
        }

        p.getInventory().addItem(new ItemStack(type, amount));
        p.sendMessage(ChatColor.GREEN + "Purchased " + amount + "x " + type.name() + " for $" + price + ".");
        updateScoreboard(p);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage("Only players can use this command.");
            return true;
        }

        UUID id = p.getUniqueId();
        Side side = data.getSide(id);

        switch (command.getName().toLowerCase()) {
            case "join" -> {
                if (args.length < 1) {
                    p.sendMessage(ChatColor.YELLOW + "Use /join capitalist or /join communist");
                    return true;
                }
                Side chosen = Side.from(args[0]);
                if (chosen == Side.NONE) {
                    p.sendMessage(ChatColor.RED + "Invalid side.");
                    return true;
                }
                data.setSide(id, chosen);
                Location room = hq.assignRoom(p, chosen);
                p.teleport(room);
                p.sendTitle(ChatColor.GREEN + chosen.display(), ChatColor.YELLOW + "You joined and received a hotel room.", 10, 80, 20);
                updateScoreboard(p);
                return true;
            }

            case "country" -> {
                p.sendMessage(ChatColor.GOLD + "Country: " + side.display());
                p.sendMessage(ChatColor.YELLOW + "Tax: " + String.format("%.0f", data.getTax(side) * 100) + "%");
                p.sendMessage(ChatColor.GREEN + "Treasury: $" + String.format("%.2f", data.getTreasury(side)));
                p.sendMessage(ChatColor.AQUA + "Parliament: " + parliament.status(side));
                return true;
            }

            case "parliament" -> {
                if (side == Side.NONE) {
                    p.sendMessage(ChatColor.RED + "Join a country first.");
                    return true;
                }
                if (args.length < 1) {
                    p.sendMessage(ChatColor.YELLOW + "/parliament propose <law>");
                    p.sendMessage(ChatColor.YELLOW + "/parliament vote yes/no");
                    return true;
                }
                if (args[0].equalsIgnoreCase("propose")) {
                    if (args.length < 2) {
                        p.sendMessage(ChatColor.RED + "Use /parliament propose <law>");
                        return true;
                    }
                    parliament.propose(p, side, String.join(" ", java.util.Arrays.copyOfRange(args, 1, args.length)));
                    return true;
                }
                if (args[0].equalsIgnoreCase("vote")) {
                    if (args.length < 2) {
                        p.sendMessage(ChatColor.RED + "Use /parliament vote yes/no");
                        return true;
                    }
                    parliament.vote(p, side, args[1].equalsIgnoreCase("yes"));
                    return true;
                }
                return true;
            }

            case "work", "job" -> {
                String jobName = args.length > 0 ? args[0] : "worker";
                economy.work(p, jobName);
                updateScoreboard(p);
                return true;
            }

            case "balance" -> {
                p.sendMessage(ChatColor.GREEN + "Balance: $" + String.format("%.2f", data.getBalance(id)));
                return true;
            }

            case "pay" -> {
                if (args.length < 2) {
                    p.sendMessage(ChatColor.YELLOW + "Use /pay <player> <amount>");
                    return true;
                }
                Player target = Bukkit.getPlayer(args[0]);
                if (target == null) {
                    p.sendMessage(ChatColor.RED + "Player not found.");
                    return true;
                }
                try {
                    economy.pay(p, target, Double.parseDouble(args[1]));
                } catch (NumberFormatException ex) {
                    p.sendMessage(ChatColor.RED + "Invalid amount.");
                }
                return true;
            }

            case "tax" -> {
                if (args.length == 0) {
                    p.sendMessage(ChatColor.YELLOW + side.display() + " tax: " + String.format("%.0f", data.getTax(side) * 100) + "%");
                    return true;
                }
                if (!p.hasPermission("civcore.admin")) {
                    p.sendMessage(ChatColor.RED + "Only admins can set tax in this starter.");
                    return true;
                }
                try {
                    data.setTax(side, Double.parseDouble(args[0]) / 100.0);
                    p.sendMessage(ChatColor.GREEN + "Tax updated.");
                } catch (NumberFormatException ex) {
                    p.sendMessage(ChatColor.RED + "Use /tax <percent>");
                }
                return true;
            }

            case "treasury" -> {
                p.sendMessage(ChatColor.GOLD + "Capitalist Treasury: $" + String.format("%.2f", data.getTreasury(Side.CAPITALIST)));
                p.sendMessage(ChatColor.RED + "Communist Treasury: $" + String.format("%.2f", data.getTreasury(Side.COMMUNIST)));
                return true;
            }

            case "room" -> {
                if (side == Side.NONE) {
                    p.sendMessage(ChatColor.RED + "Join a side first.");
                    return true;
                }
                p.teleport(hq.assignRoom(p, side));
                return true;
            }

            case "hq" -> {
                if (side == Side.NONE) {
                    p.sendMessage(ChatColor.RED + "Join a side first.");
                    return true;
                }
                p.teleport(hq.hqSpawn(side));
                return true;
            }

            case "rules" -> {
                giveRules(p, true);
                return true;
            }

            case "shop" -> {
                openShop(p);
                return true;
            }

            case "civadmin" -> {
                if (!p.hasPermission("civcore.admin")) {
                    p.sendMessage(ChatColor.RED + "No permission.");
                    return true;
                }
                if (args.length > 0 && args[0].equalsIgnoreCase("clear")) {
                    hq.clearOldZonesBatched();
                    p.sendMessage(ChatColor.YELLOW + "Clearing old HQ zones in batches.");
                    return true;
                }
                if (args.length > 0 && args[0].equalsIgnoreCase("rebuild")) {
                    hq.rebuildBatched();
                    p.sendMessage(ChatColor.GREEN + "HQs rebuilt.");
                    return true;
                }
                p.sendMessage(ChatColor.YELLOW + "/civadmin clear");
                p.sendMessage(ChatColor.YELLOW + "/civadmin rebuild");
                return true;
            }
        }

        return true;
    }

    private void openShop(Player p) {
        Inventory inv = Bukkit.createInventory(null, 27, ChatColor.GOLD + "CivCore Shop");
        shopItem(inv, 10, Material.BREAD, 16, "Bread Pack", 5);
        shopItem(inv, 11, Material.COOKED_BEEF, 8, "Steak Pack", 15);
        shopItem(inv, 12, Material.COAL, 16, "Coal Pack", 10);
        shopItem(inv, 14, Material.IRON_INGOT, 4, "Iron Pack", 50);
        shopItem(inv, 15, Material.STONE_BRICKS, 32, "Building Pack", 6);
        shopItem(inv, 16, Material.TORCH, 16, "Light Pack", 4);
        p.openInventory(inv);
    }

    private void shopItem(Inventory inv, int slot, Material mat, int amount, String name, double price) {
        ItemStack item = new ItemStack(mat, amount);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(ChatColor.YELLOW + name);
            meta.setLore(List.of(ChatColor.GRAY + "Price: $" + price));
            item.setItemMeta(meta);
        }
        inv.setItem(slot, item);
    }

    private void giveRules(Player p, boolean force) {
        if (!force) {
            for (ItemStack item : p.getInventory().getContents()) {
                if (item != null && item.getType() == Material.WRITTEN_BOOK && item.hasItemMeta()) {
                    BookMeta meta = (BookMeta) item.getItemMeta();
                    if (meta != null && "CivCore Rulebook".equals(meta.getTitle())) return;
                }
            }
        }

        ItemStack book = new ItemStack(Material.WRITTEN_BOOK);
        BookMeta meta = (BookMeta) book.getItemMeta();
        if (meta == null) return;

        meta.setTitle("CivCore Rulebook");
        meta.setAuthor("CivCore");
        meta.addPage(ChatColor.GOLD + "Rules\n\n" + ChatColor.BLACK + "No griefing.\nNo exploits.\nRespect players.\nFollow staff.\nNo hacked clients.");
        meta.addPage(ChatColor.GOLD + "Countries\n\n" + ChatColor.BLACK + "Use /join capitalist or /join communist.\nCommunists cannot fight each other.\nCapitalists can.");
        meta.addPage(ChatColor.GOLD + "Economy\n\n" + ChatColor.BLACK + "/work earns money.\n/pay transfers money.\nTaxes fund treasuries.\n/shop buys items.");
        meta.addPage(ChatColor.GOLD + "World\n\n" + ChatColor.BLACK + "HQs and rooms are protected.\nYou can build outside HQ zones.\nNether is disabled.");
        book.setItemMeta(meta);
        p.getInventory().addItem(book);
        p.sendMessage(ChatColor.GOLD + "You received the CivCore rulebook.");
    }

    private void updateScoreboards() {
        for (Player p : Bukkit.getOnlinePlayers()) updateScoreboard(p);
    }

    private void updateScoreboard(Player p) {
        ScoreboardManager manager = Bukkit.getScoreboardManager();
        if (manager == null) return;

        Scoreboard board = manager.getNewScoreboard();
        Objective obj = board.registerNewObjective("civcore", "dummy", ChatColor.GOLD + "CivCore");
        obj.setDisplaySlot(DisplaySlot.SIDEBAR);

        Side side = data.getSide(p.getUniqueId());
        obj.getScore(ChatColor.GRAY + "--------------").setScore(6);
        obj.getScore(ChatColor.YELLOW + "Cash: $" + String.format("%.2f", data.getBalance(p.getUniqueId()))).setScore(5);
        obj.getScore(ChatColor.AQUA + "Side: " + side.display()).setScore(4);
        obj.getScore(ChatColor.GREEN + "Tax: " + String.format("%.0f", data.getTax(side) * 100) + "%").setScore(3);
        obj.getScore(ChatColor.GOLD + "Treasury: $" + String.format("%.0f", data.getTreasury(side))).setScore(2);
        obj.getScore(ChatColor.BLUE + "/shop /work").setScore(1);
        p.setScoreboard(board);
    }
}
