package com.civcore.country;

public enum Side {
    CAPITALIST,
    COMMUNIST,
    NONE;

    public static Side from(String input) {
        if (input == null) return NONE;
        if (input.equalsIgnoreCase("capitalist") || input.equalsIgnoreCase("cap")) return CAPITALIST;
        if (input.equalsIgnoreCase("communist") || input.equalsIgnoreCase("com")) return COMMUNIST;
        return NONE;
    }

    public String display() {
        return switch (this) {
            case CAPITALIST -> "Capitalist";
            case COMMUNIST -> "Communist";
            case NONE -> "None";
        };
    }

    public String key() {
        return name().toLowerCase();
    }
}
