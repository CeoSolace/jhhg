package com.civcore.economy;

import com.civcore.country.Side;
import com.civcore.storage.DataStore;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;

public class EconomyService {
    private final DataStore data;

    public EconomyService(DataStore data) {
        this.data = data;
    }

    public double balance(Player player) {
        return data.getBalance(player.getUniqueId());
    }

    public void deposit(Player player, double amount) {
        data.setBalance(player.getUniqueId(), balance(player) + Math.max(0, amount));
    }

    public boolean withdraw(Player player, double amount) {
        if (amount <= 0) return false;
        double current = balance(player);
        if (current < amount) return false;
        data.setBalance(player.getUniqueId(), current - amount);
        return true;
    }

    public void pay(Player from, Player to, double amount) {
        if (amount <= 0) {
            from.sendMessage(ChatColor.RED + "Amount must be positive.");
            return;
        }
        if (!withdraw(from, amount)) {
            from.sendMessage(ChatColor.RED + "Not enough money.");
            return;
        }

        Side side = data.getSide(from.getUniqueId());
        double tax = amount * data.getTax(side);
        double received = amount - tax;

        data.addTreasury(side, tax);
        deposit(to, received);

        from.sendMessage(ChatColor.GREEN + "Paid $" + String.format("%.2f", received) + " to " + to.getName() + " after tax.");
        to.sendMessage(ChatColor.GREEN + "Received $" + String.format("%.2f", received) + " from " + from.getName() + ".");
    }

    public void work(Player player, String jobName) {
        Side side = data.getSide(player.getUniqueId());
        double gross = switch (jobName.toLowerCase()) {
            case "miner" -> 65.0;
            case "farmer" -> 50.0;
            case "factory" -> 60.0;
            case "trader" -> 55.0;
            default -> 45.0;
        };

        double tax = gross * data.getTax(side);
        double net = gross - tax;

        data.addTreasury(side, tax);
        deposit(player, net);
        data.setJob(player.getUniqueId(), jobName);

        player.sendMessage(ChatColor.GREEN + "Worked as " + jobName + " and earned $" + String.format("%.2f", net) + ".");
        if (tax > 0) player.sendMessage(ChatColor.YELLOW + "Tax paid to treasury: $" + String.format("%.2f", tax));
    }
}
