package com.civcore.storage;

import com.civcore.CivCore;
import com.civcore.country.Side;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class DataStore {
    private final CivCore plugin;
    private File playersFile;
    private File countriesFile;
    private YamlConfiguration players;
    private YamlConfiguration countries;

    public DataStore(CivCore plugin) {
        this.plugin = plugin;
    }

    public void load() {
        if (!plugin.getDataFolder().exists()) plugin.getDataFolder().mkdirs();
        playersFile = new File(plugin.getDataFolder(), "players.yml");
        countriesFile = new File(plugin.getDataFolder(), "countries.yml");
        players = YamlConfiguration.loadConfiguration(playersFile);
        countries = YamlConfiguration.loadConfiguration(countriesFile);

        countries.addDefault("capitalist.tax", 0.08);
        countries.addDefault("capitalist.treasury", 0.0);
        countries.addDefault("capitalist.laws", new ArrayList<String>());
        countries.addDefault("communist.tax", 0.35);
        countries.addDefault("communist.treasury", 0.0);
        countries.addDefault("communist.laws", new ArrayList<String>());
        countries.options().copyDefaults(true);
        saveAll();
    }

    public void saveAll() {
        try {
            players.save(playersFile);
            countries.save(countriesFile);
        } catch (IOException e) {
            plugin.getLogger().severe("Failed to save CivCore data");
            e.printStackTrace();
        }
    }

    public Side getSide(UUID uuid) {
        return Side.from(players.getString(uuid + ".side", "NONE"));
    }

    public void setSide(UUID uuid, Side side) {
        players.set(uuid + ".side", side.name());
        saveAll();
    }

    public double getBalance(UUID uuid) {
        return players.getDouble(uuid + ".balance", 250.0);
    }

    public void setBalance(UUID uuid, double balance) {
        players.set(uuid + ".balance", Math.max(0, balance));
        saveAll();
    }

    public int getRoom(UUID uuid) {
        return players.getInt(uuid + ".room", -1);
    }

    public void setRoom(UUID uuid, int room) {
        players.set(uuid + ".room", room);
        saveAll();
    }

    public String getJob(UUID uuid) {
        return players.getString(uuid + ".job", "None");
    }

    public void setJob(UUID uuid, String job) {
        players.set(uuid + ".job", job);
        saveAll();
    }

    public double getTax(Side side) {
        if (side == Side.NONE) return 0.0;
        return countries.getDouble(side.key() + ".tax", side == Side.COMMUNIST ? 0.35 : 0.08);
    }

    public void setTax(Side side, double tax) {
        if (side == Side.NONE) return;
        countries.set(side.key() + ".tax", Math.max(0.0, Math.min(0.75, tax)));
        saveAll();
    }

    public double getTreasury(Side side) {
        if (side == Side.NONE) return 0.0;
        return countries.getDouble(side.key() + ".treasury", 0.0);
    }

    public void addTreasury(Side side, double amount) {
        if (side == Side.NONE) return;
        countries.set(side.key() + ".treasury", getTreasury(side) + amount);
        saveAll();
    }

    public List<String> getLaws(Side side) {
        if (side == Side.NONE) return new ArrayList<>();
        return countries.getStringList(side.key() + ".laws");
    }

    public void addLaw(Side side, String law) {
        if (side == Side.NONE) return;
        List<String> laws = getLaws(side);
        laws.add(law);
        countries.set(side.key() + ".laws", laws);
        saveAll();
    }
}
