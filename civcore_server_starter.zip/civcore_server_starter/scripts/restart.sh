#!/bin/bash
tmux has-session -t mc 2>/dev/null || tmux new -d -s mc
tmux send-keys -t mc "stop" C-m || true
sleep 8
tmux send-keys -t mc "cd /opt/minecraft/server && /opt/minecraft/scripts/start.sh" C-m
