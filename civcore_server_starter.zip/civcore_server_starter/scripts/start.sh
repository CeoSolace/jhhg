#!/bin/bash
cd /opt/minecraft/server
java \
  -Xms3G -Xmx5G \
  -XX:+UseG1GC \
  -XX:+ParallelRefProcEnabled \
  -XX:MaxGCPauseMillis=200 \
  -XX:+UnlockExperimentalVMOptions \
  -XX:+DisableExplicitGC \
  -jar purpur.jar nogui
