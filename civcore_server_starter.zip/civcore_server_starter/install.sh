#!/bin/bash
set -e

BASE="/opt/minecraft"
SERVER="$BASE/server"
PLUGINS="$SERVER/plugins"
SCRIPTS="$BASE/scripts"
CIV="$BASE/civcore-source"

echo "[1] Installing packages..."
apt update
apt install -y openjdk-21-jre wget curl unzip tmux cron ufw gradle

update-alternatives --set java /usr/lib/jvm/java-21-openjdk-amd64/bin/java || true

mkdir -p "$SERVER" "$PLUGINS" "$SCRIPTS" "$BASE/backups"

echo "[2] Downloading Purpur 1.21.1..."
cd "$SERVER"
wget -q https://api.purpurmc.org/v2/purpur/1.21.1/latest/download -O purpur.jar
echo "eula=true" > eula.txt

echo "[3] Writing server.properties..."
cat > "$SERVER/server.properties" <<'EOF'
motd=CivCore | Capitalism vs Communism
server-port=25565
online-mode=true
max-players=25
pvp=true
difficulty=normal
gamemode=survival
spawn-protection=0
view-distance=6
simulation-distance=4
allow-nether=false
enable-command-block=false
enable-rcon=false
sync-chunk-writes=false
network-compression-threshold=256
enforce-secure-profile=false
EOF

echo "[4] Downloading plugin stack..."
cd "$PLUGINS"

wget -q https://download.geysermc.org/v2/projects/geyser/versions/latest/builds/latest/downloads/spigot -O Geyser-Spigot.jar
wget -q https://download.geysermc.org/v2/projects/floodgate/versions/latest/builds/latest/downloads/spigot -O floodgate.jar
wget -q https://hangarcdn.papermc.io/plugins/ViaVersion/ViaVersion/versions/5.9.0-SNAPSHOT%2B974/PAPER/ViaVersion-5.9.0-SNAPSHOT.jar -O ViaVersion.jar || true

echo "[5] Building CivCore..."
cd "$CIV"
gradle clean build
cp build/libs/*.jar "$PLUGINS/CivCore.jar"

echo "[6] Installing backups..."
chmod +x "$BASE/backup.sh"
(crontab -l 2>/dev/null | grep -v "/opt/minecraft/backup.sh" || true; echo "*/15 * * * * /opt/minecraft/backup.sh >/opt/minecraft/backups/backup.log 2>&1") | crontab -

echo "[7] Firewall..."
ufw allow 22/tcp || true
ufw allow 25565/tcp || true
ufw allow 19132/udp || true
ufw --force enable || true

echo "[8] Starting server..."
tmux has-session -t mc 2>/dev/null || tmux new -d -s mc
tmux send-keys -t mc "cd $SERVER && $SCRIPTS/start.sh" C-m

echo "Done."
echo "Java:    YOUR_IP:25565"
echo "Bedrock: YOUR_IP:19132"
echo "Console: tmux attach -t mc"
