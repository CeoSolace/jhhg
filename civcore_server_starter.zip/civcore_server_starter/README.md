# CivCore Nation Simulation Starter Pack

A clean starter ZIP for a Purpur 1.21.1 crossplay Minecraft server with a modular CivCore plugin.

Target VPS:
- Netcup RS 1000 G12
- 4 dedicated AMD EPYC cores
- 8GB DDR5 ECC RAM
- 256GB NVMe
- Java 21
- Purpur 1.21.1

## Install

Upload this folder to `/opt/minecraft` or unzip it there:

```bash
cd /opt/minecraft
chmod +x install.sh update.sh backup.sh scripts/start.sh scripts/restart.sh
sudo ./install.sh
```

## Server commands

```bash
tmux attach -t mc
```

Detach without stopping:

```text
CTRL+B then D
```

## In-game commands

```text
/join capitalist
/join communist
/country
/parliament propose <text>
/parliament vote yes
/parliament vote no
/work miner
/work farmer
/work factory
/balance
/pay <player> <amount>
/tax
/treasury
/room
/hq
/rules
/shop
/civadmin rebuild
```

## Notes

This is a starter foundation, but it is real code, not pseudocode. It includes:
- persistent YAML storage
- country membership
- economy and taxes
- treasury
- parliament proposal/vote system
- HQ/hotel generation using batched block placement
- locked hotel rooms
- rulebook
- scoreboard
- Nether blocking
- basic jobs
- GUI shop
