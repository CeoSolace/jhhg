package com.civcore.database;

import com.civcore.CivCorePlugin;
import com.civcore.util.ConfigLoader;
import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Manages a single SQLite database connection for the plugin. Provides methods
 * to open and close the connection and exposes the underlying JDBC {@link Connection}
 * for executing statements and queries. The database file is located in the
 * plugin's data folder and configured via config.yml.
 */
public class SQLiteManager {
    private final CivCorePlugin plugin;
    private Connection connection;

    public SQLiteManager(CivCorePlugin plugin) {
        this.plugin = plugin;
    }

    /**
     * Opens a connection to the SQLite database configured in config.yml. If the
     * database file does not exist, it will be created. This method must be
     * called before executing any queries.
     *
     * @throws SQLException if an error occurs while connecting to SQLite
     */
    public void openConnection() throws SQLException {
        if (connection != null && !connection.isClosed()) {
            return;
        }
        ConfigLoader config = plugin.getConfigLoader();
        File dataFolder = plugin.getDataFolder();
        if (!dataFolder.exists()) {
            dataFolder.mkdirs();
        }
        String dbName = config.getDatabaseFile();
        File dbFile = new File(dataFolder, dbName);
        String url = "jdbc:sqlite:" + dbFile.getAbsolutePath();
        // Ensure the SQLite JDBC driver is loaded
        try {
            Class.forName("org.sqlite.JDBC");
        } catch (ClassNotFoundException e) {
            plugin.getLogger().warning("SQLite JDBC driver not found. Did you include sqlite-jdbc as a dependency?");
        }
        connection = DriverManager.getConnection(url);
        connection.setAutoCommit(false);
    }

    /**
     * Returns the active SQLite connection. Ensure {@link #openConnection()} has
     * been called before invoking this method.
     *
     * @return The JDBC connection.
     */
    public Connection getConnection() {
        return connection;
    }

    /**
     * Closes the SQLite connection if it is open. Any pending transactions will
     * be committed before closing.
     */
    public void closeConnection() {
        if (connection != null) {
            try {
                if (!connection.getAutoCommit()) {
                    connection.commit();
                }
                connection.close();
            } catch (SQLException e) {
                plugin.getLogger().severe("Error closing SQLite connection: " + e.getMessage());
            }
        }
    }
}