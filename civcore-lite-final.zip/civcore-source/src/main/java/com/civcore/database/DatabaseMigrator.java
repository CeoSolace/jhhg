package com.civcore.database;

import com.civcore.CivCorePlugin;
import com.civcore.util.ConfigLoader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

/**
 * Executes schema migrations against the SQLite database. Migrations ensure
 * required tables exist and insert any necessary seed data. This class is
 * intentionally simple and idempotent: running migrations multiple times will
 * not duplicate data or throw errors.
 */
public class DatabaseMigrator {
    private final CivCorePlugin plugin;

    public DatabaseMigrator(CivCorePlugin plugin) {
        this.plugin = plugin;
    }

    /**
     * Runs all pending migrations. If migrations are disabled in config.yml
     * (database.use-migrations = false), this method will return immediately.
     */
    public void migrate() {
        ConfigLoader config = plugin.getConfigLoader();
        if (!config.isUseMigrations()) {
            plugin.getLogger().info("Migrations are disabled in the configuration.");
            return;
        }
        try {
            Connection conn = plugin.getSQLiteManager().getConnection();
            try (Statement stmt = conn.createStatement()) {
                // Players table
                stmt.executeUpdate("CREATE TABLE IF NOT EXISTS players (" +
                        "uuid TEXT PRIMARY KEY," +
                        "name TEXT NOT NULL," +
                        "country_id INTEGER," +
                        "role_id INTEGER," +
                        "balance REAL DEFAULT 0," +
                    "job TEXT," +
                    "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP" +
                    ");");

                // Countries table
                stmt.executeUpdate("CREATE TABLE IF NOT EXISTS countries (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                        "name TEXT NOT NULL UNIQUE," +
                        "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP" +
                        ");");

                // Roles table
                stmt.executeUpdate("CREATE TABLE IF NOT EXISTS roles (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                        "name TEXT NOT NULL UNIQUE," +
                        "country_id INTEGER NOT NULL," +
                        "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP" +
                        ");");

                // Laws table
                stmt.executeUpdate("CREATE TABLE IF NOT EXISTS laws (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                        "country_id INTEGER NOT NULL," +
                        "title TEXT NOT NULL," +
                        "content TEXT," +
                        "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP" +
                        ");");

                // Proposals table
                stmt.executeUpdate("CREATE TABLE IF NOT EXISTS proposals (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                        "country_id INTEGER," +
                        "player_uuid TEXT," +
                        "title TEXT NOT NULL," +
                        "content TEXT," +
                        "status TEXT," +
                        "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP" +
                        ");");

                // Votes table
                stmt.executeUpdate("CREATE TABLE IF NOT EXISTS votes (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                        "proposal_id INTEGER NOT NULL," +
                        "player_uuid TEXT NOT NULL," +
                        "vote INTEGER NOT NULL," +
                        "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP" +
                        ");");

                // Balances table
                stmt.executeUpdate("CREATE TABLE IF NOT EXISTS balances (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                        "player_uuid TEXT NOT NULL," +
                        "amount REAL DEFAULT 0," +
                        "updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP" +
                        ");");

                // Rooms table
                stmt.executeUpdate("CREATE TABLE IF NOT EXISTS rooms (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                        "country_id INTEGER NOT NULL," +
                        "name TEXT NOT NULL," +
                        "type TEXT," +
                        // Level represents the current tier of the room (0 = empty)
                        "level INTEGER DEFAULT 0," +
                        // UUID of the player who owns this room, null if unowned
                        "owner_uuid TEXT," +
                        // Total amount of money spent on this room (purchase + upgrades)
                        "purchase_total REAL DEFAULT 0," +
                        "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP" +
                        ");");

                // Room upgrades table
                stmt.executeUpdate("CREATE TABLE IF NOT EXISTS room_upgrades (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                        "room_id INTEGER NOT NULL," +
                        "upgrade_name TEXT NOT NULL," +
                        "level INTEGER DEFAULT 0," +
                        "purchased_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP" +
                        ");");

                // Room shop listings table
                stmt.executeUpdate("CREATE TABLE IF NOT EXISTS room_shop_listings (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                        "room_id INTEGER NOT NULL," +
                        "item TEXT NOT NULL," +
                        "price REAL NOT NULL," +
                        "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP" +
                        ");");

                // Jobs table
                stmt.executeUpdate("CREATE TABLE IF NOT EXISTS jobs (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                        "country_id INTEGER," +
                        "name TEXT NOT NULL," +
                        "description TEXT," +
                        "reward REAL DEFAULT 0," +
                        "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP" +
                        ");");
            }

            // Add new columns to the countries table if they do not already exist.
            try (Statement alter = conn.createStatement()) {
                try {
                    alter.executeUpdate("ALTER TABLE countries ADD COLUMN treasury REAL DEFAULT 0");
                } catch (SQLException ignored) {
                    // Column may already exist; ignore error
                }
                try {
                    alter.executeUpdate("ALTER TABLE countries ADD COLUMN tax_percentage REAL DEFAULT 0");
                } catch (SQLException ignored) {
                    // Column may already exist; ignore error
                }
                try {
                    alter.executeUpdate("ALTER TABLE countries ADD COLUMN leader_uuid TEXT");
                } catch (SQLException ignored) {
                    // Column may already exist; ignore error
                }

                // Add job column to players table if it does not exist
                try {
                    alter.executeUpdate("ALTER TABLE players ADD COLUMN job TEXT");
                } catch (SQLException ignored) {
                    // Column may already exist; ignore error
                }

                // Add owner_uuid and purchase_total columns to rooms table if they do not already exist
                try {
                    alter.executeUpdate("ALTER TABLE rooms ADD COLUMN owner_uuid TEXT");
                } catch (SQLException ignored) {
                    // Column may already exist
                }
                try {
                    alter.executeUpdate("ALTER TABLE rooms ADD COLUMN purchase_total REAL DEFAULT 0");
                } catch (SQLException ignored) {
                    // Column may already exist
                }
            }

            // Insert default countries defined in the configuration
            List<String> defaults = config.getDefaultCountries();
            if (defaults != null && !defaults.isEmpty()) {
                String insertSql = "INSERT OR IGNORE INTO countries (name) VALUES (?);";
                try (PreparedStatement ps = conn.prepareStatement(insertSql)) {
                    for (String name : defaults) {
                        ps.setString(1, name);
                        ps.addBatch();
                    }
                    ps.executeBatch();
                }
                // After ensuring countries exist, set their tax percentages from config
                String updateTaxSql = "UPDATE countries SET tax_percentage = ? WHERE name = ?;";
                try (PreparedStatement ps = conn.prepareStatement(updateTaxSql)) {
                    for (String name : defaults) {
                        double tax = 0.0;
                        // Retrieve tax value from config section
                        if (plugin.getConfig().contains("countries." + name + ".tax-percentage")) {
                            tax = plugin.getConfig().getDouble("countries." + name + ".tax-percentage");
                        }
                        ps.setDouble(1, tax);
                        ps.setString(2, name);
                        ps.addBatch();
                    }
                    ps.executeBatch();
                }

                // Insert default rooms defined in the configuration. Each room plot defined
                // under roomPlots.<country> will create an entry in the rooms table with
                // the corresponding country ID. Only inserts new records if none exist for
                // the specified country and plot name.
                try {
                    org.bukkit.configuration.ConfigurationSection roomPlotsSection = plugin.getConfig().getConfigurationSection("roomPlots");
                    if (roomPlotsSection != null) {
                        for (String countryName : roomPlotsSection.getKeys(false)) {
                            // Look up the country ID by name
                            int countryId = -1;
                            try (PreparedStatement cps = conn.prepareStatement("SELECT id FROM countries WHERE name = ?")) {
                                cps.setString(1, countryName);
                                try (ResultSet rs = cps.executeQuery()) {
                                    if (rs.next()) {
                                        countryId = rs.getInt(1);
                                    }
                                }
                            }
                            if (countryId < 0) {
                                continue;
                            }
                            java.util.List<?> plots = roomPlotsSection.getList(countryName);
                            if (plots != null) {
                                int idx = 0;
                                for (Object obj : plots) {
                                    if (obj instanceof java.util.Map) {
                                        java.util.Map<?, ?> map = (java.util.Map<?, ?>) obj;
                                        Object nameObj = map.get("name");
                                        String plotName;
                                        if (nameObj != null) {
                                            plotName = nameObj.toString();
                                        } else {
                                            plotName = "plot" + (idx + 1);
                                        }
                                        try (PreparedStatement ps = conn.prepareStatement(
                                                "INSERT OR IGNORE INTO rooms (country_id, name, level, owner_uuid, purchase_total) VALUES (?, ?, 0, NULL, 0)")) {
                                            ps.setInt(1, countryId);
                                            ps.setString(2, plotName);
                                            ps.executeUpdate();
                                        }
                                        idx++;
                                    }
                                }
                            }
                        }
                    }
                } catch (Exception e) {
                    plugin.getLogger().warning("Failed to seed default rooms: " + e.getMessage());
                }

                // Seed government roles and default laws for each country. Roles ensure
                // every country has a set of standard positions (leader, minister,
                // parliament, staff, citizen). Default laws are applied if not
                // already present. The values are pulled from the configuration
                // section 'laws.defaults'.
                try {
                    org.bukkit.configuration.ConfigurationSection lawDefaultsSection = plugin.getConfig().getConfigurationSection("laws.defaults");
                    java.util.Map<String, Object> lawDefaults = lawDefaultsSection != null ? lawDefaultsSection.getValues(false) : java.util.Collections.emptyMap();
                    String[] roleNames = new String[] {"leader", "minister", "parliament", "staff", "citizen"};
                    for (String countryName : defaults) {
                        // Get country ID
                        int countryId = -1;
                        try (PreparedStatement cps = conn.prepareStatement("SELECT id FROM countries WHERE name = ?")) {
                            cps.setString(1, countryName);
                            try (ResultSet rs = cps.executeQuery()) {
                                if (rs.next()) {
                                    countryId = rs.getInt(1);
                                }
                            }
                        }
                        if (countryId < 0) continue;
                        // Insert roles for this country
                        for (String roleName : roleNames) {
                            try (PreparedStatement rps = conn.prepareStatement(
                                    "INSERT OR IGNORE INTO roles (name, country_id) VALUES (?, ?);");) {
                                rps.setString(1, roleName);
                                rps.setInt(2, countryId);
                                rps.executeUpdate();
                            }
                        }
                        // Insert or update default laws for this country
                        for (java.util.Map.Entry<String, Object> entry : lawDefaults.entrySet()) {
                            String lawType = entry.getKey();
                            Object val = entry.getValue();
                            String valueStr = val != null ? val.toString() : "";
                            try (PreparedStatement lps = conn.prepareStatement(
                                    "INSERT OR REPLACE INTO laws (country_id, title, content) VALUES (?, ?, ?);");) {
                                lps.setInt(1, countryId);
                                lps.setString(2, lawType);
                                lps.setString(3, valueStr);
                                lps.executeUpdate();
                            }
                        }
                    }
                } catch (Exception e) {
                    plugin.getLogger().warning("Failed to seed roles and default laws: " + e.getMessage());
                }
            }
            conn.commit();
            plugin.getLogger().info("Database migration completed successfully.");
        } catch (SQLException e) {
            plugin.getLogger().severe("Error during database migration: " + e.getMessage());
            e.printStackTrace();
        }
    }
}