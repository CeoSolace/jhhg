package com.civcore.command;

import com.civcore.CivCorePlugin;
import com.civcore.cache.PlayerProfile;
import com.civcore.cache.PlayerProfileCache;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.Collections;
import java.util.List;

/**
 * Handles the /job command. Displays the player's currently selected job
 * along with payout and cooldown information from the configuration.
 */
public class JobCommand implements CommandExecutor, TabCompleter {

    private final CivCorePlugin plugin;
    private final PlayerProfileCache profileCache;

    public JobCommand(CivCorePlugin plugin) {
        this.plugin = plugin;
        this.profileCache = plugin.getProfileCache();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "Only players can execute this command.");
            return true;
        }
        Player player = (Player) sender;
        if (!player.hasPermission("civcore.job")) {
            player.sendMessage(ChatColor.RED + "You do not have permission to view your job.");
            return true;
        }
        PlayerProfile profile = profileCache.getProfile(player.getUniqueId(), player.getName());
        String job = profile.getJob();
        if (job == null || job.isEmpty()) {
            player.sendMessage(ChatColor.YELLOW + "You have not selected a job. Use /work to select one.");
            return true;
        }
        // Display job information
        player.sendMessage(ChatColor.AQUA + "--- Your Job ---");
        player.sendMessage(ChatColor.GRAY + "Job: " + ChatColor.WHITE + job);
        // Payouts
        if (plugin.getConfig().contains("jobs." + job + ".payouts")) {
            player.sendMessage(ChatColor.GRAY + "Payouts:");
            for (String key : plugin.getConfig().getConfigurationSection("jobs." + job + ".payouts").getKeys(false)) {
                double value = plugin.getConfig().getDouble("jobs." + job + ".payouts." + key);
                player.sendMessage(ChatColor.DARK_GRAY + " - " + ChatColor.WHITE + key + ChatColor.GRAY + ": " + ChatColor.GOLD + value);
            }
        }
        // Cooldown
        long cooldown = plugin.getConfig().getLong("jobs." + job + ".cooldown", 0);
        player.sendMessage(ChatColor.GRAY + "Cooldown: " + ChatColor.WHITE + cooldown + " seconds");
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        return Collections.emptyList();
    }
}