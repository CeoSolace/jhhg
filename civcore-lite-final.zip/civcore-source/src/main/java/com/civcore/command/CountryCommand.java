package com.civcore.command;

import com.civcore.CivCorePlugin;
import com.civcore.cache.PlayerProfile;
import com.civcore.cache.PlayerProfileCache;
import com.civcore.service.CountryService;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Optional;

/**
 * Handles the /country command and its subcommands: info, treasury, and citizens.
 * Players must belong to a country to view information about it.
 */
public class CountryCommand implements CommandExecutor, TabCompleter {

    private final CivCorePlugin plugin;
    private final CountryService countryService;
    private final PlayerProfileCache profileCache;

    public CountryCommand(CivCorePlugin plugin) {
        this.plugin = plugin;
        this.countryService = plugin.getCountryService();
        this.profileCache = plugin.getProfileCache();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "Only players can execute this command.");
            return true;
        }
        Player player = (Player) sender;
        if (!player.hasPermission("civcore.country")) {
            player.sendMessage(ChatColor.RED + "You do not have permission to use /country commands.");
            return true;
        }
        if (args.length < 1) {
            sendUsage(player, label);
            return true;
        }
        String sub = args[0].toLowerCase(Locale.ROOT);
        // Ensure player is part of a country for info/treasury/citizens commands
        PlayerProfile profile = profileCache.getProfile(player.getUniqueId(), player.getName());
        Integer countryId = profile.getCountryId();
        if (countryId == null) {
            player.sendMessage(ChatColor.RED + "You are not a citizen of any country.");
            return true;
        }
        switch (sub) {
            case "info":
                if (!player.hasPermission("civcore.country.info")) {
                    player.sendMessage(ChatColor.RED + "You do not have permission to view country info.");
                    return true;
                }
                sendInfo(player, countryId);
                return true;
            case "treasury":
                if (!player.hasPermission("civcore.country.treasury")) {
                    player.sendMessage(ChatColor.RED + "You do not have permission to view the treasury.");
                    return true;
                }
                sendTreasury(player, countryId);
                return true;
            case "citizens":
                if (!player.hasPermission("civcore.country.citizens")) {
                    player.sendMessage(ChatColor.RED + "You do not have permission to view citizens.");
                    return true;
                }
                sendCitizens(player, countryId);
                return true;
            default:
                sendUsage(player, label);
                return true;
        }
    }

    private void sendUsage(Player player, String label) {
        player.sendMessage(ChatColor.YELLOW + "Usage: /" + label + " <info|treasury|citizens>");
    }

    private void sendInfo(Player player, int countryId) {
        Optional<String> nameOpt = countryService.getCountry(countryId);
        String name = nameOpt.orElse("Unknown");
        double tax = countryService.getTaxPercentage(countryId);
        double treasury = countryService.getTreasury(countryId);
        player.sendMessage(ChatColor.AQUA + "--- Country Info ---");
        player.sendMessage(ChatColor.GRAY + "Name: " + ChatColor.WHITE + name);
        player.sendMessage(ChatColor.GRAY + "Tax Rate: " + ChatColor.WHITE + String.format("%.2f%%", tax));
        player.sendMessage(ChatColor.GRAY + "Treasury: " + ChatColor.WHITE + String.format("%.2f", treasury));
        List<String> citizens = countryService.getCitizens(countryId);
        player.sendMessage(ChatColor.GRAY + "Citizens: " + ChatColor.WHITE + citizens.size());
    }

    private void sendTreasury(Player player, int countryId) {
        double treasury = countryService.getTreasury(countryId);
        player.sendMessage(ChatColor.AQUA + "--- Country Treasury ---");
        player.sendMessage(ChatColor.GRAY + "Balance: " + ChatColor.WHITE + String.format("%.2f", treasury));
    }

    private void sendCitizens(Player player, int countryId) {
        List<String> citizens = countryService.getCitizens(countryId);
        player.sendMessage(ChatColor.AQUA + "--- Country Citizens ---");
        if (citizens.isEmpty()) {
            player.sendMessage(ChatColor.GRAY + "No citizens found.");
            return;
        }
        String list = String.join(", ", citizens);
        player.sendMessage(ChatColor.GRAY + list);
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            List<String> subs = Arrays.asList("info", "treasury", "citizens");
            List<String> completions = new ArrayList<>();
            String prefix = args[0].toLowerCase(Locale.ROOT);
            for (String s : subs) {
                if (s.startsWith(prefix)) completions.add(s);
            }
            return completions;
        }
        return java.util.Collections.emptyList();
    }
}