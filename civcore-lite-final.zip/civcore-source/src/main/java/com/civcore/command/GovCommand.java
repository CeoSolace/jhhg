package com.civcore.command;

import com.civcore.CivCorePlugin;
import com.civcore.cache.PlayerProfile;
import com.civcore.cache.PlayerProfileCache;
import com.civcore.service.GovernmentService;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/**
 * Handles the /gov command and its subcommands. This command exposes
 * administrative functions for assigning and removing government roles
 * within a player's country as well as listing the current role roster.
 * Only players may execute these commands and appropriate permissions are
 * required for each subcommand.
 */
public class GovCommand implements CommandExecutor, TabCompleter {

    private final CivCorePlugin plugin;
    private final GovernmentService governmentService;
    private final PlayerProfileCache profileCache;
    private final List<String> subcommands = Arrays.asList("appoint", "remove", "roles");
    private final List<String> roleNames = Arrays.asList("leader", "minister", "parliament", "staff", "citizen");

    public GovCommand(CivCorePlugin plugin) {
        this.plugin = plugin;
        this.governmentService = plugin.getGovernmentService();
        this.profileCache = plugin.getProfileCache();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "Only players can execute this command.");
            return true;
        }
        Player player = (Player) sender;
        if (!player.hasPermission("civcore.gov")) {
            player.sendMessage(ChatColor.RED + "You do not have permission to use /gov commands.");
            return true;
        }
        if (args.length < 1) {
            sendUsage(player, label);
            return true;
        }
        String sub = args[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "appoint":
                if (!player.hasPermission("civcore.gov.appoint")) {
                    player.sendMessage(ChatColor.RED + "You do not have permission to appoint roles.");
                    return true;
                }
                if (args.length < 3) {
                    player.sendMessage(ChatColor.YELLOW + "Usage: /" + label + " appoint <player> <role>");
                    return true;
                }
                return handleAppoint(player, args[1], args[2]);
            case "remove":
                if (!player.hasPermission("civcore.gov.remove")) {
                    player.sendMessage(ChatColor.RED + "You do not have permission to remove roles.");
                    return true;
                }
                if (args.length < 2) {
                    player.sendMessage(ChatColor.YELLOW + "Usage: /" + label + " remove <player>");
                    return true;
                }
                return handleRemove(player, args[1]);
            case "roles":
                if (!player.hasPermission("civcore.gov.roles")) {
                    player.sendMessage(ChatColor.RED + "You do not have permission to view roles.");
                    return true;
                }
                return handleRoles(player);
            default:
                sendUsage(player, label);
                return true;
        }
    }

    private boolean handleAppoint(Player issuer, String targetName, String role) {
        // Normalize role name
        String roleName = role.toLowerCase(Locale.ROOT);
        if (!roleNames.contains(roleName)) {
            issuer.sendMessage(ChatColor.RED + "Unknown role: " + role);
            issuer.sendMessage(ChatColor.RED + "Valid roles: leader, minister, parliament, staff, citizen.");
            return true;
        }
        OfflinePlayer targetPlayer = Bukkit.getOfflinePlayer(targetName);
        if (targetPlayer == null || targetPlayer.getUniqueId() == null) {
            issuer.sendMessage(ChatColor.RED + "Player not found: " + targetName);
            return true;
        }
        UUID issuerId = issuer.getUniqueId();
        UUID targetId = targetPlayer.getUniqueId();
        boolean success = governmentService.appointRole(issuerId, targetId, roleName);
        if (success) {
            issuer.sendMessage(ChatColor.GREEN + "Successfully appointed " + ChatColor.AQUA + targetName + ChatColor.GREEN + " to role " + ChatColor.AQUA + roleName + ChatColor.GREEN + ".");
        } else {
            issuer.sendMessage(ChatColor.RED + "Failed to appoint player. You may not have permission, the role may be invalid or the player is in a different country.");
        }
        return true;
    }

    private boolean handleRemove(Player issuer, String targetName) {
        OfflinePlayer targetPlayer = Bukkit.getOfflinePlayer(targetName);
        if (targetPlayer == null || targetPlayer.getUniqueId() == null) {
            issuer.sendMessage(ChatColor.RED + "Player not found: " + targetName);
            return true;
        }
        UUID issuerId = issuer.getUniqueId();
        UUID targetId = targetPlayer.getUniqueId();
        boolean success = governmentService.removeRole(issuerId, targetId);
        if (success) {
            issuer.sendMessage(ChatColor.GREEN + "Successfully removed role from " + ChatColor.AQUA + targetName + ChatColor.GREEN + ".");
        } else {
            issuer.sendMessage(ChatColor.RED + "Failed to remove role. Only leaders may remove roles and you must be in the same country.");
        }
        return true;
    }

    private boolean handleRoles(Player player) {
        // Determine player's country
        PlayerProfile profile = profileCache.getProfile(player.getUniqueId(), player.getName());
        Integer countryId = profile.getCountryId();
        if (countryId == null) {
            player.sendMessage(ChatColor.RED + "You are not a citizen of any country.");
            return true;
        }
        Map<String, List<UUID>> roles = governmentService.listRoles(countryId);
        player.sendMessage(ChatColor.AQUA + "--- Government Roles ---");
        if (roles.isEmpty()) {
            player.sendMessage(ChatColor.GRAY + "No roles defined.");
            return true;
        }
        for (Map.Entry<String, List<UUID>> entry : roles.entrySet()) {
            String role = entry.getKey();
            List<UUID> uuids = entry.getValue();
            if (uuids.isEmpty()) {
                player.sendMessage(ChatColor.GRAY + role + ": " + ChatColor.WHITE + "None");
            } else {
                List<String> names = new ArrayList<>();
                for (UUID id : uuids) {
                    OfflinePlayer op = Bukkit.getOfflinePlayer(id);
                    String name = op != null ? op.getName() : id.toString();
                    if (name != null) names.add(name);
                }
                String list = String.join(", ", names);
                player.sendMessage(ChatColor.GRAY + role + ": " + ChatColor.WHITE + list);
            }
        }
        return true;
    }

    private void sendUsage(Player player, String label) {
        player.sendMessage(ChatColor.YELLOW + "Usage: /" + label + " <appoint|remove|roles>");
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> completions = new ArrayList<>();
        if (!(sender instanceof Player)) {
            return completions;
        }
        if (args.length == 1) {
            String prefix = args[0].toLowerCase(Locale.ROOT);
            for (String sub : subcommands) {
                if (sub.startsWith(prefix)) {
                    completions.add(sub);
                }
            }
        } else if (args.length == 2) {
            String sub = args[0].toLowerCase(Locale.ROOT);
            if (sub.equals("appoint") || sub.equals("remove")) {
                String prefix = args[1].toLowerCase(Locale.ROOT);
                for (Player p : Bukkit.getOnlinePlayers()) {
                    String name = p.getName();
                    if (name.toLowerCase(Locale.ROOT).startsWith(prefix)) {
                        completions.add(name);
                    }
                }
            }
        } else if (args.length == 3) {
            String sub = args[0].toLowerCase(Locale.ROOT);
            if (sub.equals("appoint")) {
                String prefix = args[2].toLowerCase(Locale.ROOT);
                for (String role : roleNames) {
                    if (role.startsWith(prefix)) {
                        completions.add(role);
                    }
                }
            }
        }
        return completions;
    }
}