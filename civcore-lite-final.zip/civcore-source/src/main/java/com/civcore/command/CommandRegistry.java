package com.civcore.command;

import com.civcore.CivCorePlugin;
import org.bukkit.command.PluginCommand;

/**
 * Registers command executors and tab completers for the plugin. Centralizing
 * command registration here makes it easier to manage commands as the plugin
 * grows.
 */
public class CommandRegistry {
    private final CivCorePlugin plugin;

    public CommandRegistry(CivCorePlugin plugin) {
        this.plugin = plugin;
    }

    /**
     * Registers all commands with the Bukkit command map. Each command should be
     * defined in plugin.yml. Executors handle the logic for subcommands.
     */
    public void registerCommands() {
        // Register primary /civcore command
        PluginCommand civcoreCommand = plugin.getCommand("civcore");
        if (civcoreCommand != null) {
            CivCoreCommand executor = new CivCoreCommand(plugin);
            civcoreCommand.setExecutor(executor);
            civcoreCommand.setTabCompleter(executor);
        } else {
            plugin.getLogger().warning("Could not register /civcore command; check plugin.yml.");
        }

        // Register /join command
        PluginCommand join = plugin.getCommand("join");
        if (join != null) {
            JoinCommand executor = new JoinCommand(plugin);
            join.setExecutor(executor);
            join.setTabCompleter(executor);
        } else {
            plugin.getLogger().warning("Could not register /join command; check plugin.yml.");
        }

        // Register /country command
        PluginCommand country = plugin.getCommand("country");
        if (country != null) {
            CountryCommand executor = new CountryCommand(plugin);
            country.setExecutor(executor);
            country.setTabCompleter(executor);
        } else {
            plugin.getLogger().warning("Could not register /country command; check plugin.yml.");
        }

        // Register /balance command
        PluginCommand balance = plugin.getCommand("balance");
        if (balance != null) {
            BalanceCommand executor = new BalanceCommand(plugin);
            balance.setExecutor(executor);
            balance.setTabCompleter(executor);
        } else {
            plugin.getLogger().warning("Could not register /balance command; check plugin.yml.");
        }

        // Register /pay command
        PluginCommand pay = plugin.getCommand("pay");
        if (pay != null) {
            PayCommand executor = new PayCommand(plugin);
            pay.setExecutor(executor);
            pay.setTabCompleter(executor);
        } else {
            plugin.getLogger().warning("Could not register /pay command; check plugin.yml.");
        }

        // Register /work command
        PluginCommand work = plugin.getCommand("work");
        if (work != null) {
            WorkCommand executor = new WorkCommand(plugin);
            work.setExecutor(executor);
            work.setTabCompleter(executor);
        } else {
            plugin.getLogger().warning("Could not register /work command; check plugin.yml.");
        }

        // Register /job command
        PluginCommand job = plugin.getCommand("job");
        if (job != null) {
            JobCommand executor = new JobCommand(plugin);
            job.setExecutor(executor);
            job.setTabCompleter(executor);
        } else {
            plugin.getLogger().warning("Could not register /job command; check plugin.yml.");
        }

        // Register /shop command
        PluginCommand shop = plugin.getCommand("shop");
        if (shop != null) {
            ShopCommand executor = new ShopCommand(plugin);
            shop.setExecutor(executor);
            shop.setTabCompleter(executor);
        } else {
            plugin.getLogger().warning("Could not register /shop command; check plugin.yml.");
        }

        // Register /room command
        PluginCommand room = plugin.getCommand("room");
        if (room != null) {
            RoomCommand executor = new RoomCommand(plugin);
            room.setExecutor(executor);
            room.setTabCompleter(executor);
        } else {
            plugin.getLogger().warning("Could not register /room command; check plugin.yml.");
        }

        // Register /gov command
        PluginCommand gov = plugin.getCommand("gov");
        if (gov != null) {
            GovCommand executor = new GovCommand(plugin);
            gov.setExecutor(executor);
            gov.setTabCompleter(executor);
        } else {
            plugin.getLogger().warning("Could not register /gov command; check plugin.yml.");
        }

        // Register /parliament command
        PluginCommand parliament = plugin.getCommand("parliament");
        if (parliament != null) {
            ParliamentCommand executor = new ParliamentCommand(plugin);
            parliament.setExecutor(executor);
            parliament.setTabCompleter(executor);
        } else {
            plugin.getLogger().warning("Could not register /parliament command; check plugin.yml.");
        }

        // Register /laws command
        PluginCommand laws = plugin.getCommand("laws");
        if (laws != null) {
            LawsCommand executor = new LawsCommand(plugin);
            laws.setExecutor(executor);
            laws.setTabCompleter(executor);
        } else {
            plugin.getLogger().warning("Could not register /laws command; check plugin.yml.");
        }

        // Register /roomshop command
        PluginCommand roomshop = plugin.getCommand("roomshop");
        if (roomshop != null) {
            RoomShopCommand executor = new RoomShopCommand(plugin);
            roomshop.setExecutor(executor);
            roomshop.setTabCompleter(executor);
        } else {
            plugin.getLogger().warning("Could not register /roomshop command; check plugin.yml.");
        }

        // Register /hq command
        PluginCommand hq = plugin.getCommand("hq");
        if (hq != null) {
            HQCommand executor = new HQCommand(plugin);
            hq.setExecutor(executor);
            hq.setTabCompleter(executor);
        } else {
            plugin.getLogger().warning("Could not register /hq command; check plugin.yml.");
        }

        // Register /rules command
        PluginCommand rules = plugin.getCommand("rules");
        if (rules != null) {
            RulesCommand executor = new RulesCommand(plugin);
            rules.setExecutor(executor);
        } else {
            plugin.getLogger().warning("Could not register /rules command; check plugin.yml.");
        }
    }
}