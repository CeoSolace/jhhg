package com.civcore.command;

import com.civcore.CivCorePlugin;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

/**
 * Handles the /shop command which opens a GUI inventory allowing players to
 * buy and sell configured items. Prices are defined in the configuration.
 */
public class ShopCommand implements CommandExecutor, TabCompleter {

    private final CivCorePlugin plugin;
    // Title for the shop inventory. Colours stripped in click listener.
    public static final String SHOP_TITLE = ChatColor.BLUE + "Shop";

    public ShopCommand(CivCorePlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "Only players can use the shop.");
            return true;
        }
        Player player = (Player) sender;
        if (!player.hasPermission("civcore.shop")) {
            player.sendMessage(ChatColor.RED + "You do not have permission to use the shop.");
            return true;
        }
        openShop(player);
        return true;
    }

    private void openShop(Player player) {
        ConfigurationSection itemsSection = plugin.getConfig().getConfigurationSection("shop.items");
        if (itemsSection == null) {
            player.sendMessage(ChatColor.RED + "No items are configured for the shop.");
            return;
        }
        int itemCount = itemsSection.getKeys(false).size();
        int size = ((itemCount - 1) / 9 + 1) * 9;
        Inventory inv = Bukkit.createInventory(null, size, SHOP_TITLE);
        int slot = 0;
        for (String key : itemsSection.getKeys(false)) {
            Material material = Material.matchMaterial(key);
            if (material == null) {
                plugin.getLogger().warning("Invalid material in shop config: " + key);
                continue;
            }
            ItemStack item = new ItemStack(material, 1);
            ItemMeta meta = item.getItemMeta();
            if (meta != null) {
                meta.setDisplayName(ChatColor.WHITE + key.replace('_', ' ').toLowerCase());
                List<String> lore = new ArrayList<>();
                double buy = itemsSection.getDouble(key + ".buy", 0.0);
                double sell = itemsSection.getDouble(key + ".sell", 0.0);
                lore.add(ChatColor.YELLOW + "Buy: " + ChatColor.GOLD + String.format("%.2f", buy));
                lore.add(ChatColor.YELLOW + "Sell: " + ChatColor.GOLD + String.format("%.2f", sell));
                meta.setLore(lore);
                item.setItemMeta(meta);
            }
            inv.setItem(slot++, item);
        }
        player.openInventory(inv);
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        return new ArrayList<>();
    }
}