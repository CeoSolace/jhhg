package com.civcore.command;

import com.civcore.CivCorePlugin;
import com.civcore.cache.PlayerProfile;
import com.civcore.cache.PlayerProfileCache;
import com.civcore.service.GovernmentService;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

/**
 * Handles the /parliament command which allows eligible players to propose
 * new laws and vote on active proposals. Proposals must specify a law
 * type and value along with an optional description. Votes may be cast
 * as yes or no.
 */
public class ParliamentCommand implements CommandExecutor, TabCompleter {
    private final CivCorePlugin plugin;
    private final GovernmentService governmentService;
    private final PlayerProfileCache profileCache;
    private final List<String> subcommands = Arrays.asList("propose", "vote");
    private final List<String> lawTypes = Arrays.asList(
            "TAX_RATE", "PVP_ENABLED", "JOB_MULTIPLIER", "ROOM_PRICE_MULTIPLIER", "ROOM_UPGRADE_MULTIPLIER");

    public ParliamentCommand(CivCorePlugin plugin) {
        this.plugin = plugin;
        this.governmentService = plugin.getGovernmentService();
        this.profileCache = plugin.getProfileCache();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "Only players can execute this command.");
            return true;
        }
        Player player = (Player) sender;
        if (!player.hasPermission("civcore.parliament")) {
            player.sendMessage(ChatColor.RED + "You do not have permission to use /parliament commands.");
            return true;
        }
        if (args.length < 1) {
            sendUsage(player, label);
            return true;
        }
        String sub = args[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "propose":
                if (!player.hasPermission("civcore.parliament.propose")) {
                    player.sendMessage(ChatColor.RED + "You do not have permission to propose laws.");
                    return true;
                }
                if (args.length < 3) {
                    player.sendMessage(ChatColor.YELLOW + "Usage: /" + label + " propose <type> <value> [description]");
                    return true;
                }
                return handlePropose(player, args);
            case "vote":
                if (!player.hasPermission("civcore.parliament.vote")) {
                    player.sendMessage(ChatColor.RED + "You do not have permission to vote on proposals.");
                    return true;
                }
                if (args.length < 2) {
                    player.sendMessage(ChatColor.YELLOW + "Usage: /" + label + " vote <yes|no>");
                    return true;
                }
                return handleVote(player, args[1]);
            default:
                sendUsage(player, label);
                return true;
        }
    }

    private boolean handlePropose(Player player, String[] args) {
        String type = args[1].toUpperCase(Locale.ROOT);
        if (!lawTypes.contains(type)) {
            player.sendMessage(ChatColor.RED + "Unknown law type: " + type + ". Valid types: " + String.join(", ", lawTypes));
            return true;
        }
        String value = args[2];
        // Validate numeric or boolean values depending on law type
        if (type.equals("PVP_ENABLED")) {
            String lower = value.toLowerCase(Locale.ROOT);
            if (!(lower.equals("true") || lower.equals("false"))) {
                player.sendMessage(ChatColor.RED + "PVP_ENABLED must be true or false.");
                return true;
            }
        } else {
            // Ensure numeric
            try {
                Double.parseDouble(value);
            } catch (NumberFormatException ex) {
                player.sendMessage(ChatColor.RED + "Value for " + type + " must be a number.");
                return true;
            }
        }
        String description = "";
        if (args.length > 3) {
            // Build description from remaining args
            StringBuilder sb = new StringBuilder();
            for (int i = 3; i < args.length; i++) {
                sb.append(args[i]);
                if (i < args.length - 1) sb.append(" ");
            }
            description = sb.toString();
        }
        int id = governmentService.propose(player.getUniqueId(), type, value, description);
        if (id < 0) {
            player.sendMessage(ChatColor.RED + "Failed to create proposal. Ensure you have the correct role and there are no active proposals.");
        } else {
            long duration = plugin.getConfig().getLong("laws.proposal-duration", 300);
            player.sendMessage(ChatColor.GREEN + "Proposal created with ID " + id + ". Voting will remain open for " + duration + " seconds.");
        }
        return true;
    }

    private boolean handleVote(Player player, String voteArg) {
        boolean yes;
        String lower = voteArg.toLowerCase(Locale.ROOT);
        if (lower.equals("yes") || lower.equals("y")) {
            yes = true;
        } else if (lower.equals("no") || lower.equals("n")) {
            yes = false;
        } else {
            player.sendMessage(ChatColor.RED + "Invalid vote. Use yes or no.");
            return true;
        }
        boolean success = governmentService.vote(player.getUniqueId(), yes);
        if (success) {
            player.sendMessage(ChatColor.GREEN + "Your vote has been recorded.");
        } else {
            player.sendMessage(ChatColor.RED + "Failed to record vote. Ensure there is an active proposal and you have not already voted.");
        }
        return true;
    }

    private void sendUsage(Player player, String label) {
        player.sendMessage(ChatColor.YELLOW + "Usage: /" + label + " <propose|vote>");
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> completions = new ArrayList<>();
        if (!(sender instanceof Player)) {
            return completions;
        }
        if (args.length == 1) {
            String prefix = args[0].toLowerCase(Locale.ROOT);
            for (String sub : subcommands) {
                if (sub.startsWith(prefix)) {
                    completions.add(sub);
                }
            }
        } else if (args.length == 2) {
            String sub = args[0].toLowerCase(Locale.ROOT);
            if (sub.equals("propose")) {
                String prefix = args[1].toUpperCase(Locale.ROOT);
                for (String type : lawTypes) {
                    if (type.startsWith(prefix)) {
                        completions.add(type);
                    }
                }
            } else if (sub.equals("vote")) {
                String prefix = args[1].toLowerCase(Locale.ROOT);
                if ("yes".startsWith(prefix)) completions.add("yes");
                if ("no".startsWith(prefix)) completions.add("no");
            }
        }
        return completions;
    }
}