package com.civcore.command;

import com.civcore.CivCorePlugin;
import com.civcore.service.RulesService;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

/**
 * Handles the /rules command which opens the server rulebook for the player.
 * If the player does not already have a rulebook, one will be given. This
 * command is available to all players by default.
 */
public class RulesCommand implements CommandExecutor {
    private final CivCorePlugin plugin;
    private final RulesService rulesService;

    public RulesCommand(CivCorePlugin plugin) {
        this.plugin = plugin;
        this.rulesService = plugin.getRulesService();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("This command can only be used by players.");
            return true;
        }
        Player player = (Player) sender;
        rulesService.openRulebook(player);
        return true;
    }
}