package com.civcore.command;

import com.civcore.CivCorePlugin;
import com.civcore.cache.PlayerProfile;
import com.civcore.cache.PlayerProfileCache;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

/**
 * Handles the /work command which allows a player to select one of the
 * predefined jobs: miner, farmer, factory or trader. The chosen job is
 * persisted on the player's profile and will be used by job-related event
 * listeners to determine payouts.
 */
public class WorkCommand implements CommandExecutor, TabCompleter {

    private final CivCorePlugin plugin;
    private final PlayerProfileCache profileCache;
    private final List<String> jobs = Arrays.asList("miner", "farmer", "factory", "trader");

    public WorkCommand(CivCorePlugin plugin) {
        this.plugin = plugin;
        this.profileCache = plugin.getProfileCache();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "Only players can execute this command.");
            return true;
        }
        Player player = (Player) sender;
        if (!player.hasPermission("civcore.work")) {
            player.sendMessage(ChatColor.RED + "You do not have permission to choose a job.");
            return true;
        }
        if (args.length < 1) {
            player.sendMessage(ChatColor.YELLOW + "Usage: /" + label + " <miner|farmer|factory|trader>");
            return true;
        }
        String requestedJob = args[0].toLowerCase(Locale.ROOT);
        if (!jobs.contains(requestedJob)) {
            player.sendMessage(ChatColor.RED + "Unknown job: " + requestedJob + ". Valid jobs: miner, farmer, factory, trader.");
            return true;
        }
        PlayerProfile profile = profileCache.getProfile(player.getUniqueId(), player.getName());
        profile.setJob(requestedJob);
        // Persist asynchronously
        profileCache.saveProfile(profile);
        player.sendMessage(ChatColor.GREEN + "You have selected the " + ChatColor.AQUA + requestedJob + ChatColor.GREEN + " job.");
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> completions = new ArrayList<>();
        if (args.length == 1) {
            String prefix = args[0].toLowerCase(Locale.ROOT);
            for (String job : jobs) {
                if (job.startsWith(prefix)) {
                    completions.add(job);
                }
            }
        }
        return completions;
    }
}