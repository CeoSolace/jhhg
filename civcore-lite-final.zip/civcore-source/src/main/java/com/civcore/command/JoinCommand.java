package com.civcore.command;

import com.civcore.CivCorePlugin;
import com.civcore.cache.PlayerProfile;
import com.civcore.cache.PlayerProfileCache;
import com.civcore.service.CountryService;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Optional;

/**
 * Handles the /join command, allowing players to join a country. A player
 * may only belong to one country at a time.
 */
public class JoinCommand implements CommandExecutor, TabCompleter {

    private final CivCorePlugin plugin;
    private final CountryService countryService;
    private final PlayerProfileCache profileCache;

    public JoinCommand(CivCorePlugin plugin) {
        this.plugin = plugin;
        this.countryService = plugin.getCountryService();
        this.profileCache = plugin.getProfileCache();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "Only players can execute this command.");
            return true;
        }
        Player player = (Player) sender;
        if (!player.hasPermission("civcore.join")) {
            player.sendMessage(ChatColor.RED + "You do not have permission to join a country.");
            return true;
        }
        if (args.length < 1) {
            player.sendMessage(ChatColor.YELLOW + "Usage: /" + label + " <country>");
            return true;
        }
        String targetName = args[0].toLowerCase(Locale.ROOT);
        Optional<Integer> idOpt = countryService.getCountryIdByName(targetName);
        if (!idOpt.isPresent()) {
            player.sendMessage(ChatColor.RED + "Country not found: " + targetName);
            return true;
        }
        // Check if already in a country
        PlayerProfile profile = profileCache.getProfile(player.getUniqueId(), player.getName());
        if (profile.getCountryId() != null) {
            player.sendMessage(ChatColor.RED + "You are already a citizen of a country.");
            return true;
        }
        int countryId = idOpt.get();
        countryService.assignPlayer(player.getUniqueId(), countryId);
        player.sendMessage(ChatColor.GREEN + "You have joined the country: " + ChatColor.AQUA + targetName);
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> completions = new ArrayList<>();
        if (args.length == 1) {
            String prefix = args[0].toLowerCase(Locale.ROOT);
            for (String name : countryService.listCountries()) {
                if (name.toLowerCase(Locale.ROOT).startsWith(prefix)) {
                    completions.add(name);
                }
            }
        }
        return completions;
    }
}