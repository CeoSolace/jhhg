package com.civcore.command;

import com.civcore.CivCorePlugin;
import com.civcore.service.CountryService;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;
import java.util.*;

/**
 * Handles /hq commands related to headquarters generation and information.
 * Generation builds compact HQ hubs at configured origins for each country.
 * A generate command must be confirmed before running to avoid accidental
 * regeneration. Generation status is tracked per country in the plugin.
 */
public class HQCommand implements CommandExecutor, TabCompleter {
    private final CivCorePlugin plugin;
    private final CountryService countryService;

    public HQCommand(CivCorePlugin plugin) {
        this.plugin = plugin;
        this.countryService = plugin.getCountryService();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            sender.sendMessage(ChatColor.YELLOW + "Usage: /" + label + " <generate|generate confirm|info>");
            return true;
        }
        String sub = args[0].toLowerCase();
        switch (sub) {
            case "generate":
                return handleGenerate(sender, args);
            case "info":
                return handleInfo(sender);
            default:
                sender.sendMessage(ChatColor.YELLOW + "Unknown subcommand. Usage: /" + label + " <generate|generate confirm|info>");
                return true;
        }
    }

    private boolean handleGenerate(CommandSender sender, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "Only players may run this command.");
            return true;
        }
        Player player = (Player) sender;
        if (!player.hasPermission("civcore.hq.generate")) {
            player.sendMessage(ChatColor.RED + "You do not have permission to generate HQs.");
            return true;
        }
        // If already pending confirmation
        if (plugin.isHqGenerationPending()) {
            if (args.length > 1 && args[1].equalsIgnoreCase("confirm")) {
                // Proceed with generation
                plugin.setHqGenerationPending(false);
                player.sendMessage(ChatColor.GREEN + "Generating headquarters. This may take a few moments...");
                generateAllHqs();
            } else {
                player.sendMessage(ChatColor.YELLOW + "A generation is already pending confirmation. Use /hq generate confirm to proceed.");
            }
            return true;
        }
        // If first invocation, set pending flag and prompt confirmation
        plugin.setHqGenerationPending(true);
        player.sendMessage(ChatColor.YELLOW + "You are about to generate all headquarters. This will overwrite existing structures. Run /hq generate confirm to continue.");
        return true;
    }

    private boolean handleInfo(CommandSender sender) {
        StringBuilder sb = new StringBuilder();
        sb.append(ChatColor.AQUA).append("Headquarters status:");
        for (String countryName : plugin.getConfig().getConfigurationSection("hq").getKeys(false)) {
            int cid = countryService.getCountryIdByName(countryName).orElse(-1);
            boolean generated = plugin.isHqGenerated(cid);
            sb.append("\n - ").append(countryName).append(": ")
              .append(generated ? ChatColor.GREEN + "Generated" : ChatColor.RED + "Not generated");
        }
        sender.sendMessage(sb.toString());
        return true;
    }

    /**
     * Generates headquarters for all countries defined in the configuration. This
     * method reads the 'hq' section to find origins and uses a {@link BukkitRunnable}
     * to batch block placements. Each headquarters will be built sequentially.
     */
    private void generateAllHqs() {
        Map<String, Object> hqSection = plugin.getConfig().getConfigurationSection("hq").getValues(false);
        Iterator<String> iterator = hqSection.keySet().iterator();
        buildNextHQ(iterator);
    }

    private void buildNextHQ(Iterator<String> iterator) {
        if (!iterator.hasNext()) {
            return;
        }
        String countryName = iterator.next();
        // Fetch origin
        org.bukkit.configuration.ConfigurationSection countrySec = plugin.getConfig().getConfigurationSection("hq." + countryName + ".origin");
        if (countrySec == null) {
            plugin.getLogger().warning("No HQ origin defined for " + countryName);
            buildNextHQ(iterator);
            return;
        }
        String worldName = countrySec.getString("world", "world");
        int x = countrySec.getInt("x", 0);
        int y = countrySec.getInt("y", 64);
        int z = countrySec.getInt("z", 0);
        World world = Bukkit.getWorld(worldName);
        if (world == null) {
            plugin.getLogger().warning("World " + worldName + " not found for HQ " + countryName);
            buildNextHQ(iterator);
            return;
        }
        int countryId = countryService.getCountryIdByName(countryName).orElse(-1);
        if (countryId <= 0) {
            plugin.getLogger().warning("Country " + countryName + " not registered. Skipping HQ generation.");
            buildNextHQ(iterator);
            return;
        }
        // If already generated, skip
        if (plugin.isHqGenerated(countryId)) {
            buildNextHQ(iterator);
            return;
        }
        // Determine simple structure: 9x1x9 platform and central pillar
        final int size = 9;
        final List<Vector> blocks = new ArrayList<>();
        final int half = size / 2;
        // Platform at y-level
        for (int dx = -half; dx <= half; dx++) {
            for (int dz = -half; dz <= half; dz++) {
                blocks.add(new Vector(x + dx, y, z + dz));
            }
        }
        // Pillar at centre (y+1 to y+3)
        for (int dy = 1; dy <= 3; dy++) {
            blocks.add(new Vector(x, y + dy, z));
        }
        // Create runnable to place blocks in batches
        new BukkitRunnable() {
            int index = 0;
            @Override
            public void run() {
                int placed = 0;
                while (index < blocks.size() && placed < 1500) {
                    Vector v = blocks.get(index++);
                    world.getBlockAt(v.getBlockX(), v.getBlockY(), v.getBlockZ()).setType(org.bukkit.Material.STONE);
                    placed++;
                }
                if (index >= blocks.size()) {
                    // Place labeled signs to designate zones on the HQ after platform is built
                    placeZoneSigns(world, x, y, z, half);
                    // Mark as generated
                    plugin.setHqGenerated(countryId, true);
                    cancel();
                    // Build next HQ after finishing
                    buildNextHQ(iterator);
                }
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    /**
     * Places simple signs around the headquarters platform to label different
     * areas. This method runs on the main thread and should be invoked
     * after the platform has been created. It positions signs at the edges
     * of the platform relative to the origin and writes text for each zone.
     *
     * @param world The world in which to place the signs
     * @param x     X coordinate of the HQ origin
     * @param y     Y coordinate of the HQ ground level
     * @param z     Z coordinate of the HQ origin
     * @param half  Half the size of the platform (platform extends from -half to +half)
     */
    private void placeZoneSigns(World world, int x, int y, int z, int half) {
        // Define positions and texts for various zones
        class ZoneSign {
            final int dx; final int dz; final String[] lines;
            ZoneSign(int dx, int dz, String[] lines) { this.dx = dx; this.dz = dz; this.lines = lines; }
        }
        List<ZoneSign> signs = new ArrayList<>();
        // Parliament at east side
        signs.add(new ZoneSign(half + 1, 0, new String[]{ChatColor.DARK_PURPLE + "Parliament", "", "", ""}));
        // Government office at west side
        signs.add(new ZoneSign(-(half + 1), 0, new String[]{ChatColor.DARK_GREEN + "Government", "Office", "", ""}));
        // Shop area at south side
        signs.add(new ZoneSign(0, half + 1, new String[]{ChatColor.GOLD + "Shop", "Area", "", ""}));
        // Job zone at north side
        signs.add(new ZoneSign(0, -(half + 1), new String[]{ChatColor.BLUE + "Job", "Zone", "", ""}));
        // Housing corridor at south-east corner
        signs.add(new ZoneSign(half + 1, half + 1, new String[]{ChatColor.AQUA + "Housing", "Corridor", "", ""}));
        for (ZoneSign zs : signs) {
            int sx = x + zs.dx;
            int sy = y + 1;
            int sz = z + zs.dz;
            org.bukkit.block.Block block = world.getBlockAt(sx, sy, sz);
            block.setType(org.bukkit.Material.OAK_SIGN, false);
            if (block.getState() instanceof org.bukkit.block.Sign) {
                org.bukkit.block.Sign signState = (org.bukkit.block.Sign) block.getState();
                String[] lines = zs.lines;
                for (int i = 0; i < lines.length && i < 4; i++) {
                    signState.setLine(i, lines[i]);
                }
                signState.update(false, false);
            }
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> comps = new ArrayList<>();
        if (args.length == 1) {
            comps.add("generate");
            comps.add("info");
        } else if (args.length == 2 && args[0].equalsIgnoreCase("generate")) {
            comps.add("confirm");
        }
        return comps;
    }
}