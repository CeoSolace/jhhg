package com.civcore.command;

import com.civcore.CivCorePlugin;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Handles the /civcore command and its subcommands. Supported subcommands are
 * 'reload' to reload configuration and 'status' to display plugin status.
 */
public class CivCoreCommand implements CommandExecutor, TabCompleter {

    private final CivCorePlugin plugin;

    public CivCoreCommand(CivCorePlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            sendUsage(sender);
            return true;
        }
        String sub = args[0].toLowerCase();
        switch (sub) {
            case "reload":
                if (!sender.hasPermission("civcore.reload")) {
                    sender.sendMessage(ChatColor.RED + "You do not have permission to execute this command.");
                    return true;
                }
                plugin.reloadPlugin();
                sender.sendMessage(ChatColor.GREEN + "CivCore Lite configuration reloaded.");
                return true;
            case "status":
                if (!sender.hasPermission("civcore.status")) {
                    sender.sendMessage(ChatColor.RED + "You do not have permission to view the status.");
                    return true;
                }
                sendStatus(sender);
                return true;
            default:
                sendUsage(sender);
                return true;
        }
    }

    private void sendUsage(CommandSender sender) {
        sender.sendMessage(ChatColor.YELLOW + "Usage: /civcore <reload|status>");
    }

    private void sendStatus(CommandSender sender) {
        sender.sendMessage(ChatColor.AQUA + "--- CivCore Lite Status ---");
        sender.sendMessage(ChatColor.GRAY + "Version: " + ChatColor.WHITE + plugin.getDescription().getVersion());
        int profileCount = plugin.getProfileCache() != null ? plugin.getProfileCache().size() : 0;
        sender.sendMessage(ChatColor.GRAY + "Cached Profiles: " + ChatColor.WHITE + profileCount);
        sender.sendMessage(ChatColor.GRAY + "Database Connected: " + ChatColor.WHITE + (plugin.getSQLiteManager() != null && plugin.getSQLiteManager().getConnection() != null));
        sender.sendMessage(ChatColor.GRAY + "Economy Hooked: " + ChatColor.WHITE + (plugin.getEconomy() != null));
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            List<String> completions = new ArrayList<>();
            if ("reload".startsWith(args[0].toLowerCase())) {
                completions.add("reload");
            }
            if ("status".startsWith(args[0].toLowerCase())) {
                completions.add("status");
            }
            return completions;
        }
        return Arrays.asList();
    }
}