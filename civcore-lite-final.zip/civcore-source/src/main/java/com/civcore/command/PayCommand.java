package com.civcore.command;

import com.civcore.CivCorePlugin;
import com.civcore.service.EconomyService;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Handles the /pay command, allowing players to transfer funds to other players.
 */
public class PayCommand implements CommandExecutor, TabCompleter {

    private final CivCorePlugin plugin;
    private final EconomyService economyService;

    public PayCommand(CivCorePlugin plugin) {
        this.plugin = plugin;
        this.economyService = plugin.getEconomyService();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "Only players can execute this command.");
            return true;
        }
        Player payer = (Player) sender;
        if (!payer.hasPermission("civcore.pay")) {
            payer.sendMessage(ChatColor.RED + "You do not have permission to pay other players.");
            return true;
        }
        if (args.length < 2) {
            payer.sendMessage(ChatColor.YELLOW + "Usage: /" + label + " <player> <amount>");
            return true;
        }
        String targetName = args[0];
        OfflinePlayer target = Bukkit.getOfflinePlayer(targetName);
        if (target.getUniqueId().equals(payer.getUniqueId())) {
            payer.sendMessage(ChatColor.RED + "You cannot pay yourself.");
            return true;
        }
        double amount;
        try {
            amount = Double.parseDouble(args[1]);
        } catch (NumberFormatException e) {
            payer.sendMessage(ChatColor.RED + "Invalid amount: " + args[1]);
            return true;
        }
        if (amount <= 0) {
            payer.sendMessage(ChatColor.RED + "Amount must be positive.");
            return true;
        }
        // Ensure payer has enough funds
        if (!economyService.withdraw(payer.getUniqueId(), amount)) {
            payer.sendMessage(ChatColor.RED + "You do not have enough funds.");
            return true;
        }
        // Deposit to target
        economyService.deposit(target.getUniqueId(), amount);
        payer.sendMessage(ChatColor.GREEN + "You paid " + ChatColor.AQUA + targetName + ChatColor.GREEN + " " + String.format("%.2f", amount) + ".");
        if (target.isOnline()) {
            Player onlineTarget = target.getPlayer();
            onlineTarget.sendMessage(ChatColor.GREEN + payer.getName() + " has paid you " + String.format("%.2f", amount) + ".");
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> completions = new ArrayList<>();
        if (args.length == 1) {
            String prefix = args[0].toLowerCase(Locale.ROOT);
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (!p.getName().equalsIgnoreCase(sender.getName()) && p.getName().toLowerCase(Locale.ROOT).startsWith(prefix)) {
                    completions.add(p.getName());
                }
            }
        }
        return completions;
    }
}