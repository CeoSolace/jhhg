package com.civcore.command;

import com.civcore.CivCorePlugin;
import com.civcore.model.RoomInfo;
import com.civcore.service.CountryService;
import com.civcore.service.EconomyService;
import com.civcore.service.HousingService;
import com.civcore.util.AsyncExecutor;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Provides personal room shop functionality. Players can list items for sale
 * from their personal room, remove listings, view current listings and buy
 * items from other players. All database operations are performed
 * asynchronously to avoid blocking the main server thread.
 */
public class RoomShopCommand implements CommandExecutor, TabCompleter {
    private final CivCorePlugin plugin;
    private final HousingService housingService;
    private final EconomyService economyService;
    private final CountryService countryService;
    private final AsyncExecutor executor;

    public RoomShopCommand(CivCorePlugin plugin) {
        this.plugin = plugin;
        this.housingService = plugin.getHousingService();
        this.economyService = plugin.getEconomyService();
        this.countryService = plugin.getCountryService();
        this.executor = plugin.getAsyncExecutor();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "This command can only be used by players.");
            return true;
        }
        Player player = (Player) sender;
        if (args.length < 1) {
            player.sendMessage(ChatColor.YELLOW + "Usage: /" + label + " <add|remove|listings|buy> [args]");
            return true;
        }
        String sub = args[0].toLowerCase();
        switch (sub) {
            case "add":
                handleAdd(player, args);
                break;
            case "remove":
                handleRemove(player, args);
                break;
            case "listings":
                handleListings(player);
                break;
            case "buy":
                handleBuy(player, args);
                break;
            default:
                player.sendMessage(ChatColor.YELLOW + "Unknown subcommand. Usage: /" + label + " <add|remove|listings|buy> [args]");
                break;
        }
        return true;
    }

    /**
     * Handles the /roomshop add command. Requires the player to hold an item in
     * their main hand and specify a price. The item will be removed from the
     * player's inventory and inserted into the room_shop_listings table.
     *
     * @param player Player executing the command
     * @param args   Command arguments
     */
    private void handleAdd(Player player, String[] args) {
        if (args.length < 2) {
            player.sendMessage(ChatColor.YELLOW + "Usage: /roomshop add <price>");
            return;
        }
        double price;
        try {
            price = Double.parseDouble(args[1]);
        } catch (NumberFormatException e) {
            player.sendMessage(ChatColor.RED + "Invalid price.");
            return;
        }
        if (price <= 0) {
            player.sendMessage(ChatColor.RED + "Price must be greater than zero.");
            return;
        }
        UUID playerId = player.getUniqueId();
        RoomInfo room = housingService.getPlayerRoomInfo(playerId);
        if (room == null) {
            player.sendMessage(ChatColor.RED + "You must own a room to list items for sale.");
            return;
        }
        PlayerInventory inv = player.getInventory();
        ItemStack item = inv.getItemInMainHand();
        if (item == null || item.getType() == Material.AIR) {
            player.sendMessage(ChatColor.RED + "Hold the item you want to sell in your main hand.");
            return;
        }
        // Clone the item to avoid modifying metadata when removing
        ItemStack toSell = item.clone();
        // Remove one item from player's hand
        int amount = item.getAmount();
        if (amount <= 1) {
            inv.setItemInMainHand(null);
        } else {
            item.setAmount(amount - 1);
        }
        // Insert listing asynchronously
        executor.runAsync(() -> {
            try (Connection conn = plugin.getSQLiteManager().getConnection();
                 PreparedStatement ps = conn.prepareStatement(
                         "INSERT INTO room_shop_listings (room_id, item, price) VALUES (?, ?, ?)");) {
                ps.setInt(1, room.getId());
                // Store material name as item representation
                ps.setString(2, toSell.getType().name());
                ps.setDouble(3, price);
                ps.executeUpdate();
                conn.commit();
            } catch (SQLException ex) {
                plugin.getLogger().severe("Error adding room shop listing: " + ex.getMessage());
                // Give item back on error
                Bukkit.getScheduler().runTask(plugin, () -> player.getInventory().addItem(toSell));
                return;
            }
            Bukkit.getScheduler().runTask(plugin, () ->
                    player.sendMessage(ChatColor.GREEN + "Listing added for " + price + "!"));
        });
    }

    /**
     * Handles the /roomshop remove command. Removes a listing by ID if it
     * belongs to the player's room and returns the item to the player.
     *
     * @param player Player executing the command
     * @param args   Command arguments
     */
    private void handleRemove(Player player, String[] args) {
        if (args.length < 2) {
            player.sendMessage(ChatColor.YELLOW + "Usage: /roomshop remove <listingId>");
            return;
        }
        int listingId;
        try {
            listingId = Integer.parseInt(args[1]);
        } catch (NumberFormatException e) {
            player.sendMessage(ChatColor.RED + "Invalid listing ID.");
            return;
        }
        UUID playerId = player.getUniqueId();
        RoomInfo room = housingService.getPlayerRoomInfo(playerId);
        if (room == null) {
            player.sendMessage(ChatColor.RED + "You do not own a room.");
            return;
        }
        executor.runAsync(() -> {
            try (Connection conn = plugin.getSQLiteManager().getConnection();
                 PreparedStatement query = conn.prepareStatement(
                         "SELECT room_id, item, price FROM room_shop_listings WHERE id = ?");
                 PreparedStatement delete = conn.prepareStatement(
                         "DELETE FROM room_shop_listings WHERE id = ?");) {
                query.setInt(1, listingId);
                try (ResultSet rs = query.executeQuery()) {
                    if (!rs.next()) {
                        Bukkit.getScheduler().runTask(plugin, () ->
                                player.sendMessage(ChatColor.RED + "Listing not found."));
                        return;
                    }
                    int roomId = rs.getInt("room_id");
                    String itemName = rs.getString("item");
                    if (roomId != room.getId()) {
                        Bukkit.getScheduler().runTask(plugin, () ->
                                player.sendMessage(ChatColor.RED + "You can only remove your own listings."));
                        return;
                    }
                    // Delete listing
                    delete.setInt(1, listingId);
                    delete.executeUpdate();
                    conn.commit();
                    // Give item back to player
                    Material mat;
                    try {
                        mat = Material.valueOf(itemName);
                    } catch (IllegalArgumentException e) {
                        mat = Material.STONE;
                    }
                    ItemStack stack = new ItemStack(mat, 1);
                    Bukkit.getScheduler().runTask(plugin, () -> {
                        player.getInventory().addItem(stack);
                        player.sendMessage(ChatColor.GREEN + "Listing removed and item returned.");
                    });
                }
            } catch (SQLException ex) {
                plugin.getLogger().severe("Error removing room shop listing: " + ex.getMessage());
            }
        });
    }

    /**
     * Handles the /roomshop listings command. Shows all listings for the
     * player's room.
     *
     * @param player Player executing the command
     */
    private void handleListings(Player player) {
        UUID playerId = player.getUniqueId();
        RoomInfo room = housingService.getPlayerRoomInfo(playerId);
        if (room == null) {
            player.sendMessage(ChatColor.RED + "You do not own a room.");
            return;
        }
        executor.runAsync(() -> {
            List<String> lines = new ArrayList<>();
            try (Connection conn = plugin.getSQLiteManager().getConnection();
                 PreparedStatement ps = conn.prepareStatement(
                         "SELECT id, item, price FROM room_shop_listings WHERE room_id = ?");) {
                ps.setInt(1, room.getId());
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        int id = rs.getInt("id");
                        String item = rs.getString("item");
                        double price = rs.getDouble("price");
                        lines.add(ChatColor.GRAY + "#" + id + ChatColor.YELLOW + " " + item + ChatColor.WHITE + " - " + price);
                    }
                }
            } catch (SQLException ex) {
                plugin.getLogger().severe("Error querying room shop listings: " + ex.getMessage());
            }
            Bukkit.getScheduler().runTask(plugin, () -> {
                if (lines.isEmpty()) {
                    player.sendMessage(ChatColor.YELLOW + "You have no shop listings.");
                } else {
                    player.sendMessage(ChatColor.AQUA + "Your shop listings:");
                    for (String line : lines) {
                        player.sendMessage(line);
                    }
                }
            });
        });
    }

    /**
     * Handles the /roomshop buy command. Allows a player to purchase an item
     * from another player's room shop listing. Payment is taken from the
     * buyer and deposited to the seller (taxed) and the listing is removed.
     *
     * @param player Buyer executing the command
     * @param args   Command arguments
     */
    private void handleBuy(Player player, String[] args) {
        if (args.length < 3) {
            player.sendMessage(ChatColor.YELLOW + "Usage: /roomshop buy <player> <listingId>");
            return;
        }
        String sellerName = args[1];
        int listingId;
        try {
            listingId = Integer.parseInt(args[2]);
        } catch (NumberFormatException e) {
            player.sendMessage(ChatColor.RED + "Invalid listing ID.");
            return;
        }
        if (sellerName.equalsIgnoreCase(player.getName())) {
            player.sendMessage(ChatColor.RED + "You cannot buy from yourself.");
            return;
        }
        executor.runAsync(() -> {
            try (Connection conn = plugin.getSQLiteManager().getConnection();
                 PreparedStatement playerQuery = conn.prepareStatement(
                         "SELECT uuid FROM players WHERE name = ? COLLATE NOCASE");
                 PreparedStatement listingQuery = conn.prepareStatement(
                         "SELECT room_id, item, price FROM room_shop_listings WHERE id = ?");
                 PreparedStatement roomQuery = conn.prepareStatement(
                         "SELECT owner_uuid FROM rooms WHERE id = ?");
                 PreparedStatement delete = conn.prepareStatement(
                         "DELETE FROM room_shop_listings WHERE id = ?");) {
                // Lookup seller UUID
                playerQuery.setString(1, sellerName);
                UUID sellerUuid = null;
                try (ResultSet rs = playerQuery.executeQuery()) {
                    if (rs.next()) {
                        sellerUuid = UUID.fromString(rs.getString("uuid"));
                    }
                }
                if (sellerUuid == null) {
                    Bukkit.getScheduler().runTask(plugin, () ->
                            player.sendMessage(ChatColor.RED + "Seller not found."));
                    return;
                }
                // Lookup listing
                listingQuery.setInt(1, listingId);
                int roomId;
                String itemName;
                double price;
                try (ResultSet rs = listingQuery.executeQuery()) {
                    if (!rs.next()) {
                        Bukkit.getScheduler().runTask(plugin, () ->
                                player.sendMessage(ChatColor.RED + "Listing not found."));
                        return;
                    }
                    roomId = rs.getInt("room_id");
                    itemName = rs.getString("item");
                    price = rs.getDouble("price");
                }
                // Verify room belongs to seller
                roomQuery.setInt(1, roomId);
                try (ResultSet rs = roomQuery.executeQuery()) {
                    if (!rs.next()) {
                        Bukkit.getScheduler().runTask(plugin, () ->
                                player.sendMessage(ChatColor.RED + "Room record not found."));
                        return;
                    }
                    String ownerStr = rs.getString("owner_uuid");
                    if (ownerStr == null || !ownerStr.equalsIgnoreCase(sellerUuid.toString())) {
                        Bukkit.getScheduler().runTask(plugin, () ->
                                player.sendMessage(ChatColor.RED + "Listing does not belong to the specified player."));
                        return;
                    }
                }
                // Ensure buyer has funds
                double buyerBal = economyService.getBalance(player.getUniqueId());
                if (buyerBal < price) {
                    Bukkit.getScheduler().runTask(plugin, () ->
                            player.sendMessage(ChatColor.RED + "You do not have enough money to buy this item."));
                    return;
                }
                // Remove listing and commit
                delete.setInt(1, listingId);
                delete.executeUpdate();
                conn.commit();
                // Process payment and item transfer on main thread
                Bukkit.getScheduler().runTask(plugin, () -> {
                    // Withdraw funds from buyer
                    economyService.withdraw(player.getUniqueId(), price, "RoomShop purchase");
                    // Deposit taxed amount to seller
                    economyService.depositTaxed(sellerUuid, price, "RoomShop sale");
                    // Give item to buyer
                    Material mat;
                    try {
                        mat = Material.valueOf(itemName);
                    } catch (IllegalArgumentException e) {
                        mat = Material.STONE;
                    }
                    ItemStack stack = new ItemStack(mat, 1);
                    player.getInventory().addItem(stack);
                    player.sendMessage(ChatColor.GREEN + "Purchased " + mat.name().toLowerCase() + " for " + price + ".");
                });
            } catch (SQLException ex) {
                plugin.getLogger().severe("Error buying room shop listing: " + ex.getMessage());
            }
        });
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> completions = new ArrayList<>();
        if (args.length == 1) {
            completions.add("add");
            completions.add("remove");
            completions.add("listings");
            completions.add("buy");
        }
        return completions;
    }
}