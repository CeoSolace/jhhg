package com.civcore.command;

import com.civcore.CivCorePlugin;
import com.civcore.cache.PlayerProfile;
import com.civcore.cache.PlayerProfileCache;
import com.civcore.service.LawService;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Handles the /laws command which lists all active laws for the player's
 * country. Laws influence gameplay such as taxes, PvP, job payouts and
 * housing costs. Only players may invoke this command.
 */
public class LawsCommand implements CommandExecutor, TabCompleter {
    private final CivCorePlugin plugin;
    private final LawService lawService;
    private final PlayerProfileCache profileCache;

    public LawsCommand(CivCorePlugin plugin) {
        this.plugin = plugin;
        this.lawService = plugin.getLawService();
        this.profileCache = plugin.getProfileCache();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "Only players can execute this command.");
            return true;
        }
        Player player = (Player) sender;
        if (!player.hasPermission("civcore.laws")) {
            player.sendMessage(ChatColor.RED + "You do not have permission to view laws.");
            return true;
        }
        PlayerProfile profile = profileCache.getProfile(player.getUniqueId(), player.getName());
        Integer countryId = profile.getCountryId();
        if (countryId == null) {
            player.sendMessage(ChatColor.RED + "You are not a citizen of any country.");
            return true;
        }
        Map<String, String> laws = lawService.getAllLaws(countryId);
        player.sendMessage(ChatColor.AQUA + "--- Active Laws ---");
        if (laws.isEmpty()) {
            player.sendMessage(ChatColor.GRAY + "No laws defined for your country.");
            return true;
        }
        for (Map.Entry<String, String> entry : laws.entrySet()) {
            String key = entry.getKey();
            String value = entry.getValue();
            player.sendMessage(ChatColor.GRAY + key + ": " + ChatColor.WHITE + value);
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        // No tab completion for /laws
        return Collections.emptyList();
    }
}