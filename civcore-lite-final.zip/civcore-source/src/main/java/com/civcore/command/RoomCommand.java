package com.civcore.command;

import com.civcore.CivCorePlugin;
import com.civcore.model.RoomInfo;
import com.civcore.service.HousingService;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.*;

/**
 * Handles the /room command and its subcommands. Players can purchase,
 * upgrade, sell, view information about their room, and visit the rooms of
 * other players. Usage: /room [info|buy|upgrade|upgrades|sell|visit <player>]
 */
public class RoomCommand implements CommandExecutor, TabCompleter {

    private final CivCorePlugin plugin;
    private final HousingService housingService;

    /**
     * Features offered at each tier. This is a static description to
     * illustrate what upgrades provide. In a future phase this could be
     * moved to the configuration.
     */
    private static final Map<Integer, List<String>> FEATURES = new HashMap<>();

    static {
        FEATURES.put(1, Arrays.asList(
                "Bed",
                "Chest",
                "Furnace",
                "Lantern",
                "Basic room"
        ));
        FEATURES.put(2, Arrays.asList(
                "Double chest",
                "Smoker",
                "Blast furnace",
                "Carpet/floor detail",
                "Basic shop chest unlock"
        ));
        FEATURES.put(3, Arrays.asList(
                "Storage wall",
                "Decoration",
                "Second floor or loft",
                "Enchanting table",
                "Upgraded shop chest unlock"
        ));
        FEATURES.put(4, Arrays.asList(
                "Larger protected space",
                "Balcony/private corner",
                "Armor stand display",
                "Extra storage",
                "Advanced shop chest unlock"
        ));
    }

    public RoomCommand(CivCorePlugin plugin) {
        this.plugin = plugin;
        this.housingService = plugin.getHousingService();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "Only players can use housing commands.");
            return true;
        }
        Player player = (Player) sender;
        if (!player.hasPermission("civcore.room")) {
            player.sendMessage(ChatColor.RED + "You do not have permission to use housing commands.");
            return true;
        }
        if (args.length == 0) {
            sendUsage(player, label);
            return true;
        }
        String sub = args[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "info":
                if (!player.hasPermission("civcore.room.info")) {
                    player.sendMessage(ChatColor.RED + "You do not have permission to view room info.");
                    return true;
                }
                handleInfo(player);
                return true;
            case "buy":
                if (!player.hasPermission("civcore.room.buy")) {
                    player.sendMessage(ChatColor.RED + "You do not have permission to buy a room.");
                    return true;
                }
                handleBuy(player);
                return true;
            case "upgrade":
                if (!player.hasPermission("civcore.room.upgrade")) {
                    player.sendMessage(ChatColor.RED + "You do not have permission to upgrade your room.");
                    return true;
                }
                handleUpgrade(player);
                return true;
            case "upgrades":
                if (!player.hasPermission("civcore.room.upgrades")) {
                    player.sendMessage(ChatColor.RED + "You do not have permission to view room upgrades.");
                    return true;
                }
                handleUpgrades(player);
                return true;
            case "sell":
                if (!player.hasPermission("civcore.room.sell")) {
                    player.sendMessage(ChatColor.RED + "You do not have permission to sell your room.");
                    return true;
                }
                handleSell(player);
                return true;
            case "visit":
                if (!player.hasPermission("civcore.room.visit")) {
                    player.sendMessage(ChatColor.RED + "You do not have permission to visit rooms.");
                    return true;
                }
                handleVisit(player, args);
                return true;
            default:
                sendUsage(player, label);
                return true;
        }
    }

    private void sendUsage(Player player, String label) {
        player.sendMessage(ChatColor.YELLOW + "Usage: /" + label + " <info|buy|upgrade|upgrades|sell|visit <player>>");
    }

    private void handleInfo(Player player) {
        RoomInfo info = housingService.getPlayerRoomInfo(player.getUniqueId());
        if (info == null) {
            player.sendMessage(ChatColor.YELLOW + "You do not own a room. Use /room buy to purchase one.");
            return;
        }
        player.sendMessage(ChatColor.AQUA + "--- Room Info ---");
        player.sendMessage(ChatColor.GRAY + "Room: " + ChatColor.WHITE + info.getName());
        player.sendMessage(ChatColor.GRAY + "Tier: " + ChatColor.WHITE + info.getTier());
        player.sendMessage(ChatColor.GRAY + "Total Spent: " + ChatColor.WHITE + String.format("%.2f", info.getTotalSpent()));
        List<String> features = FEATURES.getOrDefault(info.getTier(), Collections.emptyList());
        player.sendMessage(ChatColor.GRAY + "Features:");
        for (String feat : features) {
            player.sendMessage(ChatColor.DARK_GRAY + " - " + ChatColor.WHITE + feat);
        }
    }

    private void handleBuy(Player player) {
        if (housingService.hasRoom(player.getUniqueId())) {
            player.sendMessage(ChatColor.RED + "You already own a room. Use /room sell to relinquish it.");
            return;
        }
        boolean success = housingService.buyRoom(player.getUniqueId());
        if (!success) {
            player.sendMessage(ChatColor.RED + "Unable to purchase a room. Ensure you are in a country, have enough funds, and that plots are available.");
            return;
        }
        player.sendMessage(ChatColor.GREEN + "You have successfully purchased a room!");
    }

    private void handleUpgrade(Player player) {
        RoomInfo info = housingService.getPlayerRoomInfo(player.getUniqueId());
        if (info == null) {
            player.sendMessage(ChatColor.RED + "You do not own a room.");
            return;
        }
        if (info.getTier() >= 4) {
            player.sendMessage(ChatColor.RED + "Your room is already at the maximum tier.");
            return;
        }
        boolean success = housingService.upgradeRoom(player.getUniqueId());
        if (!success) {
            player.sendMessage(ChatColor.RED + "Unable to upgrade your room. Check your balance or country treasury.");
            return;
        }
        player.sendMessage(ChatColor.GREEN + "Your room has been upgraded to tier " + (info.getTier() + 1) + "!");
    }

    private void handleUpgrades(Player player) {
        RoomInfo info = housingService.getPlayerRoomInfo(player.getUniqueId());
        int currentTier = info != null ? info.getTier() : 0;
        player.sendMessage(ChatColor.AQUA + "--- Available Upgrades ---");
        for (int tier = currentTier + 1; tier <= 4; tier++) {
            List<String> features = FEATURES.getOrDefault(tier, Collections.emptyList());
            String tierLabel = ChatColor.YELLOW + "Tier " + tier + ": ";
            player.sendMessage(tierLabel + ChatColor.GRAY + String.join(", ", features));
        }
        if (currentTier >= 4) {
            player.sendMessage(ChatColor.GRAY + "No further upgrades available.");
        }
    }

    private void handleSell(Player player) {
        RoomInfo info = housingService.getPlayerRoomInfo(player.getUniqueId());
        if (info == null) {
            player.sendMessage(ChatColor.RED + "You do not own a room to sell.");
            return;
        }
        boolean success = housingService.sellRoom(player.getUniqueId());
        if (!success) {
            player.sendMessage(ChatColor.RED + "Unable to sell your room. Your country's treasury may not have enough funds to refund you.");
            return;
        }
        player.sendMessage(ChatColor.GREEN + "Your room has been sold. You received a 50% refund of your total spend.");
    }

    private void handleVisit(Player player, String[] args) {
        if (args.length < 2) {
            player.sendMessage(ChatColor.YELLOW + "Usage: /room visit <player>");
            return;
        }
        String targetName = args[1];
        OfflinePlayer target = Bukkit.getOfflinePlayer(targetName);
        if (target == null || target.getUniqueId() == null) {
            player.sendMessage(ChatColor.RED + "Player not found: " + targetName);
            return;
        }
        if (target.getUniqueId().equals(player.getUniqueId())) {
            player.sendMessage(ChatColor.RED + "You cannot visit your own room.");
            return;
        }
        Location entrance = housingService.getRoomEntrance(target.getUniqueId());
        if (entrance == null) {
            player.sendMessage(ChatColor.RED + "That player does not own a room.");
            return;
        }
        // Teleport the visiting player to the entrance of the target's room
        player.teleport(entrance);
        player.sendMessage(ChatColor.GREEN + "You have been teleported to " + targetName + "'s room entrance.");
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> completions = new ArrayList<>();
        if (!(sender instanceof Player)) {
            return completions;
        }
        Player player = (Player) sender;
        if (!player.hasPermission("civcore.room")) {
            return completions;
        }
        if (args.length == 1) {
            String prefix = args[0].toLowerCase(Locale.ROOT);
            List<String> subs = Arrays.asList("info", "buy", "upgrade", "upgrades", "sell", "visit");
            for (String s : subs) {
                if (s.startsWith(prefix)) completions.add(s);
            }
            return completions;
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("visit")) {
            String prefix = args[1].toLowerCase(Locale.ROOT);
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (!p.getUniqueId().equals(player.getUniqueId()) && p.getName().toLowerCase(Locale.ROOT).startsWith(prefix)) {
                    completions.add(p.getName());
                }
            }
            return completions;
        }
        return completions;
    }
}