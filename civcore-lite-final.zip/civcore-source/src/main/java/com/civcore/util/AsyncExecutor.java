package com.civcore.util;

import com.civcore.CivCorePlugin;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.concurrent.CompletableFuture;
import java.util.function.Supplier;

/**
 * Executes tasks asynchronously using the Bukkit scheduler. Use this class to
 * offload database operations or other expensive computations from the main
 * server thread. It also provides convenience methods for returning futures.
 */
public class AsyncExecutor {
    private final CivCorePlugin plugin;

    public AsyncExecutor(CivCorePlugin plugin) {
        this.plugin = plugin;
    }

    /**
     * Runs a {@link Runnable} asynchronously.
     *
     * @param task The task to run off the main thread.
     */
    public void runAsync(Runnable task) {
        plugin.getServer().getScheduler().runTaskAsynchronously(plugin, task);
    }

    /**
     * Runs a supplier asynchronously and returns a {@link CompletableFuture} with
     * the result. This is useful for database queries or calculations that
     * return a value.
     *
     * @param supplier The supplier to execute off the main thread.
     * @param <T>      The type of the result.
     * @return A future representing the eventual result.
     */
    public <T> CompletableFuture<T> supplyAsync(Supplier<T> supplier) {
        CompletableFuture<T> future = new CompletableFuture<>();
        runAsync(() -> {
            try {
                T result = supplier.get();
                future.complete(result);
            } catch (Throwable t) {
                future.completeExceptionally(t);
            }
        });
        return future;
    }
}