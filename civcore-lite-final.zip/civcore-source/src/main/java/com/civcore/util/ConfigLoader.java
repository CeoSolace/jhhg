package com.civcore.util;

import com.civcore.CivCorePlugin;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import java.util.Collections;
import java.util.List;

/**
 * Wrapper around the Bukkit configuration API. This class loads values from
 * config.yml and exposes them via getters. It supports reloading at runtime.
 */
public class ConfigLoader {
    private final CivCorePlugin plugin;
    private String databaseFile;
    private boolean useMigrations;
    private List<String> defaultCountries;
    private boolean debug;

    public ConfigLoader(CivCorePlugin plugin) {
        this.plugin = plugin;
    }

    /**
     * Loads configuration values from the plugin's config.yml file.
     */
    public void load() {
        FileConfiguration config = plugin.getConfig();
        ConfigurationSection databaseSection = config.getConfigurationSection("database");
        if (databaseSection != null) {
            this.databaseFile = databaseSection.getString("file", "civcore.db");
            this.useMigrations = databaseSection.getBoolean("use-migrations", true);
        } else {
            this.databaseFile = "civcore.db";
            this.useMigrations = true;
        }
        ConfigurationSection countriesSection = config.getConfigurationSection("countries");
        if (countriesSection != null) {
            this.defaultCountries = countriesSection.getStringList("defaults");
        } else {
            this.defaultCountries = Collections.emptyList();
        }
        ConfigurationSection generalSection = config.getConfigurationSection("general");
        if (generalSection != null) {
            this.debug = generalSection.getBoolean("debug", false);
        } else {
            this.debug = false;
        }
    }

    public String getDatabaseFile() {
        return databaseFile;
    }

    public boolean isUseMigrations() {
        return useMigrations;
    }

    public List<String> getDefaultCountries() {
        return defaultCountries;
    }

    public boolean isDebug() {
        return debug;
    }
}