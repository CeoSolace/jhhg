package com.civcore.listener;

import com.civcore.CivCorePlugin;
import com.civcore.cache.PlayerProfile;
import com.civcore.cache.PlayerProfileCache;
import com.civcore.service.EconomyService;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.inventory.CraftItemEvent;
import org.bukkit.inventory.ItemStack;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/**
 * Listens for player actions related to jobs and awards payouts accordingly.
 * Each job has configurable payouts and cooldowns defined in the config.yml.
 * Payouts are processed via the {@link EconomyService#depositTaxed} method to
 * automatically handle country taxes.
 */
public class JobListener implements Listener {

    private final CivCorePlugin plugin;
    private final PlayerProfileCache profileCache;
    private final EconomyService economyService;
    private final com.civcore.service.LawService lawService;
    // Cooldown maps store the last payout timestamp per player per job
    private final Map<UUID, Long> minerCooldowns = new HashMap<>();
    private final Map<UUID, Long> farmerCooldowns = new HashMap<>();
    private final Map<UUID, Long> factoryCooldowns = new HashMap<>();

    public JobListener(CivCorePlugin plugin) {
        this.plugin = plugin;
        this.profileCache = plugin.getProfileCache();
        this.economyService = plugin.getEconomyService();
        this.lawService = plugin.getLawService();
    }

    @EventHandler
    public void onBlockBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        PlayerProfile profile = profileCache.getProfile(player.getUniqueId(), player.getName());
        String job = profile.getJob();
        if (job == null) {
            return;
        }
        job = job.toLowerCase(Locale.ROOT);
        Material type = event.getBlock().getType();
        Location loc = event.getBlock().getLocation();
        // Miner job: mining specific blocks in miner zone
        if (job.equals("miner")) {
            if (!isInZone(loc, "miner")) return;
            double payout = plugin.getConfig().getDouble("jobs.miner.payouts." + type.name(), 0.0);
            if (payout <= 0) return;
            long cooldown = plugin.getConfig().getLong("jobs.miner.cooldown", 3);
            long now = System.currentTimeMillis();
            Long last = minerCooldowns.get(player.getUniqueId());
            if (last != null && now - last < cooldown * 1000L) {
                return;
            }
            minerCooldowns.put(player.getUniqueId(), now);
            // Apply job multiplier law
            Integer cId = profile.getCountryId();
            double multiplier = 1.0;
            if (cId != null) {
                double m = lawService.getDoubleLaw(cId, "JOB_MULTIPLIER");
                if (m > 0) multiplier = m;
            }
            double gross = payout * multiplier;
            economyService.depositTaxed(player.getUniqueId(), gross, "Mining " + type.name());
        }
        // Farmer job: harvesting crops in farm zone
        else if (job.equals("farmer")) {
            if (!isInZone(loc, "farmer")) return;
            double payout = plugin.getConfig().getDouble("jobs.farmer.payouts." + type.name(), 0.0);
            if (payout <= 0) return;
            long cooldown = plugin.getConfig().getLong("jobs.farmer.cooldown", 3);
            long now = System.currentTimeMillis();
            Long last = farmerCooldowns.get(player.getUniqueId());
            if (last != null && now - last < cooldown * 1000L) {
                return;
            }
            farmerCooldowns.put(player.getUniqueId(), now);
            Integer cId2 = profile.getCountryId();
            double multiplier2 = 1.0;
            if (cId2 != null) {
                double m2 = lawService.getDoubleLaw(cId2, "JOB_MULTIPLIER");
                if (m2 > 0) multiplier2 = m2;
            }
            double gross2 = payout * multiplier2;
            economyService.depositTaxed(player.getUniqueId(), gross2, "Farming " + type.name());
        }
    }

    @EventHandler
    public void onCraftItem(CraftItemEvent event) {
        if (!(event.getWhoClicked() instanceof Player)) {
            return;
        }
        Player player = (Player) event.getWhoClicked();
        PlayerProfile profile = profileCache.getProfile(player.getUniqueId(), player.getName());
        String job = profile.getJob();
        if (job == null || !job.equalsIgnoreCase("factory")) {
            return;
        }
        // Check zone
        if (!isInZone(player.getLocation(), "factory")) {
            return;
        }
        ItemStack result = event.getRecipe() != null ? event.getRecipe().getResult() : null;
        if (result == null) {
            return;
        }
        Material resultType = result.getType();
        double payoutPerItem = plugin.getConfig().getDouble("jobs.factory.payouts." + resultType.name(), 0.0);
        if (payoutPerItem <= 0) {
            return;
        }
        // Cooldown
        long cooldown = plugin.getConfig().getLong("jobs.factory.cooldown", 5);
        long now = System.currentTimeMillis();
        Long last = factoryCooldowns.get(player.getUniqueId());
        if (last != null && now - last < cooldown * 1000L) {
            return;
        }
        factoryCooldowns.put(player.getUniqueId(), now);
        // Determine number of items crafted (result quantity may be >1)
        int amount = result.getAmount();
        // deposit taxed
        Integer countryId = profile.getCountryId();
        double multiplier = 1.0;
        if (countryId != null) {
            double m = lawService.getDoubleLaw(countryId, "JOB_MULTIPLIER");
            if (m > 0) multiplier = m;
        }
        double gross = payoutPerItem * amount * multiplier;
        economyService.depositTaxed(player.getUniqueId(), gross, "Crafting " + resultType.name());
    }

    /**
     * Checks whether a location is inside the configured zone for a given job.
     * If no zone is defined for the job, returns true.
     *
     * @param loc     The location to check
     * @param jobName The job name key under zones
     * @return true if within the zone or no zone defined
     */
    private boolean isInZone(Location loc, String jobName) {
        ConfigurationSection zone = plugin.getConfig().getConfigurationSection("zones." + jobName);
        if (zone == null) {
            return true;
        }
        String worldName = zone.getString("world", loc.getWorld().getName());
        if (!loc.getWorld().getName().equals(worldName)) {
            return false;
        }
        double x = loc.getX();
        double y = loc.getY();
        double z = loc.getZ();
        double x1 = zone.getDouble("x1");
        double y1 = zone.getDouble("y1");
        double z1 = zone.getDouble("z1");
        double x2 = zone.getDouble("x2");
        double y2 = zone.getDouble("y2");
        double z2 = zone.getDouble("z2");
        double minX = Math.min(x1, x2);
        double maxX = Math.max(x1, x2);
        double minY = Math.min(y1, y2);
        double maxY = Math.max(y1, y2);
        double minZ = Math.min(z1, z2);
        double maxZ = Math.max(z1, z2);
        return x >= minX && x <= maxX && y >= minY && y <= maxY && z >= minZ && z <= maxZ;
    }
}