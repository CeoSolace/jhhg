package com.civcore.listener;

import com.civcore.CivCorePlugin;
import com.civcore.cache.PlayerProfile;
import com.civcore.cache.PlayerProfileCache;
import com.civcore.service.LawService;
import org.bukkit.ChatColor;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.projectiles.ProjectileSource;

/**
 * Enforces the PVP_ENABLED law by cancelling combat events if PvP is
 * disabled for either the attacker or the victim's country. When a law
 * disables PvP, players from that country cannot engage in player
 * combat. Attacking players will be informed when their attack is
 * prevented by law.
 */
public class PvpListener implements Listener {
    private final CivCorePlugin plugin;
    private final PlayerProfileCache profileCache;
    private final LawService lawService;
    private final com.civcore.service.ProtectionService protectionService;

    public PvpListener(CivCorePlugin plugin) {
        this.plugin = plugin;
        this.profileCache = plugin.getProfileCache();
        this.lawService = plugin.getLawService();
        this.protectionService = plugin.getProtectionService();
    }

    @EventHandler
    public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
        // Only handle player vs player damage
        Entity victimEntity = event.getEntity();
        Entity damager = event.getDamager();
        Player attacker = null;
        if (damager instanceof Player) {
            attacker = (Player) damager;
        } else if (damager instanceof org.bukkit.entity.Projectile) {
            ProjectileSource src = ((org.bukkit.entity.Projectile) damager).getShooter();
            if (src instanceof Player) {
                attacker = (Player) src;
            }
        }
        if (!(victimEntity instanceof Player) || attacker == null) {
            return;
        }
        Player victim = (Player) victimEntity;
        // Determine countries
        PlayerProfile victimProfile = profileCache.getProfile(victim.getUniqueId(), victim.getName());
        PlayerProfile attackerProfile = profileCache.getProfile(attacker.getUniqueId(), attacker.getName());
        Integer victimCountry = victimProfile.getCountryId();
        Integer attackerCountry = attackerProfile.getCountryId();

        // PvP law enforcement only applies when the combat occurs inside a
        // headquarters protected zone. If combat takes place outside of all
        // HQs, PvP is always allowed regardless of law.
        boolean inVictimHQ = victimCountry != null && protectionService.isInHq(victim.getLocation(), victimCountry);
        boolean inAttackerHQ = attackerCountry != null && protectionService.isInHq(attacker.getLocation(), attackerCountry);
        if (inVictimHQ || inAttackerHQ) {
            // Determine if either player's country has PvP disabled
            boolean cancel = false;
            if (victimCountry != null) {
                boolean pvp = lawService.getBooleanLaw(victimCountry, "PVP_ENABLED");
                if (!pvp) {
                    cancel = true;
                }
            }
            if (!cancel && attackerCountry != null) {
                boolean pvp = lawService.getBooleanLaw(attackerCountry, "PVP_ENABLED");
                if (!pvp) {
                    cancel = true;
                }
            }
            if (cancel) {
                event.setCancelled(true);
                attacker.sendMessage(ChatColor.RED + "PvP is disabled by law in this protected area.");
            }
        }
    }
}