package com.civcore.listener;

import com.civcore.CivCorePlugin;
import com.civcore.service.ProtectionService;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBurnEvent;
import org.bukkit.event.block.BlockIgniteEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.block.BlockSpreadEvent;
import org.bukkit.event.entity.EntityBlockFormEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerPortalEvent;
import org.bukkit.event.world.PortalCreateEvent;
import org.bukkit.util.Vector;

/**
 * Handles global build and interaction protection outside of the housing system.
 * This listener delegates permission checks to {@link ProtectionService} and
 * enforces additional rules such as disabling portal creation, nether travel
 * and fire spread near headquarters. Protected areas include country
 * headquarters and configured zones. Staff and leaders can override these
 * restrictions.
 */
public class GlobalProtectionListener implements Listener {
    private final CivCorePlugin plugin;
    private final ProtectionService protectionService;

    public GlobalProtectionListener(CivCorePlugin plugin) {
        this.plugin = plugin;
        this.protectionService = plugin.getProtectionService();
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBlockPlace(BlockPlaceEvent event) {
        Player player = event.getPlayer();
        Block block = event.getBlock();
        if (!protectionService.canBuild(player.getUniqueId(), block.getLocation())) {
            event.setCancelled(true);
            player.sendMessage(ChatColor.RED + "You cannot build in this protected area.");
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBlockBreak(org.bukkit.event.block.BlockBreakEvent event) {
        Player player = event.getPlayer();
        Block block = event.getBlock();
        if (!protectionService.canBuild(player.getUniqueId(), block.getLocation())) {
            event.setCancelled(true);
            player.sendMessage(ChatColor.RED + "You cannot break blocks in this protected area.");
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent event) {
        if (event.getClickedBlock() == null) return;
        Player player = event.getPlayer();
        Location loc = event.getClickedBlock().getLocation();
        if (!protectionService.canInteract(player.getUniqueId(), loc)) {
            event.setCancelled(true);
            player.sendMessage(ChatColor.RED + "You cannot interact with this block in a protected area.");
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPortalCreate(PortalCreateEvent event) {
        boolean disable = plugin.getConfig().getConfigurationSection("protection")
                .getBoolean("disable-portals", true);
        if (disable) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPlayerPortal(PlayerPortalEvent event) {
        boolean disablePortals = plugin.getConfig().getConfigurationSection("protection")
                .getBoolean("disable-portals", true);
        boolean disableNether = plugin.getConfig().getConfigurationSection("protection")
                .getBoolean("disable-nether", true);
        if (disablePortals) {
            event.setCancelled(true);
            return;
        }
        if (disableNether && event.getTo() != null && event.getTo().getWorld() != null
                && event.getTo().getWorld().getEnvironment() == org.bukkit.World.Environment.NETHER) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.NORMAL, ignoreCancelled = true)
    public void onBlockIgnite(BlockIgniteEvent event) {
        // Cancel fire ignition within configured radius of any HQ
        handleFireEvent(event.getBlock(), event);
    }

    @EventHandler(priority = EventPriority.NORMAL, ignoreCancelled = true)
    public void onBlockBurn(BlockBurnEvent event) {
        // Cancel fire burning near HQs
        handleFireEvent(event.getBlock(), event);
    }

    @EventHandler(priority = EventPriority.NORMAL, ignoreCancelled = true)
    public void onBlockSpread(BlockSpreadEvent event) {
        // Cancel fire spread near HQs
        if (event.getSource() != null && event.getSource().getType() == org.bukkit.Material.FIRE) {
            handleFireEvent(event.getBlock(), event);
        }
    }

    /**
     * Helper that cancels a fire-related event if the block is within the
     * configured fire spread radius of any headquarters region. It reads the
     * radius from config.yml at protection.fire-spread-radius.
     *
     * @param block  Block that is igniting, burning or being spread to
     * @param event  Event to cancel if protected
     */
    private void handleFireEvent(Block block, org.bukkit.event.Cancellable event) {
        int radius = plugin.getConfig().getConfigurationSection("protection")
                .getInt("fire-spread-radius", 16);
        Location loc = block.getLocation();
        // Check each HQ region: if within radius of the region centre, cancel
        // Use ProtectionService's HQ check with expanded radius
        // Expand check: shift region boundaries by radius in each direction
        // Build a simple check by computing distance to HQ origin if available
        // For simplicity, reuse ProtectionServiceImpl.isInHq with null; if inside HQ,
        // always cancel fire events.
        if (protectionService instanceof com.civcore.service.impl.ProtectionServiceImpl) {
            com.civcore.service.impl.ProtectionServiceImpl impl = (com.civcore.service.impl.ProtectionServiceImpl) protectionService;
            if (impl.isInHq(loc, null)) {
                event.setCancelled(true);
            }
        }
    }
}