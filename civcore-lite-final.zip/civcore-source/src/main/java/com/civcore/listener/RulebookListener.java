package com.civcore.listener;

import com.civcore.CivCorePlugin;
import com.civcore.service.RulesService;
import org.bukkit.ChatColor;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

/**
 * Prevents players from dropping or moving the server rulebook. The
 * rulebook is an important informational item and must remain in the
 * player's inventory. This listener relies on {@link RulesService} to
 * determine whether an item is the rulebook.
 */
public class RulebookListener implements Listener {
    private final RulesService rulesService;

    public RulebookListener(CivCorePlugin plugin) {
        this.rulesService = plugin.getRulesService();
    }

    @EventHandler
    public void onItemDrop(PlayerDropItemEvent event) {
        ItemStack dropped = event.getItemDrop().getItemStack();
        if (rulesService.isRulebook(dropped)) {
            event.setCancelled(true);
            event.getPlayer().sendMessage(ChatColor.RED + "You cannot drop the rulebook.");
        }
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        ItemStack current = event.getCurrentItem();
        if (current == null || !rulesService.isRulebook(current)) {
            return;
        }
        Inventory clicked = event.getClickedInventory();
        // Allow clicks in the player's own inventory but disallow moving to other inventories
        if (clicked != null && clicked != event.getWhoClicked().getInventory()) {
            event.setCancelled(true);
            event.getWhoClicked().sendMessage(ChatColor.RED + "You cannot move the rulebook into containers.");
        }
    }
}