package com.civcore.listener;

import com.civcore.CivCorePlugin;
import com.civcore.cache.PlayerProfile;
import com.civcore.cache.PlayerProfileCache;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

/**
 * Listener that manages loading and saving player profiles when players join
 * and leave the server. Profiles are cached in memory for quick access during
 * gameplay and persisted to the database asynchronously on quit.
 */
public class PlayerConnectionListener implements Listener {

    private final CivCorePlugin plugin;
    private final PlayerProfileCache profileCache;

    public PlayerConnectionListener(CivCorePlugin plugin) {
        this.plugin = plugin;
        this.profileCache = plugin.getProfileCache();
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        // Load or create a player profile when they join. The profile cache
        // will handle creating a new entry if one does not exist.
        profileCache.getProfile(event.getPlayer().getUniqueId(), event.getPlayer().getName());
        // Give the rulebook on join
        plugin.getRulesService().giveRulebook(event.getPlayer());
        // Initialize scoreboard for player
        plugin.getUiService().initScoreboard(event.getPlayer());
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        // Save the player's profile asynchronously when they quit.
        PlayerProfile profile = profileCache.getProfile(event.getPlayer().getUniqueId(), event.getPlayer().getName());
        profileCache.saveProfile(profile);
        // Remove the player's scoreboard
        plugin.getUiService().removeScoreboard(event.getPlayer());
    }
}