package com.civcore.listener;

import com.civcore.CivCorePlugin;
import org.bukkit.event.Listener;
import com.civcore.listener.PlayerConnectionListener;
import com.civcore.listener.JobListener;
import com.civcore.listener.ShopListener;
import com.civcore.listener.RoomProtectionListener;
import com.civcore.listener.PvpListener;
import com.civcore.listener.GlobalProtectionListener;
import com.civcore.listener.RulebookListener;

/**
 * Responsible for registering and managing Bukkit event listeners. This class
 * provides a central location for hooking into game events. Listeners can be
 * added in later phases of development.
 */
public class ListenerRegistry {
    private final CivCorePlugin plugin;

    public ListenerRegistry(CivCorePlugin plugin) {
        this.plugin = plugin;
    }

    /**
     * Registers all event listeners with the Bukkit plugin manager. In this
     * phase, no listeners are registered, but this method exists to provide
     * structure for future features.
     */
    public void registerListeners() {
        // Register player connection listener to handle join/quit events
        plugin.getServer().getPluginManager().registerEvents(new PlayerConnectionListener(plugin), plugin);
        // Register job listener for job payouts
        plugin.getServer().getPluginManager().registerEvents(new JobListener(plugin), plugin);
        // Register shop listener for GUI interactions
        plugin.getServer().getPluginManager().registerEvents(new ShopListener(plugin), plugin);
        // Register room protection listener to enforce housing rules
        plugin.getServer().getPluginManager().registerEvents(new RoomProtectionListener(plugin), plugin);

        // Register PvP listener to enforce PVP_ENABLED law
        plugin.getServer().getPluginManager().registerEvents(new PvpListener(plugin), plugin);

        // Register global protection listener for HQ, portal and fire protection
        plugin.getServer().getPluginManager().registerEvents(new GlobalProtectionListener(plugin), plugin);

        // Register rulebook listener to prevent dropping or moving the rulebook
        plugin.getServer().getPluginManager().registerEvents(new RulebookListener(plugin), plugin);
    }
}