package com.civcore.listener;

import com.civcore.CivCorePlugin;
import com.civcore.model.RoomInfo;
import com.civcore.service.HousingService;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.player.PlayerInteractEvent;

/**
 * Prevents players from interacting with or breaking blocks inside rooms they
 * do not own. Staff with the civcore.room.override permission are exempt.
 */
public class RoomProtectionListener implements Listener {

    private final CivCorePlugin plugin;
    private final HousingService housingService;
    private final com.civcore.service.GovernmentService governmentService;

    public RoomProtectionListener(CivCorePlugin plugin) {
        this.plugin = plugin;
        this.housingService = plugin.getHousingService();
        this.governmentService = plugin.getGovernmentService();
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        // Allow staff role to override protections
        String role = governmentService.getPlayerRole(player.getUniqueId());
        if (player.hasPermission("civcore.room.override") || (role != null && role.equalsIgnoreCase("staff"))) {
            return;
        }
        Location loc = event.getBlock().getLocation();
        RoomInfo room = housingService.getRoomAt(loc);
        if (room == null) {
            return;
        }
        // If the room has an owner and the player is not the owner, cancel
        if (room.getOwner() != null && !room.getOwner().equals(player.getUniqueId())) {
            event.setCancelled(true);
            player.sendMessage(ChatColor.RED + "You cannot modify this room. It is owned by another player.");
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPlayerInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        // Allow staff role to override
        String role = governmentService.getPlayerRole(player.getUniqueId());
        if (player.hasPermission("civcore.room.override") || (role != null && role.equalsIgnoreCase("staff"))) {
            return;
        }
        Location loc = event.getInteractionPoint() != null ? event.getInteractionPoint() : (event.getClickedBlock() != null ? event.getClickedBlock().getLocation() : null);
        if (loc == null) {
            return;
        }
        RoomInfo room = housingService.getRoomAt(loc);
        if (room == null) {
            return;
        }
        if (room.getOwner() != null && !room.getOwner().equals(player.getUniqueId())) {
            event.setCancelled(true);
            player.sendMessage(ChatColor.RED + "You cannot interact here. This room belongs to another player.");
        }
    }
}