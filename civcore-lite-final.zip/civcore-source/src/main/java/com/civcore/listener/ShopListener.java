package com.civcore.listener;

import com.civcore.CivCorePlugin;
import com.civcore.cache.PlayerProfile;
import com.civcore.cache.PlayerProfileCache;
import com.civcore.command.ShopCommand;
import com.civcore.service.CountryService;
import com.civcore.service.EconomyService;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;

/**
 * Handles interactions within the shop inventory. Players can buy items with
 * left-click and sell items with right-click. Buy and sell prices are defined
 * in the configuration and a sales tax is applied to each transaction.
 */
public class ShopListener implements Listener {

    private final CivCorePlugin plugin;
    private final PlayerProfileCache profileCache;
    private final CountryService countryService;
    private final EconomyService economyService;

    public ShopListener(CivCorePlugin plugin) {
        this.plugin = plugin;
        this.profileCache = plugin.getProfileCache();
        this.countryService = plugin.getCountryService();
        this.economyService = plugin.getEconomyService();
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player)) {
            return;
        }
        Player player = (Player) event.getWhoClicked();
        Inventory top = event.getView().getTopInventory();
        // Ensure we act only on our shop inventory by comparing titles
        String title = event.getView().getTitle();
        if (!title.equals(ShopCommand.SHOP_TITLE)) {
            return;
        }
        // Always cancel the event to prevent taking items
        event.setCancelled(true);
        Inventory clickedInv = event.getClickedInventory();
        if (clickedInv == null || clickedInv != top) {
            return;
        }
        ItemStack clicked = event.getCurrentItem();
        if (clicked == null || clicked.getType() == Material.AIR) {
            return;
        }
        Material material = clicked.getType();
        String key = material.name();
        ConfigurationSection itemsSection = plugin.getConfig().getConfigurationSection("shop.items");
        if (itemsSection == null || !itemsSection.contains(key)) {
            return;
        }
        double buyPrice = itemsSection.getDouble(key + ".buy", 0.0);
        double sellPrice = itemsSection.getDouble(key + ".sell", 0.0);
        double taxPercentage = plugin.getConfig().getDouble("shop.tax-percentage", 0.0);
        // Determine click type: left-click to buy, right-click to sell
        ClickType click = event.getClick();
        if (click.isLeftClick()) {
            // Buying one item
            if (buyPrice <= 0) {
                player.sendMessage(ChatColor.RED + "This item cannot be purchased.");
                return;
            }
            PlayerInventory inv = player.getInventory();
            if (inv.firstEmpty() == -1) {
                player.sendMessage(ChatColor.RED + "Your inventory is full.");
                return;
            }
            // Withdraw funds from player
            if (!economyService.withdraw(player.getUniqueId(), buyPrice)) {
                player.sendMessage(ChatColor.RED + "You do not have enough funds to purchase this item.");
                return;
            }
            // Apply sales tax to country treasury if applicable
            double tax = buyPrice * (taxPercentage / 100.0);
            PlayerProfile profile = profileCache.getProfile(player.getUniqueId(), player.getName());
            Integer countryId = profile.getCountryId();
            if (tax > 0 && countryId != null) {
                countryService.addToTreasury(countryId, tax);
            }
            // Give the item to the player
            inv.addItem(new ItemStack(material, 1));
            player.sendMessage(ChatColor.GREEN + "Purchased 1 " + material.name() + " for " + String.format("%.2f", buyPrice) + ".");
        } else if (click.isRightClick()) {
            // Selling one item
            if (sellPrice <= 0) {
                player.sendMessage(ChatColor.RED + "This item cannot be sold.");
                return;
            }
            PlayerInventory inv = player.getInventory();
            // Ensure the player has at least one item of this type
            int slotIndex = inv.first(material);
            if (slotIndex == -1) {
                player.sendMessage(ChatColor.RED + "You do not have any " + material.name() + " to sell.");
                return;
            }
            ItemStack invItem = inv.getItem(slotIndex);
            if (invItem == null) {
                player.sendMessage(ChatColor.RED + "You do not have any " + material.name() + " to sell.");
                return;
            }
            // Remove one item from player's inventory
            if (invItem.getAmount() > 1) {
                invItem.setAmount(invItem.getAmount() - 1);
            } else {
                inv.setItem(slotIndex, null);
            }
            // Apply sales tax and deposit net amount to player
            double tax = sellPrice * (taxPercentage / 100.0);
            double net = sellPrice - tax;
            // Deposit net to player
            economyService.deposit(player.getUniqueId(), net);
            // Deposit tax to treasury
            PlayerProfile profile = profileCache.getProfile(player.getUniqueId(), player.getName());
            Integer countryId = profile.getCountryId();
            if (tax > 0 && countryId != null) {
                countryService.addToTreasury(countryId, tax);
            }
            player.sendMessage(ChatColor.GREEN + "Sold 1 " + material.name() + " for " + String.format("%.2f", sellPrice) + ".");
        }
    }
}