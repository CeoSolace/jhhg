package com.civcore;

import com.civcore.cache.PlayerProfileCache;
import com.civcore.command.CommandRegistry;
import com.civcore.database.DatabaseMigrator;
import com.civcore.database.SQLiteManager;
import com.civcore.listener.ListenerRegistry;
import com.civcore.util.AsyncExecutor;
import com.civcore.util.ConfigLoader;
import com.civcore.service.EconomyService;
import com.civcore.service.CountryService;
import com.civcore.service.impl.EconomyServiceImpl;
import com.civcore.service.impl.CountryServiceImpl;
import com.civcore.economy.CivCoreEconomyProvider;
import org.bukkit.Bukkit;
import org.bukkit.plugin.ServicePriority;
import org.bukkit.plugin.java.JavaPlugin;
import net.milkbowl.vault.economy.Economy;

/**
 * Main entry point for the CivCore Lite plugin. This class manages the lifecycle
 * of the plugin, initializes core components, and provides accessors for
 * subsystems such as configuration, database, caching, commands and listeners.
 */
public class CivCorePlugin extends JavaPlugin {

    private ConfigLoader configLoader;
    private AsyncExecutor asyncExecutor;
    private SQLiteManager sqliteManager;
    private DatabaseMigrator databaseMigrator;
    private PlayerProfileCache profileCache;
    private CommandRegistry commandRegistry;
    private ListenerRegistry listenerRegistry;
    private EconomyService economyService;
    private CountryService countryService;
    private com.civcore.service.HousingService housingService;
    private com.civcore.service.LawService lawService;
    private com.civcore.service.GovernmentService governmentService;
    private com.civcore.service.ProtectionService protectionService;
    private com.civcore.service.RulesService rulesService;
    private com.civcore.service.UiService uiService;
    private Economy economy; // Vault API object, may refer to external provider or our own
    private CivCoreEconomyProvider economyProvider;

    // HQ generation tracking
    private final java.util.Map<Integer, Boolean> hqGenerated = new java.util.HashMap<>();
    private boolean hqGenerationPending = false;

    @Override
    public void onLoad() {
        // Called when the plugin is first loaded. Use this to perform early setup.
        getLogger().info("CivCore Lite is loading...");
    }

    @Override
    public void onEnable() {
        // Called when the plugin is enabled. Initialize subsystems here.
        saveDefaultConfig();
        this.configLoader = new ConfigLoader(this);
        this.asyncExecutor = new AsyncExecutor(this);
        this.sqliteManager = new SQLiteManager(this);
        this.databaseMigrator = new DatabaseMigrator(this);
        this.profileCache = new PlayerProfileCache(this);
        this.commandRegistry = new CommandRegistry(this);
        this.listenerRegistry = new ListenerRegistry(this);
        // Initialize services. CountryService must be created before EconomyService so
        // that the EconomyService can access a non-null CountryService via the plugin.
        this.countryService = new CountryServiceImpl(this);
        this.economyService = new EconomyServiceImpl(this);
        // Initialize housing service after country and economy services are ready
        this.housingService = new com.civcore.service.impl.HousingServiceImpl(this);
        // Initialize law service before government service so that government can use laws
        this.lawService = new com.civcore.service.impl.LawServiceImpl(this);
        // Initialize government service after law service
        this.governmentService = new com.civcore.service.impl.GovernmentServiceImpl(this);

        // Initialize protection, UI and rules services
        this.protectionService = new com.civcore.service.impl.ProtectionServiceImpl(this);
        this.uiService = new com.civcore.service.impl.UiServiceImpl(this);
        this.rulesService = new com.civcore.service.impl.RulesServiceImpl(this);

        // Load configuration
        configLoader.load();

        // Initialize database connection
        try {
            sqliteManager.openConnection();
        } catch (Exception e) {
            getLogger().severe("Failed to open SQLite connection: " + e.getMessage());
            e.printStackTrace();
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        // Run database migrations
        databaseMigrator.migrate();

        // Start UI scoreboard updates
        uiService.start();

        // Register our own economy provider with Vault
        registerEconomyProvider();

        // Register commands and tab completers
        commandRegistry.registerCommands();
        // Register listeners
        listenerRegistry.registerListeners();

        getLogger().info("CivCore Lite enabled successfully.");
    }

    @Override
    public void onDisable() {
        // Called when the plugin is disabled. Save data and clean up resources.
        getLogger().info("CivCore Lite is shutting down...");
        // Save all cached profiles
        if (profileCache != null) {
            profileCache.saveAll();
        }
        // Close database connection
        if (sqliteManager != null) {
            sqliteManager.closeConnection();
        }
        // Unregister economy provider
        if (economyProvider != null) {
            getServer().getServicesManager().unregister(Economy.class, economyProvider);
            economyProvider = null;
        }

        // Stop scoreboard updates
        if (uiService != null) {
            uiService.stop();
        }
        getLogger().info("CivCore Lite has been disabled.");
    }

    /**
     * Reloads the plugin configuration and runs migrations if necessary.
     */
    public void reloadPlugin() {
        reloadConfig();
        configLoader.load();
        databaseMigrator.migrate();
        getLogger().info("CivCore Lite configuration reloaded.");
    }

    /**
     * Registers the CivCore economy provider with Vault. If Vault is not
     * installed, economy features will still function internally but will not
     * be available to other plugins.
     */
    private void registerEconomyProvider() {
        if (getServer().getPluginManager().getPlugin("Vault") == null) {
            getLogger().warning("Vault not found. CivCore economy will not be registered with Vault.");
            return;
        }
        this.economyProvider = new CivCoreEconomyProvider(this);
        // Register at normal priority so it does not override more preferred providers
        getServer().getServicesManager().register(Economy.class, economyProvider, this, ServicePriority.Normal);
        this.economy = economyProvider;
        getLogger().info("Registered CivCore economy provider with Vault.");
    }

    // Accessors
    public ConfigLoader getConfigLoader() {
        return configLoader;
    }

    public AsyncExecutor getAsyncExecutor() {
        return asyncExecutor;
    }

    public SQLiteManager getSQLiteManager() {
        return sqliteManager;
    }

    public PlayerProfileCache getProfileCache() {
        return profileCache;
    }
    public Economy getEconomy() {
        return economy;
    }

    public EconomyService getEconomyService() {
        return economyService;
    }

    public CountryService getCountryService() {
        return countryService;
    }

    /**
     * Returns the housing service used to manage player rooms. This accessor
     * allows other components such as commands and listeners to obtain
     * functionality for buying, upgrading, selling and visiting rooms.
     *
     * @return the plugin's HousingService implementation
     */
    public com.civcore.service.HousingService getHousingService() {
        return housingService;
    }

    /**
     * Returns the LawService used to manage active laws and retrieve law
     * values for countries. Other services can query this to adjust
     * behaviour based on current laws.
     *
     * @return LawService implementation
     */
    public com.civcore.service.LawService getLawService() {
        return lawService;
    }

    /**
     * Returns the GovernmentService used for managing roles, proposals
     * and voting. Commands and listeners can call this to perform
     * appointments, removals and voting operations.
     *
     * @return GovernmentService implementation
     */
    public com.civcore.service.GovernmentService getGovernmentService() {
        return governmentService;
    }

    /**
     * Returns the protection service which determines whether players can
     * interact or build at a location.
     *
     * @return protection service implementation
     */
    public com.civcore.service.ProtectionService getProtectionService() {
        return protectionService;
    }

    /**
     * Returns the UI service for opening menus and handling scoreboards.
     *
     * @return UI service implementation
     */
    public com.civcore.service.UiService getUiService() {
        return uiService;
    }

    /**
     * Returns the rules service for managing the server rulebook.
     *
     * @return rules service implementation
     */
    public com.civcore.service.RulesService getRulesService() {
        return rulesService;
    }

    // Headquarters generation state accessors
    public boolean isHqGenerated(int countryId) {
        return hqGenerated.getOrDefault(countryId, false);
    }

    public void setHqGenerated(int countryId, boolean generated) {
        hqGenerated.put(countryId, generated);
    }

    public boolean isHqGenerationPending() {
        return hqGenerationPending;
    }

    public void setHqGenerationPending(boolean pending) {
        this.hqGenerationPending = pending;
    }
}