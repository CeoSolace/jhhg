package com.civcore.model;

import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.Bukkit;

/**
 * Represents a predefined plot where a room can be built. A plot defines
 * a rectangular region in a world and an entrance location used when
 * teleporting players to their room. Plots are loaded from the
 * configuration and mapped to room records in the database.
 */
public class RoomPlot {
    private final String countryName;
    private final String plotName;
    private final String worldName;
    private final double x1;
    private final double y1;
    private final double z1;
    private final double x2;
    private final double y2;
    private final double z2;
    private final double entranceX;
    private final double entranceY;
    private final double entranceZ;

    public RoomPlot(String countryName, String plotName, String worldName,
                    double x1, double y1, double z1,
                    double x2, double y2, double z2,
                    double entranceX, double entranceY, double entranceZ) {
        this.countryName = countryName;
        this.plotName = plotName;
        this.worldName = worldName;
        this.x1 = x1;
        this.y1 = y1;
        this.z1 = z1;
        this.x2 = x2;
        this.y2 = y2;
        this.z2 = z2;
        this.entranceX = entranceX;
        this.entranceY = entranceY;
        this.entranceZ = entranceZ;
    }

    public String getCountryName() {
        return countryName;
    }

    public String getPlotName() {
        return plotName;
    }

    public String getWorldName() {
        return worldName;
    }

    /**
     * Determines whether the given location lies within this plot's region.
     * The region is inclusive of the boundaries defined by (x1,y1,z1) and
     * (x2,y2,z2).
     *
     * @param loc Location to test
     * @return true if the location is inside the plot
     */
    public boolean contains(Location loc) {
        if (loc == null) return false;
        if (!loc.getWorld().getName().equalsIgnoreCase(worldName)) return false;
        double lx = loc.getX();
        double ly = loc.getY();
        double lz = loc.getZ();
        double minX = Math.min(x1, x2);
        double maxX = Math.max(x1, x2);
        double minY = Math.min(y1, y2);
        double maxY = Math.max(y1, y2);
        double minZ = Math.min(z1, z2);
        double maxZ = Math.max(z1, z2);
        return lx >= minX && lx <= maxX && ly >= minY && ly <= maxY && lz >= minZ && lz <= maxZ;
    }

    /**
     * Returns the entrance location for this plot. If the world is not
     * currently loaded, this method will return null.
     *
     * @return Entrance location or null if world is missing
     */
    public Location getEntrance() {
        World world = Bukkit.getWorld(worldName);
        if (world == null) {
            return null;
        }
        return new Location(world, entranceX, entranceY, entranceZ);
    }
}