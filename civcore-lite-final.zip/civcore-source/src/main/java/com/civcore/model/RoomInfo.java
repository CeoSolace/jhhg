package com.civcore.model;

import java.util.UUID;

/**
 * Represents information about a player's room. This model is used by the
 * HousingService to return details about a room such as the current tier,
 * the country it belongs to and the total amount of money spent on it.
 */
public class RoomInfo {
    private final int id;
    private final int countryId;
    private final String name;
    private final int tier;
    private final UUID owner;
    private final double totalSpent;

    public RoomInfo(int id, int countryId, String name, int tier, UUID owner, double totalSpent) {
        this.id = id;
        this.countryId = countryId;
        this.name = name;
        this.tier = tier;
        this.owner = owner;
        this.totalSpent = totalSpent;
    }

    public int getId() {
        return id;
    }

    public int getCountryId() {
        return countryId;
    }

    public String getName() {
        return name;
    }

    public int getTier() {
        return tier;
    }

    public UUID getOwner() {
        return owner;
    }

    public double getTotalSpent() {
        return totalSpent;
    }
}