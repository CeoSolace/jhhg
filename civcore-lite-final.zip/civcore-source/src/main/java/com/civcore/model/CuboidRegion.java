package com.civcore.model;

import org.bukkit.Location;
import org.bukkit.World;

/**
 * Represents a simple axis-aligned cuboid region in a specific world. This
 * class is used for protected zones such as headquarters and other
 * configured areas. It stores the minimum and maximum coordinates along
 * each axis and provides a method to test whether a given {@link Location}
 * lies inside the region. World comparisons are performed by name to
 * reduce reliance on loaded world objects.
 */
public class CuboidRegion {
    private final String worldName;
    private final int minX;
    private final int minY;
    private final int minZ;
    private final int maxX;
    private final int maxY;
    private final int maxZ;

    /**
     * Constructs a new cuboid region. The constructor will normalize the
     * provided coordinates so that {@code min <= max} for each axis.
     *
     * @param world World the region resides in
     * @param x1    First X coordinate
     * @param y1    First Y coordinate
     * @param z1    First Z coordinate
     * @param x2    Second X coordinate
     * @param y2    Second Y coordinate
     * @param z2    Second Z coordinate
     */
    public CuboidRegion(World world, int x1, int y1, int z1, int x2, int y2, int z2) {
        this.worldName = world.getName();
        this.minX = Math.min(x1, x2);
        this.minY = Math.min(y1, y2);
        this.minZ = Math.min(z1, z2);
        this.maxX = Math.max(x1, x2);
        this.maxY = Math.max(y1, y2);
        this.maxZ = Math.max(z1, z2);
    }

    /**
     * Constructs a new cuboid region using a centre point and a uniform
     * protection radius. The region will extend equally in all directions
     * from the centre by the specified radius. Negative radii are clamped
     * to zero.
     *
     * @param world   World of the region
     * @param centerX Centre X coordinate
     * @param centerY Centre Y coordinate
     * @param centerZ Centre Z coordinate
     * @param radius  Half-size of the cube along each axis
     */
    public CuboidRegion(World world, int centerX, int centerY, int centerZ, int radius) {
        this.worldName = world.getName();
        int r = Math.max(radius, 0);
        this.minX = centerX - r;
        this.minY = centerY - r;
        this.minZ = centerZ - r;
        this.maxX = centerX + r;
        this.maxY = centerY + r;
        this.maxZ = centerZ + r;
    }

    /**
     * Checks whether the provided location lies inside this region. If the
     * location is in a different world, this method immediately returns
     * {@code false}.
     *
     * @param location Location to test
     * @return true if the location is inside the region, false otherwise
     */
    public boolean contains(Location location) {
        if (location == null) {
            return false;
        }
        World locWorld = location.getWorld();
        if (locWorld == null || !locWorld.getName().equalsIgnoreCase(this.worldName)) {
            return false;
        }
        int x = location.getBlockX();
        int y = location.getBlockY();
        int z = location.getBlockZ();
        return x >= minX && x <= maxX && y >= minY && y <= maxY && z >= minZ && z <= maxZ;
    }
}