package com.civcore.service;

import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

/**
 * Manages the creation and distribution of server rulebooks. The rules
 * service provides methods to give a rulebook to a player, open the
 * rulebook for reading and to test whether an item is the rulebook.
 */
public interface RulesService {
    /**
     * Gives the server rulebook to the specified player if they do not
     * already have one in their inventory. The rulebook is created from
     * the configuration's rules section.
     *
     * @param player Player to receive the rulebook
     */
    void giveRulebook(Player player);

    /**
     * Opens the server rulebook for the player to read. If the player does
     * not have a rulebook, one will be given first.
     *
     * @param player Player to open the rulebook for
     */
    void openRulebook(Player player);

    /**
     * Determines whether the provided item is the server rulebook. This
     * method checks the item's metadata against the configured title and
     * author.
     *
     * @param item ItemStack to test
     * @return true if the item is the rulebook
     */
    boolean isRulebook(ItemStack item);
}