package com.civcore.service;

import org.bukkit.Location;
import java.util.UUID;

/**
 * Determines whether players are permitted to interact with or modify blocks
 * at specific locations. Protection rules prevent griefing and enforce
 * territorial boundaries for countries and rooms.
 */
public interface ProtectionService {
    /**
     * Checks whether the specified player is allowed to build at the given
     * location.
     *
     * @param player   Unique ID of the player attempting to build
     * @param location Location where the build is attempted
     * @return true if the player can build, false otherwise
     */
    boolean canBuild(UUID player, Location location);

    /**
     * Checks whether the specified player is allowed to interact at the given
     * location (e.g. open chests, use doors).
     *
     * @param player   Unique ID of the player attempting the interaction
     * @param location Location of the interaction
     * @return true if interaction is allowed
     */
    boolean canInteract(UUID player, Location location);

    /**
     * Determines whether a location lies within a headquarters region. If a
     * country ID is provided, only that country's HQ is tested; if null or
     * negative, all HQs are checked.
     *
     * This method is primarily used by the PvP enforcement logic to ensure
     * that PvP laws only apply within protected zones. Implementations may
     * return false if headquarters are not configured for the given country.
     *
     * @param location  Location to test
     * @param countryId ID of the country or null to test all HQs
     * @return true if the location is inside the specified HQ region
     */
    boolean isInHq(Location location, Integer countryId);
}