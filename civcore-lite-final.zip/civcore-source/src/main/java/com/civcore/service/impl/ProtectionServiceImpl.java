package com.civcore.service.impl;

import com.civcore.CivCorePlugin;
import com.civcore.model.CuboidRegion;
import com.civcore.model.RoomInfo;
import com.civcore.service.CountryService;
import com.civcore.service.GovernmentService;
import com.civcore.service.HousingService;
import com.civcore.service.ProtectionService;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Default implementation of {@link ProtectionService}. This class enforces
 * protection rules for headquarters (HQ) areas and housing rooms. Players are
 * allowed to modify their own rooms while ordinary players may not build or
 * interact within protected HQ zones. Staff and leaders can bypass
 * protections. Protection boundaries are configured in config.yml under the
 * 'hq' section.
 */
public class ProtectionServiceImpl implements ProtectionService {
    private final CivCorePlugin plugin;
    private final HousingService housingService;
    private final GovernmentService governmentService;
    private final CountryService countryService;
    /** Maps country IDs to their HQ protection region. */
    private final Map<Integer, CuboidRegion> hqRegions = new HashMap<>();

    public ProtectionServiceImpl(CivCorePlugin plugin) {
        this.plugin = plugin;
        this.housingService = plugin.getHousingService();
        this.governmentService = plugin.getGovernmentService();
        this.countryService = plugin.getCountryService();
        loadHqRegions();
    }

    /**
     * Loads HQ protection regions from the configuration. For each country
     * defined in the 'hq' section, this method looks up the origin and
     * protection radius and constructs a {@link CuboidRegion}. If the
     * corresponding country cannot be resolved to an ID or the world is
     * unavailable, the region is skipped. Regions are stored in the
     * {@link #hqRegions} map keyed by country ID.
     */
    private void loadHqRegions() {
        ConfigurationSection hqSection = plugin.getConfig().getConfigurationSection("hq");
        if (hqSection == null) {
            return;
        }
        for (String countryName : hqSection.getKeys(false)) {
            ConfigurationSection countrySection = hqSection.getConfigurationSection(countryName);
            if (countrySection == null) continue;
            ConfigurationSection origin = countrySection.getConfigurationSection("origin");
            if (origin == null) continue;
            String worldName = origin.getString("world");
            int x = origin.getInt("x", 0);
            int y = origin.getInt("y", 64);
            int z = origin.getInt("z", 0);
            int radius = countrySection.getInt("protection-radius", 30);
            World world = Bukkit.getWorld(worldName);
            if (world == null) {
                plugin.getLogger().warning("World '" + worldName + "' for HQ of " + countryName + " is not loaded; HQ protection disabled for this country.");
                continue;
            }
            int countryId = countryService.getCountryIdByName(countryName).orElse(-1);
            if (countryId <= 0) {
                continue;
            }
            CuboidRegion region = new CuboidRegion(world, x, y, z, radius);
            hqRegions.put(countryId, region);
        }
    }

    /**
     * Determines if the given location lies within any HQ region. If
     * {@code countryId} is provided, only that country's region is tested; a
     * null or negative country ID will test all regions.
     *
     * @param location  Location to test
     * @param countryId Optional country ID to limit the check
     * @return true if inside a relevant HQ region
     */
    @Override
    public boolean isInHq(Location location, Integer countryId) {
        if (location == null) {
            return false;
        }
        if (countryId != null && countryId > 0) {
            CuboidRegion region = hqRegions.get(countryId);
            return region != null && region.contains(location);
        }
        for (CuboidRegion region : hqRegions.values()) {
            if (region.contains(location)) {
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean canBuild(UUID playerUuid, Location location) {
        // Always allow if the player is staff or leader
        if (playerUuid != null) {
            String role = governmentService.getPlayerRole(playerUuid);
            if (role != null && (role.equalsIgnoreCase("staff") || role.equalsIgnoreCase("leader"))) {
                return true;
            }
        }
        // If inside own room, allow build
        if (playerUuid != null) {
            RoomInfo room = housingService.getRoomAt(location);
            if (room != null && room.getOwner() != null && room.getOwner().equals(playerUuid)) {
                return true;
            }
        }
        // Disallow building inside any HQ region
        if (isInHq(location, null)) {
            return false;
        }
        // Otherwise allowed
        return true;
    }

    @Override
    public boolean canInteract(UUID playerUuid, Location location) {
        // Staff and leaders may interact anywhere
        if (playerUuid != null) {
            String role = governmentService.getPlayerRole(playerUuid);
            if (role != null && (role.equalsIgnoreCase("staff") || role.equalsIgnoreCase("leader"))) {
                return true;
            }
        }
        // Own room
        if (playerUuid != null) {
            RoomInfo room = housingService.getRoomAt(location);
            if (room != null && room.getOwner() != null && room.getOwner().equals(playerUuid)) {
                return true;
            }
        }
        // Inside HQ: disallow interactions for ordinary players
        if (isInHq(location, null)) {
            return false;
        }
        return true;
    }
}