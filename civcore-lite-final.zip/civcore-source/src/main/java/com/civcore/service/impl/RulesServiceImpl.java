package com.civcore.service.impl;

import com.civcore.CivCorePlugin;
import com.civcore.service.RulesService;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.BookMeta;

import java.util.ArrayList;
import java.util.List;

/**
 * Implementation of {@link RulesService} that creates a written book from
 * the configuration and distributes it to players. The rulebook content
 * is cached so that subsequent calls reuse the same template. Drop and
 * movement protection are handled in a separate listener.
 */
public class RulesServiceImpl implements RulesService {
    private final CivCorePlugin plugin;
    private ItemStack cachedBook;
    private String title;
    private String author;

    public RulesServiceImpl(CivCorePlugin plugin) {
        this.plugin = plugin;
        loadBook();
    }

    /**
     * Reads the rulebook definition from the configuration and constructs
     * an ItemStack representing the written book. If the configuration
     * section is missing, a default set of pages is used. The book is
     * cached for reuse.
     */
    private void loadBook() {
        ConfigurationSection rulesSec = plugin.getConfig().getConfigurationSection("rules");
        if (rulesSec == null) {
            this.title = ChatColor.RED + "Server Rules";
            this.author = "CivCore";
            List<String> pages = new ArrayList<>();
            pages.add("Welcome to CivCore!\nNo rules configured.");
            createBook(title, author, pages);
            return;
        }
        this.title = rulesSec.getString("title", "Server Rules");
        this.author = rulesSec.getString("author", "CivCore");
        List<String> pages = new ArrayList<>();
        List<?> rawPages = rulesSec.getList("content");
        if (rawPages != null && !rawPages.isEmpty()) {
            for (Object obj : rawPages) {
                if (obj != null) {
                    pages.add(obj.toString());
                }
            }
        } else {
            pages.add("No rules have been configured.");
        }
        createBook(title, author, pages);
    }

    private void createBook(String title, String author, List<String> pages) {
        ItemStack book = new ItemStack(Material.WRITTEN_BOOK);
        BookMeta meta = (BookMeta) book.getItemMeta();
        meta.setTitle(title);
        meta.setAuthor(author);
        meta.setPages(pages);
        book.setItemMeta(meta);
        this.cachedBook = book;
    }

    @Override
    public void giveRulebook(Player player) {
        if (player == null) return;
        // Check if player already has the rulebook
        for (ItemStack item : player.getInventory().getContents()) {
            if (item != null && isRulebook(item)) {
                return;
            }
        }
        // Add a copy to player's inventory
        ItemStack book = cachedBook.clone();
        player.getInventory().addItem(book);
    }

    @Override
    public void openRulebook(Player player) {
        if (player == null) return;
        giveRulebook(player);
        // Find the rulebook in the player's inventory and open it
        for (ItemStack item : player.getInventory().getContents()) {
            if (item != null && isRulebook(item)) {
                // Use the Bukkit API to open the book
                player.openBook(item);
                return;
            }
        }
    }

    @Override
    public boolean isRulebook(ItemStack item) {
        if (item == null || item.getType() != Material.WRITTEN_BOOK) return false;
        if (!item.hasItemMeta()) return false;
        BookMeta meta = (BookMeta) item.getItemMeta();
        if (meta == null) return false;
        String t = meta.getTitle();
        String a = meta.getAuthor();
        return this.title.equals(t) && this.author.equals(a);
    }
}