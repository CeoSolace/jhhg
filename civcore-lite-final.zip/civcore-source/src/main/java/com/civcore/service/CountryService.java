package com.civcore.service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * Provides methods to manage countries, such as creating new countries,
 * retrieving information and assigning players. Countries represent the
 * top-level organizational structure in CivCore.
 */
public interface CountryService {
    /**
     * Creates a new country with the given name.
     *
     * @param name Name of the country to create
     * @return The ID of the newly created country
     */
    int createCountry(String name);

    /**
     * Retrieves the name of a country by ID.
     *
     * @param countryId Identifier of the country
     * @return Optional containing the country name if it exists
     */
    Optional<String> getCountry(int countryId);

    /**
     * Gets a list of all country names.
     *
     * @return list of country names
     */
    List<String> listCountries();

    /**
     * Assigns a player to a country. If the player was previously in another
     * country, they will be moved.
     *
     * @param player   Unique ID of the player
     * @param countryId ID of the country to assign
     */
    void assignPlayer(UUID player, int countryId);

    /**
     * Retrieves the numeric ID of a country by its name.
     *
     * @param name Name of the country
     * @return Optional containing the ID if found
     */
    Optional<Integer> getCountryIdByName(String name);

    /**
     * Gets the tax percentage configured for the given country.
     *
     * @param countryId ID of the country
     * @return tax percentage (0-100)
     */
    double getTaxPercentage(int countryId);

    /**
     * Gets the current treasury balance for a country.
     *
     * @param countryId ID of the country
     * @return treasury amount
     */
    double getTreasury(int countryId);

    /**
     * Adds funds to a country's treasury. This operation should be performed
     * asynchronously to avoid blocking the server thread.
     *
     * @param countryId ID of the country
     * @param amount    Amount to add
     */
    void addToTreasury(int countryId, double amount);

    /**
     * Retrieves a list of citizen names for the specified country.
     *
     * @param countryId ID of the country
     * @return list of player names belonging to the country
     */
    List<String> getCitizens(int countryId);
}