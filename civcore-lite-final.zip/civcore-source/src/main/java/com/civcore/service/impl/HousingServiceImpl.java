package com.civcore.service.impl;

import com.civcore.CivCorePlugin;
import com.civcore.cache.PlayerProfile;
import com.civcore.cache.PlayerProfileCache;
import com.civcore.model.RoomInfo;
import com.civcore.model.RoomPlot;
import com.civcore.service.CountryService;
import com.civcore.service.EconomyService;
import com.civcore.service.HousingService;
import com.civcore.util.AsyncExecutor;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.OfflinePlayer;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.scheduler.BukkitRunnable;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Implementation of the {@link HousingService} interface. This class handles
 * persistence and management of player rooms. It uses the plugin's
 * configuration to determine pricing and plot definitions and interacts
 * with the SQLite database via the {@link com.civcore.database.SQLiteManager}.
 */
public class HousingServiceImpl implements HousingService {

    private final CivCorePlugin plugin;
    private final PlayerProfileCache profileCache;
    private final EconomyService economyService;
    private final CountryService countryService;
    private final com.civcore.service.LawService lawService;
    private final com.civcore.database.SQLiteManager sqliteManager;
    private final AsyncExecutor executor;

    /**
     * Mapping of country names (lowercase) to their plot definitions. Each
     * plot definition is keyed by the plot name and contains region and
     * entrance data loaded from the configuration.
     */
    private final Map<String, Map<String, RoomPlot>> plotsByCountry = new HashMap<>();

    /**
     * Mapping from a room's database ID to its corresponding plot. This
     * mapping is populated at startup and whenever room plots are reloaded.
     */
    private final Map<Integer, RoomPlot> plotByRoomId = new HashMap<>();

    public HousingServiceImpl(CivCorePlugin plugin) {
        this.plugin = plugin;
        this.profileCache = plugin.getProfileCache();
        this.economyService = plugin.getEconomyService();
        this.countryService = plugin.getCountryService();
        this.sqliteManager = plugin.getSQLiteManager();
        this.executor = plugin.getAsyncExecutor();
        this.lawService = plugin.getLawService();
        loadPlotsFromConfig();
        reloadRoomPlotMapping();
    }

    /**
     * Parses the "roomPlots" section of the configuration file and populates
     * {@link #plotsByCountry}. Each plot is associated with a country and
     * identified by a name. Plot names should be unique within a country.
     */
    private void loadPlotsFromConfig() {
        plotsByCountry.clear();
        FileConfiguration config = plugin.getConfig();
        ConfigurationSection roomPlotsSection = config.getConfigurationSection("roomPlots");
        if (roomPlotsSection == null) {
            return;
        }
        for (String countryKey : roomPlotsSection.getKeys(false)) {
            String countryName = countryKey.toLowerCase();
            List<?> list = roomPlotsSection.getList(countryKey);
            if (list == null) {
                continue;
            }
            Map<String, RoomPlot> map = new HashMap<>();
            for (Object obj : list) {
                if (!(obj instanceof Map)) {
                    continue;
                }
                Map<?, ?> m = (Map<?, ?>) obj;
                // Extract mandatory fields
                String plotName = m.getOrDefault("name", "plot").toString();
                String worldName = m.getOrDefault("world", "world").toString();
                double x1 = toDouble(m.get("x1"));
                double y1 = toDouble(m.get("y1"));
                double z1 = toDouble(m.get("z1"));
                double x2 = toDouble(m.get("x2"));
                double y2 = toDouble(m.get("y2"));
                double z2 = toDouble(m.get("z2"));
                // Entrance nested map
                double ex = x1;
                double ey = y1;
                double ez = z1;
                Object entranceObj = m.get("entrance");
                if (entranceObj instanceof Map) {
                    Map<?, ?> em = (Map<?, ?>) entranceObj;
                    ex = toDouble(em.get("x"));
                    ey = toDouble(em.get("y"));
                    ez = toDouble(em.get("z"));
                }
                RoomPlot plot = new RoomPlot(countryName, plotName, worldName, x1, y1, z1, x2, y2, z2, ex, ey, ez);
                map.put(plotName, plot);
            }
            plotsByCountry.put(countryName, map);
        }
    }

    /**
     * Utility to convert an arbitrary object into a double. If the object is
     * null or cannot be converted, 0.0 is returned.
     *
     * @param obj Object to convert
     * @return double value
     */
    private double toDouble(Object obj) {
        if (obj == null) return 0.0;
        if (obj instanceof Number) return ((Number) obj).doubleValue();
        try {
            return Double.parseDouble(obj.toString());
        } catch (NumberFormatException e) {
            return 0.0;
        }
    }

    /**
     * Rebuilds the mapping from room IDs to plots. This method queries the
     * database for all existing rooms, then assigns each to a plot based on
     * its country and name. If no plot definition exists for a room, it
     * remains unmapped and will not provide location-based features.
     */
    public void reloadRoomPlotMapping() {
        plotByRoomId.clear();
        // Build a map of countryId -> countryName
        Map<Integer, String> countryNames = new HashMap<>();
        try {
            Connection conn = sqliteManager.getConnection();
            try (PreparedStatement ps = conn.prepareStatement("SELECT id, name FROM countries")) {
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        countryNames.put(rs.getInt(1), rs.getString(2).toLowerCase());
                    }
                }
            }
            // Assign rooms to plots
            try (PreparedStatement ps = conn.prepareStatement("SELECT id, country_id, name FROM rooms")) {
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        int roomId = rs.getInt(1);
                        int countryId = rs.getInt(2);
                        String roomName = rs.getString(3);
                        String countryName = countryNames.get(countryId);
                        if (countryName == null) {
                            continue;
                        }
                        Map<String, RoomPlot> map = plotsByCountry.get(countryName);
                        if (map != null) {
                            RoomPlot plot = map.get(roomName);
                            if (plot != null) {
                                plotByRoomId.put(roomId, plot);
                            }
                        }
                    }
                }
            }
        } catch (SQLException e) {
            plugin.getLogger().warning("Failed to reload room plot mappings: " + e.getMessage());
        }
    }

    @Override
    public boolean hasRoom(UUID player) {
        return getPlayerRoomInfo(player) != null;
    }

    /**
     * Retrieves the room owned by the specified player, if any.
     *
     * @param player Unique ID of the player
     * @return RoomInfo for the player's room or null if none
     */
    private RoomInfo loadPlayerRoom(UUID player) {
        try {
            Connection conn = sqliteManager.getConnection();
            try (PreparedStatement ps = conn.prepareStatement(
                    "SELECT id, country_id, name, level, owner_uuid, purchase_total FROM rooms WHERE owner_uuid = ?")) {
                ps.setString(1, player.toString());
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        int id = rs.getInt("id");
                        int countryId = rs.getInt("country_id");
                        String name = rs.getString("name");
                        int level = rs.getInt("level");
                        String ownerUuid = rs.getString("owner_uuid");
                        double total = rs.getDouble("purchase_total");
                        UUID owner = ownerUuid != null ? UUID.fromString(ownerUuid) : null;
                        return new RoomInfo(id, countryId, name, level, owner, total);
                    }
                }
            }
        } catch (SQLException e) {
            plugin.getLogger().warning("Failed to load player room: " + e.getMessage());
        }
        return null;
    }

    @Override
    public RoomInfo getPlayerRoomInfo(UUID player) {
        return loadPlayerRoom(player);
    }

    @Override
    public List<Integer> listRooms(UUID player) {
        RoomInfo info = loadPlayerRoom(player);
        if (info == null) {
            return Collections.emptyList();
        }
        return Collections.singletonList(info.getId());
    }

    @Override
    public boolean buyRoom(UUID playerUuid) {
        // Check if player already owns a room
        if (hasRoom(playerUuid)) {
            return false;
        }
        // Determine player's country
        OfflinePlayer offline = Bukkit.getOfflinePlayer(playerUuid);
        String name = offline.getName() != null ? offline.getName() : playerUuid.toString();
        PlayerProfile profile = profileCache.getProfile(playerUuid, name);
        Integer countryId = profile.getCountryId();
        if (countryId == null) {
            // Player must join a country before buying a room
            return false;
        }
        // Find first available room for the player's country
        int roomId = -1;
        String roomName = null;
        try {
            Connection conn = sqliteManager.getConnection();
            String sql = "SELECT id, name FROM rooms WHERE country_id = ? AND owner_uuid IS NULL ORDER BY id LIMIT 1";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, countryId);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        roomId = rs.getInt("id");
                        roomName = rs.getString("name");
                    }
                }
            }
        } catch (SQLException e) {
            plugin.getLogger().warning("Failed to find available room: " + e.getMessage());
            return false;
        }
        if (roomId < 0 || roomName == null) {
            // No rooms available
            return false;
        }
        // Determine price from config
        String countryName = countryService.getCountry(countryId).orElse("");
        double price = plugin.getConfig().getDouble(
                "housing.prices." + countryName.toLowerCase() + ".starter", 0.0);
        if (price <= 0) {
            // Cannot determine price; prevent purchase
            return false;
        }
        // Apply room price multiplier law
        double multiplier = 1.0;
        if (countryId != null) {
            double m = lawService.getDoubleLaw(countryId, "ROOM_PRICE_MULTIPLIER");
            if (m > 0) multiplier = m;
        }
        price *= multiplier;
        // Attempt to withdraw funds from player's balance
        boolean success = economyService.withdraw(playerUuid, price);
        if (!success) {
            return false;
        }
        // Add the price to the country's treasury
        countryService.addToTreasury(countryId, price);
        int finalRoomId = roomId;
        String finalRoomName = roomName;
        // Schedule the build and database update on the main thread with a callback
        scheduleTierBuild(finalRoomId, 1, () -> {
            executor.runAsync(() -> {
                try {
                    Connection conn = sqliteManager.getConnection();
                    try (PreparedStatement ps = conn.prepareStatement(
                            "UPDATE rooms SET owner_uuid = ?, level = 1, purchase_total = ? WHERE id = ?")) {
                        ps.setString(1, playerUuid.toString());
                        ps.setDouble(2, price);
                        ps.setInt(3, finalRoomId);
                        ps.executeUpdate();
                    }
                    conn.commit();
                } catch (SQLException e) {
                    plugin.getLogger().warning("Failed to update room purchase: " + e.getMessage());
                }
            });
        });
        return true;
    }

    @Override
    public boolean upgradeRoom(UUID playerUuid) {
        RoomInfo info = loadPlayerRoom(playerUuid);
        if (info == null) {
            return false;
        }
        int currentTier = info.getTier();
        if (currentTier >= 4) {
            // Already max tier
            return false;
        }
        int nextTier = currentTier + 1;
        // Determine price for next tier
        String countryName = countryService.getCountry(info.getCountryId()).orElse("");
        String priceKey;
        switch (nextTier) {
            case 2:
                priceKey = "tier2";
                break;
            case 3:
                priceKey = "tier3";
                break;
            case 4:
                priceKey = "tier4";
                break;
            default:
                priceKey = null;
        }
        if (priceKey == null) {
            return false;
        }
        double price = plugin.getConfig().getDouble(
                "housing.prices." + countryName.toLowerCase() + "." + priceKey, 0.0);
        if (price <= 0) {
            return false;
        }
        // Apply room upgrade price multiplier law
        double multiplier = 1.0;
        double m = lawService.getDoubleLaw(info.getCountryId(), "ROOM_UPGRADE_MULTIPLIER");
        if (m > 0) multiplier = m;
        price *= multiplier;
        // Attempt to withdraw funds
        boolean success = economyService.withdraw(playerUuid, price);
        if (!success) {
            return false;
        }
        // Add to treasury
        countryService.addToTreasury(info.getCountryId(), price);
        int roomId = info.getId();
        // Schedule build
        scheduleTierBuild(roomId, nextTier, () -> {
            executor.runAsync(() -> {
                try {
                    Connection conn = sqliteManager.getConnection();
                    try (PreparedStatement ps = conn.prepareStatement(
                            "UPDATE rooms SET level = ?, purchase_total = purchase_total + ? WHERE id = ?")) {
                        ps.setInt(1, nextTier);
                        ps.setDouble(2, price);
                        ps.setInt(3, roomId);
                        ps.executeUpdate();
                    }
                    conn.commit();
                } catch (SQLException e) {
                    plugin.getLogger().warning("Failed to upgrade room: " + e.getMessage());
                }
            });
        });
        return true;
    }

    @Override
    public boolean sellRoom(UUID playerUuid) {
        RoomInfo info = loadPlayerRoom(playerUuid);
        if (info == null) {
            return false;
        }
        // Calculate refund (50% of total spent)
        double refund = info.getTotalSpent() * 0.5;
        // Ensure country's treasury has enough funds to cover refund
        double treasury = countryService.getTreasury(info.getCountryId());
        if (treasury < refund) {
            return false;
        }
        int roomId = info.getId();
        // Subtract refund from treasury and deposit to player
        countryService.addToTreasury(info.getCountryId(), -refund);
        economyService.deposit(playerUuid, refund);
        // Schedule reset build and DB update
        scheduleTierBuild(roomId, 0, () -> {
            executor.runAsync(() -> {
                try {
                    Connection conn = sqliteManager.getConnection();
                    try (PreparedStatement ps = conn.prepareStatement(
                            "UPDATE rooms SET owner_uuid = NULL, level = 0, purchase_total = 0 WHERE id = ?")) {
                        ps.setInt(1, roomId);
                        ps.executeUpdate();
                    }
                    conn.commit();
                } catch (SQLException e) {
                    plugin.getLogger().warning("Failed to sell room: " + e.getMessage());
                }
            });
        });
        return true;
    }

    /**
     * Schedules a build or reset operation for the specified room. The build
     * is performed asynchronously with respect to the main thread using a
     * BukkitRunnable. In this simplified implementation the build does not
     * modify blocks but ensures that callback is executed after a tick.
     *
     * @param roomId  ID of the room to build or reset
     * @param newTier Tier to build (0 resets to empty)
     * @param callback Runnable to execute after the build completes
     */
    private void scheduleTierBuild(int roomId, int newTier, Runnable callback) {
        RoomPlot plot = plotByRoomId.get(roomId);
        // In a full implementation, blocks within the plot would be modified
        // here using BukkitRunnable to stay within 1500 blocks per tick. For
        // CivCore Lite, we simply run the callback on the next tick without
        // performing any world edits.
        new BukkitRunnable() {
            @Override
            public void run() {
                if (callback != null) {
                    callback.run();
                }
            }
        }.runTask(plugin);
    }

    @Override
    public Location getRoomEntrance(UUID playerUuid) {
        RoomInfo info = loadPlayerRoom(playerUuid);
        if (info == null) {
            return null;
        }
        RoomPlot plot = plotByRoomId.get(info.getId());
        if (plot != null) {
            return plot.getEntrance();
        }
        return null;
    }

    @Override
    public RoomInfo getRoomAt(Location location) {
        if (location == null) {
            return null;
        }
        // Iterate through mapped plots to find a match
        for (Map.Entry<Integer, RoomPlot> entry : plotByRoomId.entrySet()) {
            RoomPlot plot = entry.getValue();
            if (plot != null && plot.contains(location)) {
                // Load room info by ID
                int roomId = entry.getKey();
                try {
                    Connection conn = sqliteManager.getConnection();
                    try (PreparedStatement ps = conn.prepareStatement(
                            "SELECT id, country_id, name, level, owner_uuid, purchase_total FROM rooms WHERE id = ?")) {
                        ps.setInt(1, roomId);
                        try (ResultSet rs = ps.executeQuery()) {
                            if (rs.next()) {
                                int countryId = rs.getInt("country_id");
                                String name = rs.getString("name");
                                int level = rs.getInt("level");
                                String ownerUuid = rs.getString("owner_uuid");
                                double total = rs.getDouble("purchase_total");
                                UUID owner = ownerUuid != null ? UUID.fromString(ownerUuid) : null;
                                return new RoomInfo(roomId, countryId, name, level, owner, total);
                            }
                        }
                    }
                } catch (SQLException e) {
                    plugin.getLogger().warning("Failed to get room by location: " + e.getMessage());
                }
                return null;
            }
        }
        return null;
    }
}