package com.civcore.service;

import java.util.List;
import java.util.UUID;

/**
 * Provides operations related to player housing and rooms. Housing allows
 * players to own and upgrade rooms within their country.
 */
public interface HousingService {
    /**
     * Determines whether the specified player currently owns a room.
     *
     * @param player Unique ID of the player
     * @return true if the player has a room, false otherwise
     */
    boolean hasRoom(UUID player);

    /**
     * Purchases a room for the given player. The room assigned will be the
     * first available plot defined for the player's country. The player's
     * balance will be reduced by the starter price configured for their
     * country and the country's treasury will be credited accordingly.
     *
     * @param player Unique ID of the player
     * @return true if the purchase succeeded, false otherwise
     */
    boolean buyRoom(UUID player);

    /**
     * Upgrades the player's room to the next tier. The upgrade cost is
     * determined by the current tier and country settings in the configuration.
     *
     * @param player Unique ID of the player
     * @return true if the upgrade succeeded, false otherwise
     */
    boolean upgradeRoom(UUID player);

    /**
     * Sells the player's room. The player will receive a refund equal to
     * half of the total amount they spent on their room, provided their
     * country's treasury has enough funds. The room will be reset to tier 0
     * and unowned.
     *
     * @param player Unique ID of the player
     * @return true if the sale succeeded, false otherwise
     */
    boolean sellRoom(UUID player);

    /**
     * Retrieves information about the player's room.
     *
     * @param player Unique ID of the player
     * @return RoomInfo object describing the room or null if the player has no room
     */
    com.civcore.model.RoomInfo getPlayerRoomInfo(UUID player);

    /**
     * Returns the entrance location for the specified player's room. The
     * entrance is defined in the configuration for the room plot. If the
     * player does not own a room, this method returns null.
     *
     * @param player Unique ID of the player
     * @return Entrance location for the player's room or null if none
     */
    org.bukkit.Location getRoomEntrance(UUID player);

    /**
     * Determines whether the given location lies within a defined room plot
     * and returns information about that room. If the location is not inside
     * any configured room, this method returns null.
     *
     * @param location Location to check
     * @return RoomInfo for the room at the location or null if none
     */
    com.civcore.model.RoomInfo getRoomAt(org.bukkit.Location location);

    /**
     * Returns a list of room IDs owned by the specified player. This method
     * remains for backward compatibility with previous phases. For CivCore Lite
     * only a single room per player is supported, so the list will contain at
     * most one entry.
     *
     * @param player Unique ID of the player
     * @return List of room IDs owned by the player
     */
    java.util.List<java.lang.Integer> listRooms(UUID player);
}