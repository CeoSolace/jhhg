package com.civcore.service;

import java.util.UUID;

/**
 * Defines the operations for a simple economy. Implementations may wrap
 * Vault or a custom ledger. This interface allows other modules to remain
 * decoupled from the underlying economy provider.
 */
public interface EconomyService {
    /**
     * Deposits an amount into the player's account.
     *
     * @param player Unique ID of the player
     * @param amount Amount to deposit
     */
    void deposit(UUID player, double amount);

    /**
     * Withdraws an amount from the player's account.
     *
     * @param player Unique ID of the player
     * @param amount Amount to withdraw
     * @return true if the withdrawal was successful
     */
    boolean withdraw(UUID player, double amount);

    /**
     * Retrieves the current balance of the player.
     *
     * @param player Unique ID of the player
     * @return The player's balance
     */
    double getBalance(UUID player);

    /**
     * Deposits a gross amount into the player's account after applying country tax.
     * The tax portion is added to the player's country's treasury. If the player
     * is not part of a country or the country has no tax configured, the full
     * amount is deposited.
     *
     * @param player     Unique ID of the player
     * @param grossAmount Amount before tax
     * @param reason      Reason for the deposit (used for logging or auditing)
     */
    void depositTaxed(UUID player, double grossAmount, String reason);
}