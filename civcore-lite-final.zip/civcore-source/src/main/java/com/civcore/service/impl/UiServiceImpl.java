package com.civcore.service.impl;

import com.civcore.CivCorePlugin;
import com.civcore.cache.PlayerProfile;
import com.civcore.cache.PlayerProfileCache;
import com.civcore.model.RoomInfo;
import com.civcore.service.CountryService;
import com.civcore.service.GovernmentService;
import com.civcore.service.HousingService;
import com.civcore.service.UiService;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.ScoreboardManager;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Implementation of {@link UiService} that provides a periodically updating
 * scoreboard for each player. The scoreboard displays key information about
 * the player's status, including their balance, country, tax rate, treasury,
 * job, role and housing. Scoreboards are updated at a configurable interval
 * and are cleaned up when players disconnect.
 */
public class UiServiceImpl implements UiService {
    private final CivCorePlugin plugin;
    private final ScoreboardManager scoreboardManager;
    private final Map<UUID, Scoreboard> boards = new HashMap<>();
    private int updateTaskId = -1;

    public UiServiceImpl(CivCorePlugin plugin) {
        this.plugin = plugin;
        this.scoreboardManager = Bukkit.getScoreboardManager();
    }

    @Override
    public void openMenu(Player player, String menuName) {
        // This implementation does not provide named menus. Future phases may
        // extend this method to open custom inventories.
    }

    /**
     * Starts the periodic scoreboard update task. This method should be
     * invoked once during plugin enable. The interval is read from the
     * configuration under 'ui.scoreboard-interval'. If already running,
     * the existing task will be cancelled and rescheduled.
     */
    public void start() {
        stop();
        int intervalSeconds = plugin.getConfig().getInt("ui.scoreboard-interval", 5);
        if (intervalSeconds < 1) intervalSeconds = 5;
        updateTaskId = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            for (Player player : Bukkit.getOnlinePlayers()) {
                updateScoreboard(player);
            }
        }, 20L, intervalSeconds * 20L).getTaskId();
    }

    /**
     * Cancels the scoreboard update task if it is running. This should be
     * invoked during plugin disable to prevent memory leaks.
     */
    public void stop() {
        if (updateTaskId != -1) {
            Bukkit.getScheduler().cancelTask(updateTaskId);
            updateTaskId = -1;
        }
    }

    /**
     * Initializes a scoreboard for the specified player. This will create
     * a new scoreboard if one does not already exist and assign it to the
     * player. Scoreboard objectives and display slots are set up here.
     *
     * @param player Player to initialize the scoreboard for
     */
    public void initScoreboard(Player player) {
        if (player == null) return;
        Scoreboard board = scoreboardManager.getNewScoreboard();
        Objective obj = board.registerNewObjective("civcore", "dummy", ChatColor.GOLD + "CivCore");
        obj.setDisplaySlot(DisplaySlot.SIDEBAR);
        boards.put(player.getUniqueId(), board);
        player.setScoreboard(board);
        updateScoreboard(player);
    }

    /**
     * Removes the scoreboard associated with the specified player and resets
     * them to the server's main scoreboard. This should be called when a
     * player disconnects to prevent memory leaks.
     *
     * @param player Player whose scoreboard should be removed
     */
    public void removeScoreboard(Player player) {
        if (player == null) return;
        boards.remove(player.getUniqueId());
        // Reset to a fresh scoreboard to clear old objectives
        if (scoreboardManager != null) {
            player.setScoreboard(scoreboardManager.getNewScoreboard());
        }
    }

    /**
     * Updates the scoreboard contents for a single player. This method will
     * build a series of lines representing the player's current status and
     * assign scores in descending order to control display ordering. If the
     * player does not yet have a scoreboard, it will be initialized.
     *
     * @param player Player whose scoreboard should be updated
     */
    public void updateScoreboard(Player player) {
        if (player == null) return;
        Scoreboard board = boards.get(player.getUniqueId());
        if (board == null) {
            initScoreboard(player);
            board = boards.get(player.getUniqueId());
            if (board == null) {
                return;
            }
        }
        Objective obj = board.getObjective("civcore");
        if (obj == null) {
            obj = board.registerNewObjective("civcore", "dummy", ChatColor.GOLD + "CivCore");
            obj.setDisplaySlot(DisplaySlot.SIDEBAR);
        }
        // Clear existing entries
        for (String entry : board.getEntries()) {
            board.resetScores(entry);
        }
        PlayerProfileCache profileCache = plugin.getProfileCache();
        PlayerProfile profile = profileCache.getProfile(player.getUniqueId(), player.getName());
        CountryService countryService = plugin.getCountryService();
        HousingService housingService = plugin.getHousingService();
        GovernmentService governmentService = plugin.getGovernmentService();
        double balance = plugin.getEconomyService().getBalance(player.getUniqueId());
        String currencySymbol = plugin.getConfig().getString("economy.currency-symbol", "$");
        String balanceStr = currencySymbol + String.format("%.2f", balance);
        String countryName = "None";
        String taxStr = "0%";
        String treasuryStr = "0";
        if (profile.getCountryId() != null) {
            int cId = profile.getCountryId();
            countryName = countryService.getCountry(cId).orElse("None");
            double tax = countryService.getTaxPercentage(cId);
            taxStr = String.format("%.1f%%", tax);
            double treasury = countryService.getTreasury(cId);
            treasuryStr = currencySymbol + String.format("%.2f", treasury);
        }
        String job = profile.getJob() != null ? profile.getJob() : "None";
        String role = governmentService.getPlayerRole(player.getUniqueId());
        if (role == null) role = "citizen";
        RoomInfo roomInfo = housingService.getPlayerRoomInfo(player.getUniqueId());
        String roomTier = roomInfo != null ? String.valueOf(roomInfo.getLevel()) : "0";
        String roomStatus = roomInfo != null ? "Owned" : "None";
        int score = 15;
        obj.getScore(ChatColor.AQUA + "Balance: " + ChatColor.WHITE + balanceStr).setScore(score--);
        obj.getScore(ChatColor.AQUA + "Country: " + ChatColor.WHITE + countryName).setScore(score--);
        obj.getScore(ChatColor.AQUA + "Tax: " + ChatColor.WHITE + taxStr).setScore(score--);
        obj.getScore(ChatColor.AQUA + "Treasury: " + ChatColor.WHITE + treasuryStr).setScore(score--);
        obj.getScore(ChatColor.AQUA + "Job: " + ChatColor.WHITE + job).setScore(score--);
        obj.getScore(ChatColor.AQUA + "Role: " + ChatColor.WHITE + role).setScore(score--);
        obj.getScore(ChatColor.AQUA + "Room Tier: " + ChatColor.WHITE + roomTier).setScore(score--);
        obj.getScore(ChatColor.AQUA + "Room: " + ChatColor.WHITE + roomStatus).setScore(score--);
    }
}