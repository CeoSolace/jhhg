package com.civcore.service;

import java.util.UUID;

/**
 * Encapsulates high-level government operations, such as enacting proposals,
 * managing leadership roles and overseeing country governance. This interface
 * allows the core plugin to remain decoupled from the specific government
 * implementation.
 */
public interface GovernmentService {
    /**
     * Enacts a proposal into law for the given country.
     *
     * @param countryId ID of the country
     * @param proposalId ID of the proposal to enact
     */
    void enactProposal(int countryId, int proposalId);

    /**
     * Assigns a player to a leadership role within their country.
     *
     * @param player Unique ID of the player
     * @param roleName Name of the role
     */
    void assignLeader(UUID player, String roleName);

    /**
     * Retrieves the current head of state for a country.
     *
     * @param countryId ID of the country
     * @return Unique ID of the player holding the head of state role
     */
    UUID getHeadOfState(int countryId);

    /**
     * Appoints a player to a specified role within their country. The
     * appointment is subject to the issuer's permissions and the role
     * hierarchy configured in the plugin. Returns true if the appointment
     * succeeds.
     *
     * @param issuer   Unique ID of the player issuing the appointment
     * @param target   Unique ID of the player to be appointed
     * @param roleName Name of the role to assign
     * @return true if appointment succeeded
     */
    boolean appointRole(UUID issuer, UUID target, String roleName);

    /**
     * Removes the current role of the specified player. The issuer must have
     * authority to remove the player's role. After removal the player will
     * assume the default citizen role.
     *
     * @param issuer Unique ID of the player performing the removal
     * @param target Unique ID of the player whose role is removed
     * @return true if removal succeeded
     */
    boolean removeRole(UUID issuer, UUID target);

    /**
     * Lists all roles within a country and the players assigned to each.
     *
     * @param countryId ID of the country
     * @return mapping of role names to lists of player UUIDs
     */
    java.util.Map<String, java.util.List<UUID>> listRoles(int countryId);

    /**
     * Retrieves the role name for a given player. Returns null if the player
     * has no role assigned.
     *
     * @param playerUuid Unique ID of the player
     * @return the name of the player's role or null
     */
    String getPlayerRole(UUID playerUuid);

    /**
     * Creates a new proposal for the specified law. Only eligible players may
     * propose. Returns the ID of the created proposal or -1 on failure.
     *
     * @param proposer   Unique ID of the proposing player
     * @param lawType    Type of the law being proposed
     * @param value      Proposed value (string representation)
     * @param description Human-readable description of the proposal
     * @return proposal ID or -1
     */
    int propose(UUID proposer, String lawType, String value, String description);

    /**
     * Casts a vote for the active proposal of the voter's country. Only one
     * vote per player is allowed and only players with appropriate roles may
     * vote. Returns true if the vote was recorded.
     *
     * @param voter Unique ID of the player voting
     * @param yes   true for a yes vote, false for a no vote
     * @return true if vote succeeded
     */
    boolean vote(UUID voter, boolean yes);

    /**
     * Checks whether the specified country currently has an active proposal.
     *
     * @param countryId ID of the country
     * @return true if a proposal is open
     */
    boolean hasActiveProposal(int countryId);
}