package com.civcore.service;

import org.bukkit.entity.Player;

/**
 * Provides user interface operations such as opening menus or inventories.
 * Implementations may use different GUI frameworks. The UI service allows
 * other modules to remain agnostic of the underlying UI mechanism.
 */
public interface UiService {
    /**
     * Opens a named menu for the specified player.
     *
     * @param player   Player to open the menu for
     * @param menuName Name or identifier of the menu
     */
    void openMenu(Player player, String menuName);
}