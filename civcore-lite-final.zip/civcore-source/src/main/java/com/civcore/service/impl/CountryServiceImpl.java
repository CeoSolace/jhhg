package com.civcore.service.impl;

import com.civcore.CivCorePlugin;
import com.civcore.cache.PlayerProfile;
import com.civcore.cache.PlayerProfileCache;
import com.civcore.database.SQLiteManager;
import com.civcore.service.CountryService;
import com.civcore.util.AsyncExecutor;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * Implementation of the {@link CountryService} interface backed by SQLite. This
 * class provides synchronous queries for reads and uses the plugin's
 * {@link AsyncExecutor} for writes to avoid blocking the main thread.
 */
public class CountryServiceImpl implements CountryService {
    private final CivCorePlugin plugin;
    private final SQLiteManager sqliteManager;
    private final AsyncExecutor executor;
    private final PlayerProfileCache profileCache;

    public CountryServiceImpl(CivCorePlugin plugin) {
        this.plugin = plugin;
        this.sqliteManager = plugin.getSQLiteManager();
        this.executor = plugin.getAsyncExecutor();
        this.profileCache = plugin.getProfileCache();
    }

    @Override
    public int createCountry(String name) {
        final int[] id = { -1 };
        try {
            Connection conn = sqliteManager.getConnection();
            try (PreparedStatement ps = conn.prepareStatement(
                    "INSERT INTO countries (name, treasury, tax_percentage) VALUES (?, 0, 0)",
                    PreparedStatement.RETURN_GENERATED_KEYS)) {
                ps.setString(1, name);
                ps.executeUpdate();
                try (ResultSet rs = ps.getGeneratedKeys()) {
                    if (rs.next()) {
                        id[0] = rs.getInt(1);
                    }
                }
            }
            conn.commit();
        } catch (SQLException e) {
            plugin.getLogger().severe("Failed to create country: " + e.getMessage());
        }
        return id[0];
    }

    @Override
    public Optional<String> getCountry(int countryId) {
        try {
            Connection conn = sqliteManager.getConnection();
            try (PreparedStatement ps = conn.prepareStatement(
                    "SELECT name FROM countries WHERE id = ?")) {
                ps.setInt(1, countryId);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        return Optional.ofNullable(rs.getString(1));
                    }
                }
            }
        } catch (SQLException e) {
            plugin.getLogger().severe("Failed to get country by ID: " + e.getMessage());
        }
        return Optional.empty();
    }

    @Override
    public List<String> listCountries() {
        List<String> names = new ArrayList<>();
        try {
            Connection conn = sqliteManager.getConnection();
            try (PreparedStatement ps = conn.prepareStatement("SELECT name FROM countries")) {
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        names.add(rs.getString(1));
                    }
                }
            }
        } catch (SQLException e) {
            plugin.getLogger().severe("Failed to list countries: " + e.getMessage());
        }
        return names;
    }

    @Override
    public void assignPlayer(UUID playerUuid, int countryId) {
        // Update cache first
        OfflinePlayer offline = Bukkit.getOfflinePlayer(playerUuid);
        PlayerProfile profile = profileCache.getProfile(playerUuid, offline.getName() != null ? offline.getName() : playerUuid.toString());
        profile.setCountryId(countryId);
        profileCache.saveProfile(profile);

        // Update DB asynchronously
        executor.runAsync(() -> {
            try {
                Connection conn = sqliteManager.getConnection();
                String sql = "UPDATE players SET country_id = ? WHERE uuid = ?";
                try (PreparedStatement ps = conn.prepareStatement(sql)) {
                    ps.setInt(1, countryId);
                    ps.setString(2, playerUuid.toString());
                    ps.executeUpdate();
                }
                conn.commit();
            } catch (SQLException e) {
                plugin.getLogger().severe("Failed to assign player to country: " + e.getMessage());
            }
        });
    }

    @Override
    public Optional<Integer> getCountryIdByName(String name) {
        try {
            Connection conn = sqliteManager.getConnection();
            try (PreparedStatement ps = conn.prepareStatement("SELECT id FROM countries WHERE name = ?")) {
                ps.setString(1, name);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        return Optional.of(rs.getInt(1));
                    }
                }
            }
        } catch (SQLException e) {
            plugin.getLogger().severe("Failed to get country ID by name: " + e.getMessage());
        }
        return Optional.empty();
    }

    @Override
    public double getTaxPercentage(int countryId) {
        double tax = 0.0;
        try {
            Connection conn = sqliteManager.getConnection();
            try (PreparedStatement ps = conn.prepareStatement("SELECT tax_percentage FROM countries WHERE id = ?")) {
                ps.setInt(1, countryId);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        tax = rs.getDouble(1);
                    }
                }
            }
        } catch (SQLException e) {
            plugin.getLogger().severe("Failed to get tax percentage: " + e.getMessage());
        }
        return tax;
    }

    @Override
    public double getTreasury(int countryId) {
        double treasury = 0.0;
        try {
            Connection conn = sqliteManager.getConnection();
            try (PreparedStatement ps = conn.prepareStatement("SELECT treasury FROM countries WHERE id = ?")) {
                ps.setInt(1, countryId);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        treasury = rs.getDouble(1);
                    }
                }
            }
        } catch (SQLException e) {
            plugin.getLogger().severe("Failed to get treasury: " + e.getMessage());
        }
        return treasury;
    }

    @Override
    public void addToTreasury(int countryId, double amount) {
        if (amount <= 0) return;
        executor.runAsync(() -> {
            try {
                Connection conn = sqliteManager.getConnection();
                String sql = "UPDATE countries SET treasury = COALESCE(treasury, 0) + ? WHERE id = ?";
                try (PreparedStatement ps = conn.prepareStatement(sql)) {
                    ps.setDouble(1, amount);
                    ps.setInt(2, countryId);
                    ps.executeUpdate();
                }
                conn.commit();
            } catch (SQLException e) {
                plugin.getLogger().severe("Failed to add to country treasury: " + e.getMessage());
            }
        });
    }

    @Override
    public List<String> getCitizens(int countryId) {
        List<String> names = new ArrayList<>();
        try {
            Connection conn = sqliteManager.getConnection();
            String sql = "SELECT name FROM players WHERE country_id = ?";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, countryId);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        names.add(rs.getString(1));
                    }
                }
            }
        } catch (SQLException e) {
            plugin.getLogger().severe("Failed to get citizens: " + e.getMessage());
        }
        return names;
    }
}