package com.civcore.service.impl;

import com.civcore.CivCorePlugin;
import com.civcore.cache.PlayerProfile;
import com.civcore.cache.PlayerProfileCache;
import com.civcore.service.CountryService;
import com.civcore.service.GovernmentService;
import com.civcore.service.LawService;
import org.bukkit.Bukkit;
import org.bukkit.scheduler.BukkitTask;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

/**
 * Implementation of the {@link GovernmentService} interface. This class handles
 * appointments, removals, proposals and voting for country governments. It
 * persists state in the existing SQLite tables and uses the server scheduler
 * to evaluate proposals after a configured duration.
 */
public class GovernmentServiceImpl implements GovernmentService {

    private final CivCorePlugin plugin;
    private final com.civcore.database.SQLiteManager sqliteManager;
    private final CountryService countryService;
    private final LawService lawService;
    private final PlayerProfileCache profileCache;
    // Active proposal tasks keyed by country ID to cancel if replaced
    private final Map<Integer, BukkitTask> proposalTasks = new HashMap<>();

    public GovernmentServiceImpl(CivCorePlugin plugin) {
        this.plugin = plugin;
        this.sqliteManager = plugin.getSQLiteManager();
        this.countryService = plugin.getCountryService();
        this.lawService = plugin.getLawService();
        this.profileCache = plugin.getProfileCache();
    }

    // ---------------- GovernmentService interface methods ------------------

    @Override
    public void enactProposal(int countryId, int proposalId) {
        // Not directly used: enactment happens via scheduled evaluation.
        evaluateProposal(countryId, proposalId);
    }

    @Override
    public void assignLeader(java.util.UUID player, String roleName) {
        // Assign the player as leader in their country. We ignore roleName since
        // the leader role is fixed. Determine player's country from profile.
        PlayerProfile profile = profileCache.getProfile(player, Bukkit.getOfflinePlayer(player).getName());
        Integer countryId = profile.getCountryId();
        if (countryId == null) {
            return;
        }
        // Update player's role to leader
        appointRole(player, player, "leader");
        // Update leader_uuid in countries table
        try {
            Connection conn = sqliteManager.getConnection();
            try (PreparedStatement ps = conn.prepareStatement(
                    "UPDATE countries SET leader_uuid = ? WHERE id = ?")) {
                ps.setString(1, player.toString());
                ps.setInt(2, countryId);
                ps.executeUpdate();
            }
            conn.commit();
        } catch (SQLException e) {
            plugin.getLogger().warning("Failed to assign leader: " + e.getMessage());
        }
    }

    @Override
    public java.util.UUID getHeadOfState(int countryId) {
        try {
            Connection conn = sqliteManager.getConnection();
            try (PreparedStatement ps = conn.prepareStatement(
                    "SELECT leader_uuid FROM countries WHERE id = ?")) {
                ps.setInt(1, countryId);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        String uuidStr = rs.getString(1);
                        if (uuidStr != null) {
                            return java.util.UUID.fromString(uuidStr);
                        }
                    }
                }
            }
        } catch (SQLException e) {
            plugin.getLogger().warning("Failed to get head of state: " + e.getMessage());
        }
        return null;
    }

    // ---------------- Extended operations ------------------

    @Override
    public boolean appointRole(java.util.UUID issuerUuid, java.util.UUID targetUuid, String roleName) {
        PlayerProfile issuerProfile = profileCache.getProfile(issuerUuid, Bukkit.getOfflinePlayer(issuerUuid).getName());
        PlayerProfile targetProfile = profileCache.getProfile(targetUuid, Bukkit.getOfflinePlayer(targetUuid).getName());
        Integer issuerCountry = issuerProfile.getCountryId();
        Integer targetCountry = targetProfile.getCountryId();
        if (issuerCountry == null || targetCountry == null || !issuerCountry.equals(targetCountry)) {
            return false; // Must be same country
        }
        String issuerRole = getPlayerRole(issuerUuid);
        if (issuerRole == null) {
            return false;
        }
        // Determine if issuer can appoint the specified role
        if (!canAppoint(issuerRole, roleName)) {
            return false;
        }
        // Look up role ID
        int roleId = getRoleId(issuerCountry, roleName);
        if (roleId < 0) {
            return false;
        }
        // Update player's role in DB and cache
        targetProfile.setRoleId(roleId);
        profileCache.saveProfile(targetProfile);
        try {
            Connection conn = sqliteManager.getConnection();
            try (PreparedStatement ps = conn.prepareStatement(
                    "UPDATE players SET role_id = ? WHERE uuid = ?")) {
                ps.setInt(1, roleId);
                ps.setString(2, targetUuid.toString());
                ps.executeUpdate();
            }
            // If appointing leader, update leader_uuid
            if (roleName.equalsIgnoreCase("leader")) {
                try (PreparedStatement ps = conn.prepareStatement(
                        "UPDATE countries SET leader_uuid = ? WHERE id = ?")) {
                    ps.setString(1, targetUuid.toString());
                    ps.setInt(2, issuerCountry);
                    ps.executeUpdate();
                }
            }
            conn.commit();
            return true;
        } catch (SQLException e) {
            plugin.getLogger().warning("Failed to appoint role: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean removeRole(java.util.UUID issuerUuid, java.util.UUID targetUuid) {
        // Only leader can remove roles
        String issuerRole = getPlayerRole(issuerUuid);
        if (issuerRole == null || !issuerRole.equalsIgnoreCase("leader")) {
            return false;
        }
        PlayerProfile targetProfile = profileCache.getProfile(targetUuid, Bukkit.getOfflinePlayer(targetUuid).getName());
        Integer countryId = targetProfile.getCountryId();
        if (countryId == null) {
            return false;
        }
        // Get citizen role ID
        int citizenId = getRoleId(countryId, "citizen");
        if (citizenId < 0) {
            return false;
        }
        targetProfile.setRoleId(citizenId);
        profileCache.saveProfile(targetProfile);
        try {
            Connection conn = sqliteManager.getConnection();
            try (PreparedStatement ps = conn.prepareStatement(
                    "UPDATE players SET role_id = ? WHERE uuid = ?")) {
                ps.setInt(1, citizenId);
                ps.setString(2, targetUuid.toString());
                ps.executeUpdate();
            }
            // If removing leader, clear leader_uuid
            String targetRole = getPlayerRole(targetUuid);
            if (targetRole != null && targetRole.equalsIgnoreCase("leader")) {
                try (PreparedStatement ps = conn.prepareStatement(
                        "UPDATE countries SET leader_uuid = NULL WHERE id = ?")) {
                    ps.setInt(1, countryId);
                    ps.executeUpdate();
                }
            }
            conn.commit();
            return true;
        } catch (SQLException e) {
            plugin.getLogger().warning("Failed to remove role: " + e.getMessage());
            return false;
        }
    }

    @Override
    public Map<String, List<java.util.UUID>> listRoles(int countryId) {
        Map<String, List<java.util.UUID>> map = new HashMap<>();
        try {
            Connection conn = sqliteManager.getConnection();
            // Retrieve all roles for the country
            Map<Integer, String> roleNames = new HashMap<>();
            try (PreparedStatement ps = conn.prepareStatement(
                    "SELECT id, name FROM roles WHERE country_id = ?")) {
                ps.setInt(1, countryId);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        roleNames.put(rs.getInt(1), rs.getString(2));
                    }
                }
            }
            // For each role, find players
            for (Map.Entry<Integer, String> entry : roleNames.entrySet()) {
                int roleId = entry.getKey();
                String roleName = entry.getValue();
                List<java.util.UUID> players = new ArrayList<>();
                try (PreparedStatement ps = conn.prepareStatement(
                        "SELECT uuid FROM players WHERE country_id = ? AND role_id = ?")) {
                    ps.setInt(1, countryId);
                    ps.setInt(2, roleId);
                    try (ResultSet rs = ps.executeQuery()) {
                        while (rs.next()) {
                            String uuidStr = rs.getString(1);
                            try {
                                players.add(java.util.UUID.fromString(uuidStr));
                            } catch (IllegalArgumentException ex) {
                                // Ignore invalid UUIDs
                            }
                        }
                    }
                }
                map.put(roleName, players);
            }
        } catch (SQLException e) {
            plugin.getLogger().warning("Failed to list roles: " + e.getMessage());
        }
        return map;
    }

    @Override
    public String getPlayerRole(java.util.UUID playerUuid) {
        // Use cached role ID if available
        PlayerProfile profile = profileCache.getProfile(playerUuid, Bukkit.getOfflinePlayer(playerUuid).getName());
        Integer roleId = profile.getRoleId();
        if (roleId == null) {
            // If no role ID, treat as citizen
            return "citizen";
        }
        try {
            Connection conn = sqliteManager.getConnection();
            try (PreparedStatement ps = conn.prepareStatement(
                    "SELECT name FROM roles WHERE id = ?")) {
                ps.setInt(1, roleId);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        return rs.getString(1);
                    }
                }
            }
        } catch (SQLException e) {
            plugin.getLogger().warning("Failed to get player role: " + e.getMessage());
        }
        return null;
    }

    @Override
    public int propose(java.util.UUID proposerUuid, String lawType, String value, String description) {
        PlayerProfile profile = profileCache.getProfile(proposerUuid, Bukkit.getOfflinePlayer(proposerUuid).getName());
        Integer countryId = profile.getCountryId();
        if (countryId == null) {
            return -1;
        }
        // Check player role eligibility (leader, minister, parliament)
        String role = getPlayerRole(proposerUuid);
        if (role == null || !(role.equalsIgnoreCase("leader") || role.equalsIgnoreCase("minister") || role.equalsIgnoreCase("parliament"))) {
            return -1;
        }
        // Ensure there is no active proposal
        if (hasActiveProposal(countryId)) {
            return -1;
        }
        // Create proposal
        int proposalId = -1;
        String status = "OPEN";
        String content = value + "::" + (description != null ? description : "");
        try {
            Connection conn = sqliteManager.getConnection();
            try (PreparedStatement ps = conn.prepareStatement(
                    "INSERT INTO proposals (country_id, player_uuid, title, content, status) VALUES (?, ?, ?, ?, ?)", PreparedStatement.RETURN_GENERATED_KEYS)) {
                ps.setInt(1, countryId);
                ps.setString(2, proposerUuid.toString());
                ps.setString(3, lawType);
                ps.setString(4, content);
                ps.setString(5, status);
                ps.executeUpdate();
                try (ResultSet rs = ps.getGeneratedKeys()) {
                    if (rs.next()) {
                        proposalId = rs.getInt(1);
                    }
                }
            }
            conn.commit();
        } catch (SQLException e) {
            plugin.getLogger().warning("Failed to create proposal: " + e.getMessage());
            return -1;
        }
        if (proposalId < 0) {
            return -1;
        }
        // Schedule evaluation after configured duration
        long seconds = plugin.getConfig().getLong("laws.proposal-duration", 300L);
        long ticks = seconds * 20L;
        // Cancel any existing task for this country
        BukkitTask existing = proposalTasks.get(countryId);
        if (existing != null) {
            existing.cancel();
        }
        BukkitTask task = Bukkit.getScheduler().runTaskLater(plugin, () -> evaluateProposal(countryId, proposalId), ticks);
        proposalTasks.put(countryId, task);
        return proposalId;
    }

    @Override
    public boolean vote(java.util.UUID voterUuid, boolean yes) {
        PlayerProfile profile = profileCache.getProfile(voterUuid, Bukkit.getOfflinePlayer(voterUuid).getName());
        Integer countryId = profile.getCountryId();
        if (countryId == null) return false;
        // Check player's role eligibility to vote
        String role = getPlayerRole(voterUuid);
        if (role == null || !(role.equalsIgnoreCase("leader") || role.equalsIgnoreCase("minister") || role.equalsIgnoreCase("parliament"))) {
            return false;
        }
        // Find active proposal
        int proposalId = getActiveProposalId(countryId);
        if (proposalId < 0) {
            return false;
        }
        // Check if already voted
        try {
            Connection conn = sqliteManager.getConnection();
            try (PreparedStatement ps = conn.prepareStatement(
                    "SELECT COUNT(*) FROM votes WHERE proposal_id = ? AND player_uuid = ?")) {
                ps.setInt(1, proposalId);
                ps.setString(2, voterUuid.toString());
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next() && rs.getInt(1) > 0) {
                        return false;
                    }
                }
            }
            // Insert vote
            try (PreparedStatement ps = conn.prepareStatement(
                    "INSERT INTO votes (proposal_id, player_uuid, vote) VALUES (?, ?, ?)")) {
                ps.setInt(1, proposalId);
                ps.setString(2, voterUuid.toString());
                ps.setInt(3, yes ? 1 : 0);
                ps.executeUpdate();
            }
            conn.commit();
            return true;
        } catch (SQLException e) {
            plugin.getLogger().warning("Failed to record vote: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean hasActiveProposal(int countryId) {
        return getActiveProposalId(countryId) >= 0;
    }

    // ---------------- Private helpers ------------------

    /**
     * Determines whether the issuer role is permitted to appoint the target role.
     *
     * @param issuerRole role of issuer
     * @param targetRole role to assign
     * @return true if issuer can appoint
     */
    private boolean canAppoint(String issuerRole, String targetRole) {
        if (issuerRole == null || targetRole == null) {
            return false;
        }
        issuerRole = issuerRole.toLowerCase(Locale.ROOT);
        targetRole = targetRole.toLowerCase(Locale.ROOT);
        if (issuerRole.equals("leader")) {
            return true;
        }
        if (issuerRole.equals("minister")) {
            return targetRole.equals("staff");
        }
        return false;
    }

    /**
     * Retrieves the role ID for the given name and country.
     */
    private int getRoleId(int countryId, String roleName) {
        try {
            Connection conn = sqliteManager.getConnection();
            try (PreparedStatement ps = conn.prepareStatement(
                    "SELECT id FROM roles WHERE country_id = ? AND name = ?")) {
                ps.setInt(1, countryId);
                ps.setString(2, roleName.toLowerCase(Locale.ROOT));
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        return rs.getInt(1);
                    }
                }
            }
        } catch (SQLException e) {
            plugin.getLogger().warning("Failed to get role ID: " + e.getMessage());
        }
        return -1;
    }

    /**
     * Returns the ID of the active proposal for the specified country or -1 if none exists.
     */
    private int getActiveProposalId(int countryId) {
        try {
            Connection conn = sqliteManager.getConnection();
            try (PreparedStatement ps = conn.prepareStatement(
                    "SELECT id FROM proposals WHERE country_id = ? AND status = 'OPEN'")) {
                ps.setInt(1, countryId);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        return rs.getInt(1);
                    }
                }
            }
        } catch (SQLException e) {
            plugin.getLogger().warning("Failed to get active proposal: " + e.getMessage());
        }
        return -1;
    }

    /**
     * Evaluates the specified proposal for a country. Counts votes and either
     * enacts the law or rejects the proposal. This method runs on the main
     * thread and should be scheduled via Bukkit scheduler.
     */
    private void evaluateProposal(int countryId, int proposalId) {
        // Remove the scheduled task entry
        proposalTasks.remove(countryId);
        // Count votes
        int yesCount = 0;
        int noCount = 0;
        String lawType = null;
        String content = null;
        try {
            Connection conn = sqliteManager.getConnection();
            // Fetch proposal info
            try (PreparedStatement ps = conn.prepareStatement(
                    "SELECT title, content FROM proposals WHERE id = ?")) {
                ps.setInt(1, proposalId);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        lawType = rs.getString(1);
                        content = rs.getString(2);
                    }
                }
            }
            // Count votes
            try (PreparedStatement ps = conn.prepareStatement(
                    "SELECT vote, COUNT(*) FROM votes WHERE proposal_id = ? GROUP BY vote")) {
                ps.setInt(1, proposalId);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        int vote = rs.getInt(1);
                        int count = rs.getInt(2);
                        if (vote == 1) yesCount += count; else noCount += count;
                    }
                }
            }
            boolean approved = yesCount > noCount;
            // Update proposal status
            try (PreparedStatement ps = conn.prepareStatement(
                    "UPDATE proposals SET status = ? WHERE id = ?")) {
                ps.setString(1, approved ? "APPROVED" : "REJECTED");
                ps.setInt(2, proposalId);
                ps.executeUpdate();
            }
            conn.commit();
        } catch (SQLException e) {
            plugin.getLogger().warning("Failed to evaluate proposal: " + e.getMessage());
            return;
        }
        if (lawType != null && content != null && yesCount + noCount > 0) {
            if (yesCount > noCount) {
                // Parse value and description
                String[] parts = content.split("::", 2);
                String value = parts.length > 0 ? parts[0] : "";
                // Enact the law via LawService
                lawService.setLaw(countryId, lawType, value);
                plugin.getLogger().info("Proposal for " + lawType + " approved in country " + countryId + ".");
            } else {
                plugin.getLogger().info("Proposal for " + lawType + " rejected in country " + countryId + ".");
            }
        }
    }
}