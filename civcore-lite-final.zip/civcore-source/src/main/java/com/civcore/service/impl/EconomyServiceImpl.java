package com.civcore.service.impl;

import com.civcore.CivCorePlugin;
import com.civcore.cache.PlayerProfile;
import com.civcore.cache.PlayerProfileCache;
import com.civcore.service.CountryService;
import com.civcore.service.EconomyService;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;

import java.util.UUID;

/**
 * Implementation of the {@link com.civcore.service.EconomyService} interface. This class
 * manages player balances and handles taxable deposits. All writes are
 * delegated to the {@link PlayerProfileCache} which performs asynchronous
 * persistence to SQLite via the plugin's {@link com.civcore.util.AsyncExecutor}.
 */
public class EconomyServiceImpl implements EconomyService {

    private final CivCorePlugin plugin;
    private final PlayerProfileCache profileCache;
    private final CountryService countryService;

    public EconomyServiceImpl(CivCorePlugin plugin) {
        this.plugin = plugin;
        this.profileCache = plugin.getProfileCache();
        // Note: CountryService is set after construction in CivCorePlugin
        this.countryService = plugin.getCountryService();
    }

    @Override
    public void deposit(UUID playerUuid, double amount) {
        if (amount <= 0) {
            return;
        }
        // Obtain player name via OfflinePlayer for accurate casing
        OfflinePlayer offline = Bukkit.getOfflinePlayer(playerUuid);
        String name = offline.getName() != null ? offline.getName() : playerUuid.toString();
        PlayerProfile profile = profileCache.getProfile(playerUuid, name);
        profile.setBalance(profile.getBalance() + amount);
        profileCache.saveProfile(profile);
    }

    @Override
    public boolean withdraw(UUID playerUuid, double amount) {
        if (amount <= 0) {
            return true;
        }
        OfflinePlayer offline = Bukkit.getOfflinePlayer(playerUuid);
        String name = offline.getName() != null ? offline.getName() : playerUuid.toString();
        PlayerProfile profile = profileCache.getProfile(playerUuid, name);
        double balance = profile.getBalance();
        if (balance < amount) {
            return false;
        }
        profile.setBalance(balance - amount);
        profileCache.saveProfile(profile);
        return true;
    }

    @Override
    public double getBalance(UUID playerUuid) {
        OfflinePlayer offline = Bukkit.getOfflinePlayer(playerUuid);
        String name = offline.getName() != null ? offline.getName() : playerUuid.toString();
        PlayerProfile profile = profileCache.getProfile(playerUuid, name);
        return profile.getBalance();
    }

    @Override
    public void depositTaxed(UUID playerUuid, double grossAmount, String reason) {
        if (grossAmount <= 0) {
            return;
        }
        OfflinePlayer offline = Bukkit.getOfflinePlayer(playerUuid);
        String name = offline.getName() != null ? offline.getName() : playerUuid.toString();
        PlayerProfile profile = profileCache.getProfile(playerUuid, name);
        double taxAmount = 0.0;
        double netAmount = grossAmount;
        Integer countryId = profile.getCountryId();
        if (countryId != null) {
            double taxPercentage = countryService.getTaxPercentage(countryId);
            if (taxPercentage > 0) {
                taxAmount = grossAmount * (taxPercentage / 100.0);
                netAmount = grossAmount - taxAmount;
            }
        }
        // Deposit net amount to player
        profile.setBalance(profile.getBalance() + netAmount);
        profileCache.saveProfile(profile);
        // Add tax to treasury asynchronously
        if (taxAmount > 0 && countryId != null) {
            countryService.addToTreasury(countryId, taxAmount);
        }
        // Reason is currently unused but may be logged in the future
    }
}