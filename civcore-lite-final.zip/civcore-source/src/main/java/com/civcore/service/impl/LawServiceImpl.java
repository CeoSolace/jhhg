package com.civcore.service.impl;

import com.civcore.CivCorePlugin;
import com.civcore.service.LawService;
import com.civcore.service.CountryService;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Concrete implementation of the {@link LawService} interface. This class
 * persists law definitions to the SQLite database and provides methods
 * for retrieving and updating law values. It also applies side effects
 * such as updating country tax percentages when tax laws change.
 */
public class LawServiceImpl implements LawService {

    private final CivCorePlugin plugin;
    private final com.civcore.database.SQLiteManager sqliteManager;
    private final CountryService countryService;

    public LawServiceImpl(CivCorePlugin plugin) {
        this.plugin = plugin;
        this.sqliteManager = plugin.getSQLiteManager();
        this.countryService = plugin.getCountryService();
    }

    @Override
    public int proposeLaw(int countryId, String title, String content) {
        // Not used in Phase 5. Law proposals are handled via GovernmentService.
        // This method creates a proposal immediately as an enacted law.
        try {
            Connection conn = sqliteManager.getConnection();
            try (PreparedStatement ps = conn.prepareStatement(
                    "INSERT INTO laws (country_id, title, content) VALUES (?, ?, ?)", PreparedStatement.RETURN_GENERATED_KEYS)) {
                ps.setInt(1, countryId);
                ps.setString(2, title);
                ps.setString(3, content);
                ps.executeUpdate();
                try (ResultSet rs = ps.getGeneratedKeys()) {
                    if (rs.next()) {
                        conn.commit();
                        return rs.getInt(1);
                    }
                }
            }
        } catch (SQLException e) {
            plugin.getLogger().warning("Failed to propose law: " + e.getMessage());
        }
        return -1;
    }

    @Override
    public void repealLaw(int lawId) {
        try {
            Connection conn = sqliteManager.getConnection();
            try (PreparedStatement ps = conn.prepareStatement(
                    "DELETE FROM laws WHERE id = ?")) {
                ps.setInt(1, lawId);
                ps.executeUpdate();
            }
            conn.commit();
        } catch (SQLException e) {
            plugin.getLogger().warning("Failed to repeal law: " + e.getMessage());
        }
    }

    @Override
    public List<Integer> listLaws(int countryId) {
        List<Integer> ids = new ArrayList<>();
        try {
            Connection conn = sqliteManager.getConnection();
            try (PreparedStatement ps = conn.prepareStatement(
                    "SELECT id FROM laws WHERE country_id = ?")) {
                ps.setInt(1, countryId);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        ids.add(rs.getInt(1));
                    }
                }
            }
        } catch (SQLException e) {
            plugin.getLogger().warning("Failed to list laws: " + e.getMessage());
        }
        return ids;
    }

    @Override
    public double getDoubleLaw(int countryId, String lawType) {
        String value = getLawString(countryId, lawType);
        if (value == null || value.isEmpty()) {
            return 0.0;
        }
        try {
            return Double.parseDouble(value);
        } catch (NumberFormatException e) {
            return 0.0;
        }
    }

    @Override
    public boolean getBooleanLaw(int countryId, String lawType) {
        String value = getLawString(countryId, lawType);
        if (value == null) {
            return false;
        }
        return Boolean.parseBoolean(value);
    }

    @Override
    public Map<String, String> getAllLaws(int countryId) {
        Map<String, String> map = new HashMap<>();
        try {
            Connection conn = sqliteManager.getConnection();
            try (PreparedStatement ps = conn.prepareStatement(
                    "SELECT title, content FROM laws WHERE country_id = ?")) {
                ps.setInt(1, countryId);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        map.put(rs.getString("title"), rs.getString("content"));
                    }
                }
            }
        } catch (SQLException e) {
            plugin.getLogger().warning("Failed to get all laws: " + e.getMessage());
        }
        return map;
    }

    @Override
    public void setLaw(int countryId, String lawType, String value) {
        try {
            Connection conn = sqliteManager.getConnection();
            // Insert or replace the law value
            try (PreparedStatement ps = conn.prepareStatement(
                    "INSERT OR REPLACE INTO laws (country_id, title, content) VALUES (?, ?, ?)")) {
                ps.setInt(1, countryId);
                ps.setString(2, lawType);
                ps.setString(3, value);
                ps.executeUpdate();
            }
            // Apply side effects for certain laws
            if (lawType.equalsIgnoreCase("TAX_RATE")) {
                // Update country tax percentage
                try (PreparedStatement ps = conn.prepareStatement(
                        "UPDATE countries SET tax_percentage = ? WHERE id = ?")) {
                    try {
                        double tax = Double.parseDouble(value);
                        ps.setDouble(1, tax);
                    } catch (NumberFormatException e) {
                        ps.setDouble(1, 0.0);
                    }
                    ps.setInt(2, countryId);
                    ps.executeUpdate();
                }
            }
            conn.commit();
        } catch (SQLException e) {
            plugin.getLogger().warning("Failed to set law: " + e.getMessage());
        }
    }

    /**
     * Retrieves the raw string value for the given law or null if not found.
     */
    private String getLawString(int countryId, String lawType) {
        try {
            Connection conn = sqliteManager.getConnection();
            try (PreparedStatement ps = conn.prepareStatement(
                    "SELECT content FROM laws WHERE country_id = ? AND title = ?")) {
                ps.setInt(1, countryId);
                ps.setString(2, lawType);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        return rs.getString(1);
                    }
                }
            }
        } catch (SQLException e) {
            plugin.getLogger().warning("Failed to get law value: " + e.getMessage());
        }
        return null;
    }
}