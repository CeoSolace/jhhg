package com.civcore.service;

import java.util.List;
import java.util.UUID;

/**
 * Manages jobs and work assignments for players. Jobs provide tasks with
 * rewards and may be tied to specific countries or roles.
 */
public interface JobService {
    /**
     * Creates a new job.
     *
     * @param countryId   ID of the country offering the job
     * @param name        Name of the job
     * @param description Description of the job
     * @param reward      Reward for completing the job
     * @return ID of the newly created job
     */
    int createJob(int countryId, String name, String description, double reward);

    /**
     * Assigns a job to a player.
     *
     * @param player Unique ID of the player
     * @param jobId  ID of the job to assign
     */
    void assignJob(UUID player, int jobId);

    /**
     * Marks a job as completed for a player and awards the reward.
     *
     * @param player Unique ID of the player
     * @param jobId  ID of the job to complete
     */
    void completeJob(UUID player, int jobId);

    /**
     * Retrieves a list of available job IDs for a given country.
     *
     * @param countryId ID of the country
     * @return List of job IDs
     */
    List<Integer> listJobs(int countryId);
}