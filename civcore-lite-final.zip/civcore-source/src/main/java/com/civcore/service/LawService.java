package com.civcore.service;

import java.util.List;

/**
 * Handles creation, retrieval and removal of laws within countries. Laws are
 * rules enacted by proposals and influence various aspects of gameplay.
 */
public interface LawService {
    /**
     * Proposes a new law for a country.
     *
     * @param countryId ID of the country
     * @param title     Title of the law
     * @param content   Description or text of the law
     * @return ID of the newly created law proposal
     */
    int proposeLaw(int countryId, String title, String content);

    /**
     * Removes a law from a country.
     *
     * @param lawId ID of the law to remove
     */
    void repealLaw(int lawId);

    /**
     * Retrieves the IDs of all active laws for a country.
     *
     * @param countryId ID of the country
     * @return list of law IDs
     */
    List<Integer> listLaws(int countryId);

    /**
     * Retrieves the value of a law as a double. If the law is not defined for
     * the specified country, a default of 0 is returned.
     *
     * @param countryId ID of the country
     * @param lawType   Law type identifier (e.g. TAX_RATE)
     * @return numeric value of the law or 0 if undefined
     */
    double getDoubleLaw(int countryId, String lawType);

    /**
     * Retrieves the value of a law as a boolean. Returns false if the law
     * is not defined or cannot be parsed as a boolean.
     *
     * @param countryId ID of the country
     * @param lawType   Law type identifier
     * @return boolean law value
     */
    boolean getBooleanLaw(int countryId, String lawType);

    /**
     * Retrieves all laws for a country as a map of law type to value string.
     *
     * @param countryId ID of the country
     * @return map of law type to value
     */
    java.util.Map<String, String> getAllLaws(int countryId);

    /**
     * Sets or updates the value of a law for a country.
     *
     * @param countryId ID of the country
     * @param lawType   Law type identifier
     * @param value     New value for the law
     */
    void setLaw(int countryId, String lawType, String value);
}