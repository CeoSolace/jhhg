package com.civcore.cache;

import java.util.UUID;

/**
 * Represents a cached player profile. Profiles are loaded from the database
 * when players join and stored in memory for quick access. When the plugin
 * shuts down or a player quits, profiles should be saved back to the
 * database.
 */
public class PlayerProfile {
    private final UUID uuid;
    private String name;
    private Integer countryId;
    private Integer roleId;
    private double balance;

    /**
     * The player's currently selected job. Jobs determine how a player earns
     * money through in-game activities. This value is persisted in the
     * players table.
     */
    private String job;

    public PlayerProfile(UUID uuid, String name) {
        this.uuid = uuid;
        this.name = name;
    }

    public UUID getUuid() {
        return uuid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getCountryId() {
        return countryId;
    }

    public void setCountryId(Integer countryId) {
        this.countryId = countryId;
    }

    public Integer getRoleId() {
        return roleId;
    }

    public void setRoleId(Integer roleId) {
        this.roleId = roleId;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    /**
     * Gets the player's selected job.
     *
     * @return the job name or null if none
     */
    public String getJob() {
        return job;
    }

    /**
     * Sets the player's selected job.
     *
     * @param job the job name
     */
    public void setJob(String job) {
        this.job = job;
    }
}