package com.civcore.cache;

import com.civcore.CivCorePlugin;
import com.civcore.util.AsyncExecutor;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * In-memory cache of player profiles. Profiles are loaded lazily from the
 * database and stored in a map keyed by player UUID. All database operations
 * are executed asynchronously via the plugin's AsyncExecutor to avoid
 * blocking the server thread.
 */
public class PlayerProfileCache {
    private final CivCorePlugin plugin;
    private final AsyncExecutor executor;
    private final Map<UUID, PlayerProfile> cache = new HashMap<>();

    public PlayerProfileCache(CivCorePlugin plugin) {
        this.plugin = plugin;
        this.executor = plugin.getAsyncExecutor();
    }

    /**
     * Retrieves a player's profile from the cache or loads it from the
     * database if not present. The returned profile is loaded synchronously
     * but should ideally be called asynchronously.
     *
     * @param uuid The player's UUID
     * @param name The player's current username
     * @return The player's profile
     */
    public PlayerProfile getProfile(UUID uuid, String name) {
        return cache.computeIfAbsent(uuid, id -> {
            PlayerProfile profile = loadProfile(id);
            if (profile == null) {
                profile = new PlayerProfile(id, name);
            } else {
                profile.setName(name);
            }
            return profile;
        });
    }

    /**
     * Loads a player profile from the database. If the profile does not exist,
     * returns null.
     *
     * @param uuid The player's UUID
     * @return The loaded profile or null
     */
    private PlayerProfile loadProfile(UUID uuid) {
        try {
            Connection conn = plugin.getSQLiteManager().getConnection();
            String sql = "SELECT uuid, name, country_id, role_id, balance, job FROM players WHERE uuid = ?";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, uuid.toString());
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        PlayerProfile profile = new PlayerProfile(UUID.fromString(rs.getString("uuid")), rs.getString("name"));
                        int countryId = rs.getInt("country_id");
                        if (!rs.wasNull()) profile.setCountryId(countryId);
                        int roleId = rs.getInt("role_id");
                        if (!rs.wasNull()) profile.setRoleId(roleId);
                        profile.setBalance(rs.getDouble("balance"));
                        String job = rs.getString("job");
                        if (job != null) profile.setJob(job);
                        return profile;
                    }
                }
            }
        } catch (SQLException e) {
            plugin.getLogger().severe("Failed to load player profile: " + e.getMessage());
        }
        return null;
    }

    /**
     * Saves all cached profiles to the database. This operation runs
     * synchronously and should only be called during shutdown. Individual
     * profiles can be saved asynchronously via {@link #saveProfile(PlayerProfile)}.
     */
    public void saveAll() {
        for (PlayerProfile profile : cache.values()) {
            saveProfile(profile);
        }
    }

    /**
     * Saves a single profile to the database asynchronously.
     *
     * @param profile The profile to save
     */
    public void saveProfile(PlayerProfile profile) {
        executor.runAsync(() -> {
            try {
                Connection conn = plugin.getSQLiteManager().getConnection();
                String sql = "INSERT INTO players (uuid, name, country_id, role_id, balance, job) " +
                        "VALUES (?, ?, ?, ?, ?, ?) " +
                        "ON CONFLICT(uuid) DO UPDATE SET name = excluded.name, country_id = excluded.country_id, " +
                        "role_id = excluded.role_id, balance = excluded.balance, job = excluded.job";
                try (PreparedStatement ps = conn.prepareStatement(sql)) {
                    ps.setString(1, profile.getUuid().toString());
                    ps.setString(2, profile.getName());
                    if (profile.getCountryId() == null) {
                        ps.setNull(3, java.sql.Types.INTEGER);
                    } else {
                        ps.setInt(3, profile.getCountryId());
                    }
                    if (profile.getRoleId() == null) {
                        ps.setNull(4, java.sql.Types.INTEGER);
                    } else {
                        ps.setInt(4, profile.getRoleId());
                    }
                    ps.setDouble(5, profile.getBalance());
                    if (profile.getJob() == null) {
                        ps.setNull(6, java.sql.Types.VARCHAR);
                    } else {
                        ps.setString(6, profile.getJob());
                    }
                    ps.executeUpdate();
                }
                conn.commit();
            } catch (SQLException e) {
                plugin.getLogger().severe("Failed to save player profile: " + e.getMessage());
            }
        });
    }

    /**
     * Returns the number of player profiles currently cached.
     *
     * @return size of the cache
     */
    public int size() {
        return cache.size();
    }
}