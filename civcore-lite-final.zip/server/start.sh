#!/bin/bash

# CivCore Lite server startup script
#
# This script launches the Purpur server using Java 21 with a fixed 5 GB
# heap and Aikar’s recommended garbage collection flags. It will accept
# Mojang’s EULA on first run by creating eula.txt with eula=true. To run
# the server in the background, execute this script inside a tmux session.

set -euo pipefail

JAR="purpur-1.21.1.jar"
JAVA_CMD="java"
MEM_OPTS="-Xms5G -Xmx5G"
GC_OPTS="-XX:+UseG1GC -XX:+ParallelRefProcEnabled -XX:MaxGCPauseMillis=200 -XX:+UnlockExperimentalVMOptions -XX:+DisableExplicitGC -XX:+AlwaysPreTouch -XX:G1NewSizePercent=30 -XX:G1MaxNewSizePercent=40 -XX:G1HeapRegionSize=8M -XX:G1ReservePercent=20 -XX:G1HeapWastePercent=5 -XX:G1MixedGCCountTarget=4 -XX:InitiatingHeapOccupancyPercent=15 -XX:G1MixedGCLiveThresholdPercent=90 -XX:G1RSetUpdatingPauseTimePercent=5 -XX:SurvivorRatio=32 -XX:+PerfDisableSharedMem -XX:MaxTenuringThreshold=1"

# Create EULA file if missing
if [ ! -f eula.txt ]; then
  echo "eula=true" > eula.txt
fi

exec $JAVA_CMD $MEM_OPTS $GC_OPTS -jar "$JAR" nogui