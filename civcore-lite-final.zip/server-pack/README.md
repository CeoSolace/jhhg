# CivCore Lite Server Pack

This server pack provides everything you need to deploy and operate the **CivCore Lite** plugin on a fresh Ubuntu/Debian VPS. It includes installation and update scripts, a backup utility and a ready‑made server configuration tuned for 20 concurrent players.

## Structure

The repository is organised into three top‑level directories:

* **`civcore-source/`** — the Gradle project containing all Java source code and resources for the CivCore Lite plugin. Build this to produce `civcore-lite.jar`.
* **`server/`** — the runtime directory for your Purpur server. Scripts and installers create this directory for you and populate it with the server jar, configuration files and plugins.
* **`server-pack/`** — helper scripts and documentation. All commands described in this README live here. Run them from this directory.

## Installing the Server

1. **Prepare your VPS**

   Ensure you have a fresh Ubuntu/Debian system with root or sudo privileges. The install script will install Java 21, tmux, curl, unzip, git and Gradle.

2. **Clone and build the plugin**

   ```bash
   git clone <your repository URL>
   cd civcore-lite/server-pack
   sudo ./install.sh
   ```

   The `install.sh` script performs the following tasks:

   * Installs required system packages.
   * Creates the `server/` directory structure.
   * Downloads the Purpur 1.21.1 jar and common dependencies including Geyser, Floodgate, ViaVersion, Vault and CoreProtect. If the TAB plugin cannot be downloaded automatically, a note will be appended to this README prompting you to download `TAB.jar` manually and place it into `server/plugins/`.
   * Builds the CivCore Lite plugin using Gradle and copies the resulting jar into `server/plugins/`.
   * Writes `server.properties` and `purpur.yml` with sane defaults (nether disabled, spawn protection disabled, etc.).
   * Generates an optimised `start.sh` with Aikar JVM flags and 5 GB memory allocation.
   * Accepts Mojang’s EULA and starts the server inside a tmux session named **`civcore`**.

   After installation you can attach to the console with:

   ```bash
   tmux attach -t civcore
   ```

   To detach from the console without stopping the server press `Ctrl‑b` followed by `d`.

## Updating the Plugin

When you pull new changes or bump the CivCore Lite version, run the update script:

```bash
cd civcore-lite/server-pack
sudo ./update.sh
```

The update script will:

* Stop the running server via the tmux session.
* Build the latest plugin using Gradle.
* Copy the new jar into `server/plugins/`.
* Restart the server in the same tmux session.

This process avoids corrupting the world by ensuring a clean shutdown and restart.

## Backing Up the Server

Use the backup script to create periodic snapshots of your server’s important data:

```bash
cd civcore-lite/server-pack
sudo ./backup.sh
```

The script temporarily disables level saving, flushes pending changes to disk, zips up the worlds (`world`, `world_nether`, `world_the_end` if present), the CivCore configuration directory (`plugins/CivCore`) and core server configs (`server.properties`, `purpur.yml`), then re‑enables saving. The resulting archive is written to `server-pack/backups/latest.zip`. You can schedule this script via cron to run every 15 minutes:

```
*/15 * * * * /path/to/server-pack/backup.sh
```

Older backups are overwritten to conserve disk space. Copy `latest.zip` elsewhere if you need to keep historical backups.

## Command Reference

The CivCore Lite plugin exposes a range of commands for players and administrators. Below is a summary of all available commands. Commands marked with `(op)` require operator status or the appropriate permission.

| Command | Description |
|---|---|
| `/civcore reload` (op) | Reload the plugin configuration and database migrations. |
| `/civcore status` | Display basic status information about the plugin. |
| `/join capitalist` / `/join communist` | Join one of the default countries. |
| `/country info` | Show information about your country. |
| `/country treasury` | View your country’s treasury balance. |
| `/country citizens` | List the citizens of your country. |
| `/balance` | View your personal balance. |
| `/pay <player> <amount>` | Send money to another player. |
| `/work <miner|farmer|factory|trader>` | Choose a job. |
| `/job` | Display your current job and payout information. |
| `/shop` | Open the item shop GUI to buy or sell goods. |
| `/room info` | Show information about your room. |
| `/room buy` | Purchase the first available room in your country’s HQ. |
| `/room upgrade` | Upgrade your room to the next tier. |
| `/room upgrades` | View a list of available room upgrades. |
| `/room sell` | Sell your room back to the treasury for 50% of your spent amount. |
| `/room visit <player>` | Visit another player’s room (teleports to entrance). |
| `/roomshop add <price>` | List the item in your hand for sale in your room shop. |
| `/roomshop remove <id>` | Remove one of your shop listings. |
| `/roomshop listings` | View all items you have listed for sale. |
| `/roomshop buy <player> <id>` | Buy an item from another player’s room shop. |
| `/gov appoint <player> <role>` (leader) | Appoint a player to a government role. |
| `/gov remove <player>` (leader) | Remove a player from their government role. |
| `/gov roles` | Display all roles and the players occupying them. |
| `/parliament propose <type> <value> <desc>` | Submit a new law proposal. |
| `/parliament vote yes/no` | Vote on the current proposal. |
| `/laws` | View the active laws for your country. |
| `/hq info` | Show HQ generation status for all countries. |
| `/hq generate` / `/hq generate confirm` (op) | Generate or regenerate HQ hubs at configured origins. |
| `/rules` | Open your rulebook. |

## Administration Guide

1. **Assign leaders** — After installing the plugin and starting the server, use `/gov appoint <player> leader` to assign a leader to each country. Without a leader players cannot be appointed to other roles or propose laws.

2. **Generate headquarters** — Once leaders are set, run `/hq generate` and then `/hq generate confirm` to create the compact HQ hubs for each country. These hubs include a spawn point, parliament area, government office, job zone, shop, housing corridor and room plots. HQ generation reads coordinates from the `hq` section of `config.yml`. Generation is batched to avoid lag and will not overwrite existing structures without confirmation.

3. **Configure room plots** — Edit the `roomPlots` section of `config.yml` to define where player housing will be built. Each entry includes two corner points and an entrance location. The installer seeds empty room records for each plot on first run. Players can only own one room at a time and upgrades must follow the configured price tiers.

4. **Economy tuning** — Adjust the `economy.currency-symbol` to display your preferred symbol. Modify job payouts and cooldowns under the `jobs` section, and shop item prices under `shop.items`. Tax rates and treasury behaviour can be changed via `/parliament propose TAX_RATE <value>` proposals.

5. **Law configuration** — Default laws are defined under `laws.defaults`. These include tax rate, PvP toggles, and multipliers for jobs and housing prices. Law changes are enacted through the parliament proposal system and take effect when the proposal timer expires with a majority vote. Use `/laws` to view current laws.

6. **Troubleshooting** —

   * If the server fails to start, attach to the tmux session (`tmux attach -t civcore`) and check the console for errors.
   * Ensure ports 25565 (Minecraft) and 19132 (Bedrock via Geyser) are open on your firewall.
   * If the TAB plugin did not download automatically, visit the TAB project page on GitHub and manually place `TAB.jar` into `server/plugins/`.
   * Use `/civcore reload` to reload configuration changes without restarting the server.

Enjoy building your nations and growing your civics simulation with **CivCore Lite**!