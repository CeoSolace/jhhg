#!/bin/bash

# CivCore Lite backup script
#
# This script creates a snapshot backup of the server directory, including
# world data and relevant configurations. It is designed to run while the
# server is online by temporarily disabling auto-saving and flushing pending
# data to disk. The backup is stored in the 'backups' directory with the
# filename 'latest.zip'. You can schedule this script via cron to run
# periodically (e.g., every 15 minutes).

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="${SCRIPT_DIR}/.."
SERVER_DIR="${ROOT_DIR}/server"
BACKUP_DIR="${SCRIPT_DIR}/backups"
SESSION_NAME="civcore"

mkdir -p "$BACKUP_DIR"

backup() {
    local timestamp=$(date +"%Y%m%d_%H%M%S")
    local backup_tmp="${BACKUP_DIR}/backup_${timestamp}.zip"
    local latest_zip="${BACKUP_DIR}/latest.zip"
    echo "Starting backup at $timestamp..."
    # Tell Minecraft to disable saving and flush current state
    if tmux has-session -t "$SESSION_NAME" 2>/dev/null; then
        tmux send-keys -t "$SESSION_NAME" "save-off" ENTER
        tmux send-keys -t "$SESSION_NAME" "save-all" ENTER
        # Wait a moment for save to complete
        sleep 5
    fi
    # Create zip containing worlds and key config files
    pushd "$SERVER_DIR" > /dev/null
    zip -r -q "$backup_tmp" world world_nether world_the_end plugins/CivCore purpur.yml server.properties || true
    popd > /dev/null
    # Re-enable saving
    if tmux has-session -t "$SESSION_NAME" 2>/dev/null; then
        tmux send-keys -t "$SESSION_NAME" "save-on" ENTER
    fi
    # Replace latest.zip and remove temporary
    mv -f "$backup_tmp" "$latest_zip"
    echo "Backup created at $latest_zip"
}

backup