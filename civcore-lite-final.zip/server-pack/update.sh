#!/bin/bash

# CivCore Lite update script
#
# This script safely updates the CivCore Lite plugin and server jar. It stops
# the running server via tmux, rebuilds the plugin using Gradle, deploys
# the updated JAR into the plugins folder and restarts the server. Use this
# script whenever you pull new changes or update dependencies.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="${SCRIPT_DIR}/.."
SERVER_DIR="${ROOT_DIR}/server"
SOURCE_DIR="${ROOT_DIR}/civcore-source"
SESSION_NAME="civcore"
PLUGIN_NAME="civcore-lite.jar"

echo "Stopping the CivCore server for update..."
# Send stop command to the tmux session if it exists
if tmux has-session -t "$SESSION_NAME" 2>/dev/null; then
    tmux send-keys -t "$SESSION_NAME" "stop" ENTER
    # Wait up to 60 seconds for the server to shut down cleanly
    for i in {1..60}; do
        if ! tmux has-session -t "$SESSION_NAME" 2>/dev/null; then
            break
        fi
        sleep 1
    done
    # Kill the session if it didn't close cleanly
    if tmux has-session -t "$SESSION_NAME" 2>/dev/null; then
        tmux kill-session -t "$SESSION_NAME"
    fi
else
    echo "No tmux session named '$SESSION_NAME' was found; proceeding with update."
fi

echo "Building CivCore Lite plugin..."
cd "$SOURCE_DIR"
gradle build
PLUGIN_PATH="build/libs/${PLUGIN_NAME}"
if [ ! -f "$PLUGIN_PATH" ]; then
    echo "Plugin JAR not found after build at $PLUGIN_PATH. Aborting update."
    exit 1
fi

echo "Deploying updated plugin..."
mkdir -p "${SERVER_DIR}/plugins"
cp "$PLUGIN_PATH" "${SERVER_DIR}/plugins/${PLUGIN_NAME}"

echo "Starting server..."
tmux new-session -d -s "$SESSION_NAME" "cd \"${SERVER_DIR}\" && ./start.sh"
echo "Update complete. Server restarted in tmux session '${SESSION_NAME}'."